// قاعدة البيانات — SQLite للتشغيل الفوري بدون إعداد.
// البنية مكتوبة بأنماط قياسية تنتقل إلى PostgreSQL المُدارة سحابياً كما هي تقريباً.
const { DatabaseSync } = require('node:sqlite');
const bcrypt = require('bcryptjs');
const path = require('path');

const db = new DatabaseSync(path.join(__dirname, '..', 'mihwar.db'));
db.exec('PRAGMA journal_mode = WAL');
db.exec('PRAGMA foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
  pass TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'member', color TEXT, active INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS products(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, descr TEXT DEFAULT '', owner_id INTEGER REFERENCES users(id),
  status TEXT DEFAULT 'نشط'
);
CREATE TABLE IF NOT EXISTS releases(
  id INTEGER PRIMARY KEY, product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  version TEXT, date TEXT, status TEXT DEFAULT 'قادم'
);
CREATE TABLE IF NOT EXISTS projects(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, color TEXT DEFAULT '#0E766B',
  status TEXT DEFAULT 'نشط', product_id INTEGER REFERENCES products(id)
);
CREATE TABLE IF NOT EXISTS tasks(
  id INTEGER PRIMARY KEY, title TEXT NOT NULL, descr TEXT DEFAULT '',
  project_id INTEGER NOT NULL REFERENCES projects(id), assignee_id INTEGER REFERENCES users(id),
  due TEXT, prio TEXT DEFAULT 'p2', status TEXT DEFAULT 'todo',
  src TEXT, email_id INTEGER, created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS comments(
  id INTEGER PRIMARY KEY, task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  user_id INTEGER REFERENCES users(id), body TEXT NOT NULL, is_mail INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS channels(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, is_dm INTEGER DEFAULT 0,
  dm_a INTEGER REFERENCES users(id), dm_b INTEGER REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS messages(
  id INTEGER PRIMARY KEY, channel_id INTEGER NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id), body TEXT NOT NULL,
  task_id INTEGER REFERENCES tasks(id), created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS files(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, stored TEXT NOT NULL, size INTEGER, mime TEXT,
  src TEXT DEFAULT 'upload', uploader_id INTEGER REFERENCES users(id),
  task_id INTEGER REFERENCES tasks(id), email_id INTEGER, created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS shares(
  id INTEGER PRIMARY KEY, file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  token TEXT UNIQUE NOT NULL, expires_at TEXT
);
CREATE TABLE IF NOT EXISTS mailboxes(
  id INTEGER PRIMARY KEY, email TEXT NOT NULL, proto TEXT NOT NULL CHECK(proto IN ('IMAP','POP3')),
  host TEXT, port INTEGER, username TEXT, pass_enc TEXT,
  smtp_host TEXT, smtp_port INTEGER DEFAULT 587,
  default_project_id INTEGER REFERENCES projects(id),
  status TEXT DEFAULT 'ok', last_sync TEXT, processed INTEGER DEFAULT 0, last_error TEXT
);
CREATE TABLE IF NOT EXISTS seen_uids(
  mailbox_id INTEGER NOT NULL REFERENCES mailboxes(id) ON DELETE CASCADE, uid TEXT NOT NULL,
  PRIMARY KEY (mailbox_id, uid)
);
CREATE TABLE IF NOT EXISTS emails(
  id INTEGER PRIMARY KEY, mailbox_id INTEGER REFERENCES mailboxes(id), message_id TEXT,
  from_name TEXT, from_email TEXT, subject TEXT, body TEXT,
  summary TEXT, draft TEXT, task_id INTEGER REFERENCES tasks(id),
  replied_at TEXT, received_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS review_queue(
  id INTEGER PRIMARY KEY, from_email TEXT, subject TEXT, body TEXT, reason TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS scheduled(
  id INTEGER PRIMARY KEY, email_id INTEGER REFERENCES emails(id), to_email TEXT, subject TEXT,
  body TEXT, send_at TEXT NOT NULL, status TEXT DEFAULT 'pending', created_by INTEGER REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS notifications(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), body TEXT NOT NULL,
  is_read INTEGER DEFAULT 0, created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS activity(
  id INTEGER PRIMARY KEY, body TEXT NOT NULL, created_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_tasks_proj ON tasks(project_id);
CREATE INDEX IF NOT EXISTS idx_msgs_chan ON messages(channel_id);
CREATE INDEX IF NOT EXISTS idx_emails_msgid ON emails(message_id);
`);


/* ---- ترحيلات v0.2: تُنفذ بأمان على قواعد قائمة ---- */
db.exec(`
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY, title TEXT NOT NULL, starts_at TEXT NOT NULL, ends_at TEXT,
  all_day INTEGER DEFAULT 0, location TEXT, organizer TEXT, notes TEXT,
  source TEXT DEFAULT 'manual', uid TEXT, mailbox_id INTEGER, user_id INTEGER REFERENCES users(id),
  attendee_name TEXT, attendee_email TEXT, status TEXT DEFAULT 'ok',
  created_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_events_uid ON events(uid);
CREATE TABLE IF NOT EXISTS booking_settings(
  user_id INTEGER PRIMARY KEY REFERENCES users(id), slug TEXT UNIQUE, enabled INTEGER DEFAULT 0,
  duration INTEGER DEFAULT 30, days TEXT DEFAULT '0,1,2,3,4', start_hour INTEGER DEFAULT 9,
  end_hour INTEGER DEFAULT 17, title TEXT DEFAULT 'اجتماع'
);
CREATE TABLE IF NOT EXISTS booking_types(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id),
  kind TEXT NOT NULL CHECK(kind IN ('online','inperson')), slug TEXT UNIQUE,
  enabled INTEGER DEFAULT 0, duration INTEGER DEFAULT 30, days TEXT DEFAULT '0,1,2,3,4',
  start_hour INTEGER DEFAULT 9, end_hour INTEGER DEFAULT 17,
  buffer_before INTEGER DEFAULT 0, buffer_after INTEGER DEFAULT 0,
  title TEXT DEFAULT 'اجتماع', UNIQUE(user_id,kind)
);
CREATE TABLE IF NOT EXISTS channel_reads(
  user_id INTEGER NOT NULL, channel_id INTEGER NOT NULL, last_read INTEGER DEFAULT 0,
  PRIMARY KEY(user_id,channel_id)
);
`);
// ترحيل إعدادات الحجز القديمة (رابط واحد) إلى النمط الجديد كرابط «أونلاين»
try {
  const olds = db.prepare('SELECT * FROM booking_settings').all();
  for (const o of olds) {
    if (!db.prepare("SELECT id FROM booking_types WHERE user_id=? AND kind='online'").get(o.user_id))
      db.prepare("INSERT INTO booking_types(user_id,kind,slug,enabled,duration,days,start_hour,end_hour,title) VALUES (?,'online',?,?,?,?,?,?,?)")
        .run(o.user_id, o.slug, o.enabled, o.duration, o.days, o.start_hour, o.end_hour, o.title);
  }
} catch { /* أول تشغيل */ }
db.exec(`
CREATE TABLE IF NOT EXISTS tenants(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, color TEXT DEFAULT '#0E766B',
  created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS memberships(
  user_id INTEGER NOT NULL REFERENCES users(id),
  tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  role TEXT NOT NULL DEFAULT 'member',
  PRIMARY KEY(user_id, tenant_id)
);
`);

const alters = [
  "ALTER TABLE users ADD COLUMN invite_token TEXT",
  "ALTER TABLE users ADD COLUMN must_set_pass INTEGER DEFAULT 0",
  "ALTER TABLE users ADD COLUMN notify_email INTEGER DEFAULT 1",
  "ALTER TABLE tasks ADD COLUMN reminder_sent TEXT",
  "ALTER TABLE mailboxes ADD COLUMN auth_type TEXT DEFAULT 'password'",
  "ALTER TABLE mailboxes ADD COLUMN ms_client_id TEXT",
  "ALTER TABLE mailboxes ADD COLUMN ms_client_secret_enc TEXT",
  "ALTER TABLE mailboxes ADD COLUMN ms_tenant TEXT DEFAULT 'common'",
  "ALTER TABLE mailboxes ADD COLUMN ms_refresh_enc TEXT",
  "ALTER TABLE emails ADD COLUMN approved INTEGER",
  "ALTER TABLE emails ADD COLUMN proposed_title TEXT",
  "ALTER TABLE events ADD COLUMN buffer_before INTEGER DEFAULT 0",
  "ALTER TABLE events ADD COLUMN buffer_after INTEGER DEFAULT 0",
  "ALTER TABLE files ADD COLUMN deleted_at TEXT",
  "ALTER TABLE files ADD COLUMN deleted_by INTEGER",
  "ALTER TABLE tasks ADD COLUMN deleted_at TEXT",
  "ALTER TABLE tasks ADD COLUMN deleted_by INTEGER",
  "ALTER TABLE mailboxes ADD COLUMN scope TEXT DEFAULT 'team'",
  "ALTER TABLE mailboxes ADD COLUMN owner_id INTEGER",
  "ALTER TABLE mailboxes ADD COLUMN is_import INTEGER DEFAULT 0",
  "ALTER TABLE users ADD COLUMN is_super INTEGER DEFAULT 0",
  "ALTER TABLE projects ADD COLUMN tenant_id INTEGER",
  "ALTER TABLE products ADD COLUMN tenant_id INTEGER",
  "ALTER TABLE tasks ADD COLUMN tenant_id INTEGER",
  "ALTER TABLE channels ADD COLUMN tenant_id INTEGER",
  "ALTER TABLE files ADD COLUMN tenant_id INTEGER",
  "ALTER TABLE mailboxes ADD COLUMN tenant_id INTEGER",
  "ALTER TABLE events ADD COLUMN tenant_id INTEGER",
  "ALTER TABLE activity ADD COLUMN tenant_id INTEGER",
  "ALTER TABLE review_queue ADD COLUMN tenant_id INTEGER",
];
for (const a of alters) { try { db.exec(a); } catch { /* العمود موجود مسبقاً */ } }


/* ---- ترحيل v0.6: جهة افتراضية وعضويات ---- */
if (db.prepare('SELECT COUNT(*) c FROM tenants').get().c === 0 && db.prepare('SELECT COUNT(*) c FROM users').get().c > 0) {
  const tid = db.prepare("INSERT INTO tenants(name) VALUES ('الجهة الرئيسية')").run().lastInsertRowid;
  for (const t of ['projects','products','tasks','channels','files','mailboxes','activity','review_queue'])
    db.exec(`UPDATE ${t} SET tenant_id=${tid} WHERE tenant_id IS NULL`);
  db.exec(`UPDATE events SET tenant_id=${tid} WHERE tenant_id IS NULL AND user_id IS NULL AND source!='booking'`);
  db.exec(`UPDATE channels SET tenant_id=NULL WHERE is_dm=1`); // المباشر يبقى بين شخصين عابراً للجهات
  db.exec(`UPDATE mailboxes SET tenant_id=NULL WHERE scope='personal'`); // الشخصي يتبع صاحبه لا جهة
  db.exec(`UPDATE files SET tenant_id=NULL WHERE email_id IS NOT NULL AND task_id IS NULL`);
  for (const u of db.prepare('SELECT id,role FROM users').all())
    db.prepare('INSERT OR IGNORE INTO memberships(user_id,tenant_id,role) VALUES (?,?,?)').run(u.id, tid, u.role || 'member');
  db.exec("UPDATE users SET is_super=1 WHERE role='owner'");
}

function seed() {
  if (db.prepare('SELECT COUNT(*) c FROM users').get().c > 0) return false;
  const hash = bcrypt.hashSync('123456', 10);
  const iu = db.prepare('INSERT INTO users(name,email,pass,role,color) VALUES (?,?,?,?,?)');
  const uid = {};
  uid.me     = iu.run('سلطان العتيبي','sultan@mihwar.local',hash,'owner','#0E766B').lastInsertRowid;
  uid.hind   = iu.run('هند القحطاني','hind@mihwar.local',hash,'admin','#5B4BAE').lastInsertRowid;
  uid.faisal = iu.run('فيصل الدوسري','faisal@mihwar.local',hash,'member','#2B5E9E').lastInsertRowid;
  uid.noura  = iu.run('نورة الشمري','noura@mihwar.local',hash,'member','#B3372F').lastInsertRowid;
  uid.khalid = iu.run('خالد المطيري','khalid@mihwar.local',hash,'viewer','#A16207').lastInsertRowid;

  const pr1 = db.prepare("INSERT INTO products(name,descr,owner_id) VALUES ('تطبيق بوابة العملاء','بوابة ذاتية للعملاء لمتابعة طلباتهم وفواتيرهم',?)").run(uid.hind).lastInsertRowid;
  const pr2 = db.prepare("INSERT INTO products(name,descr,owner_id) VALUES ('منصة التقارير الذكية','لوحات تحليلية لعملاء الأعمال',?)").run(uid.me).lastInsertRowid;
  db.prepare("INSERT INTO releases(product_id,version,date,status) VALUES (?,?,date('now','+20 day'),'قادم'),(?,?,date('now','-15 day'),'صادر')").run(pr1,'2.4',pr1,'2.3');
  db.prepare("INSERT INTO releases(product_id,version,date,status) VALUES (?,?,date('now','+45 day'),'قادم')").run(pr2,'1.0');

  const ip = db.prepare('INSERT INTO projects(name,color,product_id) VALUES (?,?,?)');
  const p1 = ip.run('إطلاق بوابة العملاء 2.4','#0E766B',pr1).lastInsertRowid;
  const p2 = ip.run('دعم العملاء — الربع الثالث','#2B5E9E',pr1).lastInsertRowid;
  const p3 = ip.run('بناء منصة التقارير','#5B4BAE',pr2).lastInsertRowid;

  const it = db.prepare("INSERT INTO tasks(title,descr,project_id,assignee_id,due,prio,status,src) VALUES (?,?,?,?,date('now',?),?,?,?)");
  it.run('اعتماد التصميم النهائي لشاشة الفواتير','مراجعة النسخة الثالثة واعتمادها قبل التسليم للتطوير.',p1,uid.hind,'+0 day','p1','inprog',null);
  it.run('إعداد خطة اختبار الإصدار 2.4','',p1,uid.faisal,'+2 day','p2','todo',null);
  it.run('تصميم مخطط قاعدة بيانات التقارير','',p3,uid.me,'+4 day','p2','review',null);
  it.run('كتابة توثيق واجهات الـ API','',p3,uid.faisal,'+7 day','p3','todo',null);
  it.run('تجهيز بيئة العرض التجريبي','',p1,uid.noura,'-2 day','p2','done',null);

  const ic = db.prepare('INSERT INTO channels(name,is_dm,dm_a,dm_b) VALUES (?,?,?,?)');
  const c1 = ic.run('# عام',0,null,null).lastInsertRowid;
  const c2 = ic.run('# فريق-التطوير',0,null,null).lastInsertRowid;
  ic.run('# دعم-العملاء',0,null,null);
  ic.run('مباشر',1,uid.me,uid.hind);
  const im = db.prepare('INSERT INTO messages(channel_id,user_id,body) VALUES (?,?,?)');
  im.run(c1,uid.hind,'صباح الخير جميعاً، اجتماع المتابعة اليوم الساعة 11.');
  im.run(c2,uid.faisal,'انتهيت من واجهة الفواتير، تبقى ربطها بالبيانات.');
  im.run(c2,uid.noura,'ممتاز! لا تنسَ حالة «لا توجد فواتير» الفارغة.');

  // صندوق بريد تجريبي (بدون خادم فعلي — استخدم زر «محاكاة بريد وارد» لتجربة خط الأنابيب كاملاً)
  db.prepare("INSERT INTO mailboxes(email,proto,host,port,username,default_project_id,status,last_sync) VALUES ('support@demo.local','IMAP','mail.demo.local',993,'support@demo.local',?, 'dev', datetime('now'))").run(p2);
  db.prepare("INSERT INTO activity(body) VALUES ('اكتمل تجهيز النظام وبيانات البداية')").run();
  return true;
}

function ensureTenant() {
  if (db.prepare('SELECT COUNT(*) c FROM tenants').get().c === 0 && db.prepare('SELECT COUNT(*) c FROM users').get().c > 0) {
    const tid = db.prepare("INSERT INTO tenants(name) VALUES ('الجهة الرئيسية')").run().lastInsertRowid;
    for (const t of ['projects','products','tasks','channels','files','mailboxes','activity','review_queue'])
      db.exec(`UPDATE ${t} SET tenant_id=${tid} WHERE tenant_id IS NULL`);
    db.exec(`UPDATE channels SET tenant_id=NULL WHERE is_dm=1`);
    db.exec(`UPDATE mailboxes SET tenant_id=NULL WHERE scope='personal'`);
    for (const u of db.prepare('SELECT id,role FROM users').all())
      db.prepare('INSERT OR IGNORE INTO memberships(user_id,tenant_id,role) VALUES (?,?,?)').run(u.id, tid, u.role || 'member');
    db.exec("UPDATE users SET is_super=1 WHERE role='owner'");
  }
}
module.exports = { db, seed, ensureTenant };
if (require.main === module) { console.log(seed() ? 'seeded' : 'already seeded'); }
