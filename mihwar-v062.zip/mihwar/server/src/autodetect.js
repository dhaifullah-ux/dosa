// اكتشاف إعدادات البريد تلقائياً من عنوان الإيميل:
// 1) مزودون معروفون بالنطاق  2) سجلات MX تكشف المستضيف (Google Workspace / Microsoft 365 / Zoho)
// 3) فحص فعلي لمنافذ خوادم شائعة (mail./imap./smtp.) كخيار أخير
const dns = require('dns').promises;
const tls = require('tls');
const net = require('net');

const KNOWN = {
  'gmail.com':      { provider: 'Google', host: 'imap.gmail.com', port: 993, smtp_host: 'smtp.gmail.com', smtp_port: 587, auth_type: 'password', note: 'حساب Google — فعّل «التحقق بخطوتين» ثم أنشئ App Password من أمان الحساب واستخدمه هنا بدل كلمة مرورك.' },
  'googlemail.com': 'gmail.com',
  'outlook.com':    { provider: 'Microsoft (شخصي)', host: 'outlook.office365.com', port: 993, smtp_host: 'smtp.office365.com', smtp_port: 587, auth_type: 'password', note: 'حساب مايكروسوفت شخصي — فعّل التحقق بخطوتين وأنشئ App Password من أمان الحساب.' },
  'hotmail.com': 'outlook.com', 'live.com': 'outlook.com', 'msn.com': 'outlook.com',
  'yahoo.com':      { provider: 'Yahoo', host: 'imap.mail.yahoo.com', port: 993, smtp_host: 'smtp.mail.yahoo.com', smtp_port: 465, auth_type: 'password', note: 'Yahoo يتطلب App Password من إعدادات أمان الحساب.' },
  'icloud.com':     { provider: 'iCloud', host: 'imap.mail.me.com', port: 993, smtp_host: 'smtp.mail.me.com', smtp_port: 587, auth_type: 'password', note: 'iCloud يتطلب كلمة مرور خاصة بالتطبيقات من appleid.apple.com.' },
  'me.com': 'icloud.com', 'mac.com': 'icloud.com',
  'zoho.com':       { provider: 'Zoho', host: 'imap.zoho.com', port: 993, smtp_host: 'smtp.zoho.com', smtp_port: 587, auth_type: 'password', note: 'فعّل IMAP من إعدادات Zoho Mail أولاً.' },
};

function probe(host, port, useTls) {
  return new Promise((resolve) => {
    const sock = useTls ? tls.connect({ host, port, rejectUnauthorized: false, timeout: 2500 })
                        : net.connect({ host, port, timeout: 2500 });
    const done = ok => { try { sock.destroy(); } catch {} resolve(ok ? host : null); };
    sock.once(useTls ? 'secureConnect' : 'connect', () => done(true));
    sock.once('error', () => done(false));
    sock.once('timeout', () => done(false));
  });
}
async function firstAlive(hosts, port, useTls) {
  const results = await Promise.all(hosts.map(h => probe(h, port, useTls)));
  return results.find(Boolean) || null;
}

async function detect(email) {
  const domain = String(email).split('@')[1]?.toLowerCase();
  if (!domain) return { found: false, note: 'أدخل بريداً صحيحاً' };

  let k = KNOWN[domain];
  if (typeof k === 'string') k = KNOWN[k];
  if (k) return { found: true, method: 'معروف', proto: 'IMAP', ...k };

  // سجلات MX تكشف المستضيف الحقيقي للنطاقات المؤسسية
  let mx = [];
  try { mx = (await dns.resolveMx(domain)).map(r => r.exchange.toLowerCase()); } catch { /* لا DNS */ }
  const mxs = mx.join(' ');
  if (/google\.com|googlemail/.test(mxs))
    return { found: true, method: 'MX', provider: 'Google Workspace', proto: 'IMAP',
      host: 'imap.gmail.com', port: 993, smtp_host: 'smtp.gmail.com', smtp_port: 587, auth_type: 'password',
      note: `نطاقك ${domain} مستضاف على Google Workspace — استخدم App Password (التحقق بخطوتين ← كلمات مرور التطبيقات).` };
  if (/protection\.outlook\.com|office365/.test(mxs))
    return { found: true, method: 'MX', provider: 'Microsoft 365', proto: 'IMAP',
      host: 'outlook.office365.com', port: 993, smtp_host: 'smtp.office365.com', smtp_port: 587, auth_type: 'oauth_ms',
      note: `نطاقك ${domain} مستضاف على Microsoft 365 — اخترنا لك نمط OAuth2 لأن مايكروسوفت أوقفت كلمات المرور العادية. تحتاج Client ID/Secret من Azure (الدليل في README).` };
  if (/zoho/.test(mxs))
    return { found: true, method: 'MX', provider: 'Zoho', proto: 'IMAP',
      host: 'imap.zoho.com', port: 993, smtp_host: 'smtp.zoho.com', smtp_port: 587, auth_type: 'password',
      note: `نطاقك مستضاف على Zoho — فعّل IMAP من إعداداته.` };

  // فحص فعلي لأنماط الاستضافة الذاتية الشائعة
  const imapHost = await firstAlive([`mail.${domain}`, `imap.${domain}`, domain], 993, true);
  const smtpHost = imapHost ? (await firstAlive([`smtp.${domain}`, `mail.${domain}`, imapHost], 587, false)) : null;
  if (imapHost)
    return { found: true, method: 'فحص', provider: 'خادم خاص', proto: 'IMAP',
      host: imapHost, port: 993, smtp_host: smtpHost || `smtp.${domain}`, smtp_port: 587, auth_type: 'password',
      note: `وجدنا خادم IMAP يستجيب على ${imapHost}:993${smtpHost ? ` وSMTP على ${smtpHost}:587` : ''} — أدخل كلمة المرور وجرّب.` };

  return { found: false, provider: 'غير معروف', proto: 'IMAP', host: `mail.${domain}`, port: 993,
    smtp_host: `smtp.${domain}`, smtp_port: 587, auth_type: 'password',
    note: `لم نتعرف على مستضيف ${domain} تلقائياً — عبّينا الأنماط الأكثر شيوعاً، عدّلها من مزود بريدك إن لزم.` };
}
module.exports = { detect };
