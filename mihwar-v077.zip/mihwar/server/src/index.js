// محور — نقطة تشغيل الخادم: REST + ملفات ثابتة + WebSocket لحظي + عمال البريد والجدولة.
require('dotenv').config();
// درع الاستقرار: أعطال الشبكة العابرة لا تسقط النظام + أولوية IPv4 (بيئات سحابية بـIPv6 معطوب)
require('dns').setDefaultResultOrder('ipv4first');
process.on('uncaughtException', (e) => console.error('[uncaught]', e && e.message ? e.message : e));
process.on('unhandledRejection', (e) => console.error('[unhandled]', e && e.message ? e.message : e));

const express = require('express');
const http = require('http');
const path = require('path');
const jwt = require('jsonwebtoken');
const { db, seed, ensureTenant } = require('./db');
const routes = require('./routes');
const mailer = require('./mailer');

seed();
ensureTenant();
const app = express();
const server = http.createServer(app);
const io = require('socket.io')(server, { cors: { origin: '*' } });

app.use(express.json({ limit: '2mb' }));

/* ================== صفحات وواجهات عامة (بدون تسجيل دخول) ================== */
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const page = (title, body) => `<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${title} — محور</title><link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;700&display=swap" rel="stylesheet">
<style>body{font-family:'IBM Plex Sans Arabic',sans-serif;background:#122B28;margin:0;min-height:100vh;display:grid;place-items:center;padding:20px;box-sizing:border-box}
.card{background:#fff;border-radius:16px;padding:30px 32px;width:430px;max-width:94vw;box-shadow:0 24px 80px rgba(0,0,0,.4)}
h1{font-size:17px;margin:0 0 4px}.sub{font-size:12.5px;color:#6E7480;margin:0 0 18px}
label{display:block;font-size:11.5px;color:#6E7480;margin:12px 0 4px}
input,select{width:100%;border:1px solid #E4E1D8;border-radius:8px;padding:9px 11px;font-family:inherit;font-size:13.5px;box-sizing:border-box;outline:none}
input:focus{border-color:#0E766B}
button{width:100%;margin-top:16px;background:#0E766B;color:#fff;border:none;border-radius:8px;padding:11px;font-family:inherit;font-size:14px;font-weight:500;cursor:pointer}
button:hover{background:#0A5A52}button:disabled{opacity:.5}
.brand{display:flex;gap:9px;align-items:center;margin-bottom:14px}
.mark{width:34px;height:34px;border-radius:9px;background:linear-gradient(135deg,#17564F,#0E766B);display:grid;place-items:center;color:#EAF6F3;font-weight:700;font-size:17px}
.msg{font-size:12.5px;min-height:18px;margin-top:10px}.err{color:#B3372F}.ok{color:#1E6B45}
.slots{display:grid;grid-template-columns:repeat(3,1fr);gap:7px;margin-top:6px}
.slot{border:1px solid #BBDCD5;background:#E4F1EE;color:#0A5A52;border-radius:8px;padding:8px 4px;font-size:12.5px;text-align:center;cursor:pointer}
.slot:hover{background:#0E766B;color:#fff}.slot.sel{background:#0E766B;color:#fff}
.day{font-size:12px;font-weight:700;margin:14px 0 2px}</style></head><body><div class="card">
<div class="brand"><div class="mark">م</div><div><b style="font-size:15px">محور</b></div></div>${body}</div></body></html>`;

/* --- صفحة تفعيل الدعوة وتعيين كلمة المرور --- */
app.get('/invite/:token', (req, res) => {
  const u = db.prepare('SELECT name FROM users WHERE invite_token=?').get(req.params.token);
  if (!u) return res.status(404).send(page('دعوة غير صالحة', '<h1>رابط الدعوة غير صالح</h1><p class="sub">ربما استُخدم مسبقاً — اطلب دعوة جديدة من مدير النظام.</p>'));
  res.send(page('تفعيل الحساب', `
    <h1>أهلاً ${u.name} 👋</h1><p class="sub">دُعيت للانضمام لنظام محور. عيّن كلمة مرورك لإكمال التفعيل.</p>
    <label>كلمة المرور (8 أحرف فأكثر)</label><input type="password" id="p1">
    <label>تأكيد كلمة المرور</label><input type="password" id="p2">
    <div class="msg err" id="err"></div>
    <button onclick="go()">تفعيل الحساب والدخول</button>
    <script>
    async function go(){
      const p1=document.getElementById('p1').value,p2=document.getElementById('p2').value,err=document.getElementById('err');
      if(p1.length<8)return err.textContent='كلمة المرور 8 أحرف على الأقل';
      if(p1!==p2)return err.textContent='الكلمتان غير متطابقتين';
      const r=await fetch('/api/public/invite/${req.params.token}',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:p1})});
      const j=await r.json();
      if(!r.ok)return err.textContent=j.error||'حدث خطأ';
      location.href='/';
    }
    </script>`));
});
app.post('/api/public/invite/:token', express.json(), (req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE invite_token=?').get(req.params.token);
  if (!u) return res.status(404).json({ error: 'رابط غير صالح' });
  if (!req.body.password || req.body.password.length < 8) return res.status(400).json({ error: 'كلمة المرور 8 أحرف على الأقل' });
  db.prepare('UPDATE users SET pass=?, invite_token=NULL, must_set_pass=0, active=1 WHERE id=?')
    .run(bcrypt.hashSync(req.body.password, 10), u.id);
  broadcast(); res.json({ ok: 1 });
});

/* --- حساب المواعيد المتاحة --- */
function freeSlots(bs) {
  const out = []; const now = new Date();
  const busy = db.prepare(`SELECT e.starts_at,e.ends_at,e.buffer_before,e.buffer_after FROM events e WHERE e.status='ok' AND starts_at >= datetime('now','-1 day')
    AND (e.user_id=? OR e.tenant_id IN (SELECT tenant_id FROM memberships WHERE user_id=?))`).all(bs.user_id, bs.user_id);
  const days = String(bs.days || '').split(',').map(Number);
  const bufB = (bs.buffer_before || 0) * 60000, bufA = (bs.buffer_after || 0) * 60000;
  for (let d = 0; d < 14; d++) {
    const day = new Date(now); day.setDate(day.getDate() + d);
    if (!days.includes(day.getDay())) continue;
    const dayStr = day.toISOString().slice(0, 10); const slots = [];
    for (let m = bs.start_hour * 60; m + bs.duration <= bs.end_hour * 60; m += bs.duration) {
      const hh = String(Math.floor(m / 60)).padStart(2, '0'), mm = String(m % 60).padStart(2, '0');
      const stStr = `${dayStr}T${hh}:${mm}:00`;
      const st = new Date(stStr), en = new Date(st.getTime() + bs.duration * 60000);
      if (st <= now) continue;
      // نافذة الموعد المطلوب موسّعة بوقت الانتقال، ونوافذ الانشغال موسّعة بأوقات انتقال أحداثها
      const winS = new Date(st.getTime() - bufB), winE = new Date(en.getTime() + bufA);
      const clash = busy.some(b => {
        const bs2 = new Date(new Date(b.starts_at).getTime() - (b.buffer_before || 0) * 60000);
        const be = new Date((b.ends_at ? new Date(b.ends_at) : new Date(new Date(b.starts_at).getTime() + 3600000)).getTime() + (b.buffer_after || 0) * 60000);
        return bs2 < winE && be > winS;
      });
      if (!clash) slots.push(stStr);
    }
    if (slots.length) out.push({ date: dayStr, slots });
  }
  return out;
}

/* --- صفحة الحجز العامة --- */
app.get('/book/:slug', (req, res) => {
  const bs = db.prepare('SELECT b.*,u.name uname FROM booking_types b JOIN users u ON u.id=b.user_id WHERE b.slug=? AND b.enabled=1').get(req.params.slug);
  if (!bs) return res.status(404).send(page('غير متاح', '<h1>رابط الحجز غير متاح</h1><p class="sub">تأكد من الرابط أو تواصل مع صاحبه.</p>'));
  res.send(page('حجز موعد', `
    <h1>حجز ${bs.title} مع ${bs.uname}</h1><p class="sub">${bs.kind==='inperson'?'اجتماع حضوري':'اجتماع عن بُعد'} · ${bs.duration} دقيقة — اختر الوقت المناسب لك (التوقيت بتوقيت النظام).</p>
    <div id="list">جاري تحميل المواعيد…</div>
    <div id="form" style="display:none">
      <label>اسمك</label><input id="bn"><label>بريدك الإلكتروني</label><input id="be" style="direction:ltr">
      <div class="msg err" id="err"></div>
      <button id="go">تأكيد الحجز</button>
    </div>
    <div class="msg ok" id="done"></div>
    <script>
    let sel=null;const wd=['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
    fetch('/api/public/booking/${bs.slug}/slots').then(r=>r.json()).then(days=>{
      const L=document.getElementById('list');L.innerHTML='';
      if(!days.length){L.textContent='لا مواعيد متاحة خلال الأسبوعين القادمين.';return;}
      for(const d of days){
        const dt=new Date(d.date+'T12:00:00');
        L.insertAdjacentHTML('beforeend','<div class="day">'+wd[dt.getDay()]+' '+dt.toLocaleDateString('ar',{day:'numeric',month:'long'})+'</div><div class="slots">'+
          d.slots.map(s=>'<div class="slot" data-s="'+s+'">'+s.slice(11,16)+'</div>').join('')+'</div>');
      }
      L.addEventListener('click',e=>{const el=e.target.closest('.slot');if(!el)return;
        document.querySelectorAll('.slot').forEach(x=>x.classList.remove('sel'));el.classList.add('sel');
        sel=el.dataset.s;document.getElementById('form').style.display='block';el.scrollIntoView({block:'nearest'});});
    });
    document.getElementById('go').onclick=async()=>{
      const err=document.getElementById('err'),bn=document.getElementById('bn').value.trim(),be=document.getElementById('be').value.trim();
      if(!sel)return err.textContent='اختر موعداً أولاً';
      if(!bn||!be.includes('@'))return err.textContent='أدخل اسمك وبريدك الصحيح';
      document.getElementById('go').disabled=true;
      const r=await fetch('/api/public/booking/${bs.slug}',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({start:sel,name:bn,email:be})});
      const j=await r.json();document.getElementById('go').disabled=false;
      if(!r.ok)return err.textContent=j.error||'تعذر الحجز';
      document.getElementById('form').style.display='none';document.getElementById('list').style.display='none';
      document.getElementById('done').textContent='✓ تم تأكيد حجزك '+sel.slice(0,10)+' الساعة '+sel.slice(11,16)+' — ستصلك دعوة تقويم على بريدك.';
    };
    </script>`));
});
app.get('/api/public/booking/:slug/slots', (req, res) => {
  const bs = db.prepare('SELECT * FROM booking_types WHERE slug=? AND enabled=1').get(req.params.slug);
  if (!bs) return res.status(404).json({ error: 'غير متاح' });
  res.json(freeSlots(bs));
});
app.post('/api/public/booking/:slug', express.json(), async (req, res) => {
  const bs = db.prepare('SELECT b.*,u.name uname,u.email uemail FROM booking_types b JOIN users u ON u.id=b.user_id WHERE b.slug=? AND b.enabled=1').get(req.params.slug);
  if (!bs) return res.status(404).json({ error: 'غير متاح' });
  const { start, name: vn, email: ve } = req.body || {};
  if (!start || !vn || !ve) return res.status(400).json({ error: 'بيانات ناقصة' });
  const valid = freeSlots(bs).some(d => d.slots.includes(start));
  if (!valid) return res.status(409).json({ error: 'هذا الموعد لم يعد متاحاً — اختر غيره' });
  const ends = new Date(new Date(start).getTime() + bs.duration * 60000).toISOString().slice(0, 19);
  const uid = 'booking-' + crypto.randomUUID() + '@mihwar';
  db.prepare("INSERT INTO events(title,starts_at,ends_at,source,uid,user_id,attendee_name,attendee_email,buffer_before,buffer_after,location) VALUES (?,?,?,'booking',?,?,?,?,?,?,?)")
    .run(`${bs.title}: ${vn}`, start, ends, uid, bs.user_id, vn, ve, bs.buffer_before || 0, bs.buffer_after || 0, bs.kind === 'inperson' ? 'حضوري' : 'أونلاين');
  mailer.notifyUser(bs.user_id, `حجز جديد: ${vn} (${ve}) — ${start.slice(0, 10)} الساعة ${start.slice(11, 16)}`, true);
  mailer.logAct(`حجز موعد جديد عبر الرابط العام: ${vn}`);
  const ics = mailer.buildIcs({ uid, title: `${bs.title} مع ${bs.uname}`, starts_at: start, ends_at: ends,
    organizerEmail: bs.uemail, organizerName: bs.uname, attendeeEmail: ve, attendeeName: vn,
    description: 'حُجز عبر نظام محور' });
  mailer.sendSystemMail(ve, `تأكيد موعدك مع ${bs.uname}`, `مرحباً ${vn}،\n\nتأكد حجزك يوم ${start.slice(0, 10)} الساعة ${start.slice(11, 16)} (مدة ${bs.duration} دقيقة).\nمرفق دعوة التقويم.`, ics).catch(() => {});
  broadcast(); res.json({ ok: 1 });
});

/* --- عودة تفويض مايكروسوفت --- */
app.get('/api/ms-callback', async (req, res) => {
  try {
    const st = jwt.verify(req.query.state || '', process.env.SECRET || 'dev');
    const mb = db.prepare('SELECT * FROM mailboxes WHERE id=?').get(st.mb);
    if (!mb) throw new Error('الصندوق غير موجود');
    const j = await require('./msauth').exchangeCode(mb, req.query.code, mailer.getSetting('base_url'), mailer.dec);
    db.prepare("UPDATE mailboxes SET ms_refresh_enc=?, status='ok', last_error=NULL WHERE id=?").run(mailer.enc(j.refresh_token), mb.id);
    mailer.logAct(`رُبط حساب مايكروسوفت للصندوق ${mb.email} بنجاح`);
    broadcast();
    res.send(page('تم الربط', '<h1>✓ رُبط حساب مايكروسوفت بنجاح</h1><p class="sub">أغلق هذه الصفحة وعد إلى محور — ستبدأ المزامنة خلال دقيقة.</p>'));
  } catch (e) {
    res.status(400).send(page('فشل الربط', `<h1>تعذر ربط مايكروسوفت</h1><p class="sub">${String(e.message).slice(0, 200)}</p>`));
  }
});

app.use('/api', routes);
app.use((req,res,next)=>{ if(req.path==='/'||req.path.endsWith('.html')) res.set('Cache-Control','no-cache'); next(); });
app.use(express.static(path.join(__dirname, '..', '..', 'web')));

// رابط المشاركة العام المؤقت
app.get('/s/:token', (req, res) => {
  const sh = db.prepare('SELECT s.*,f.name,f.stored FROM shares s JOIN files f ON f.id=s.file_id WHERE token=?').get(req.params.token);
  if (!sh) return res.status(404).send('<meta charset=utf-8><h3 style="font-family:sans-serif">الرابط غير صحيح</h3>');
  if (db.prepare('SELECT deleted_at FROM files WHERE id=?').get(sh.file_id)?.deleted_at)
    return res.status(410).send('<meta charset=utf-8><h3 style="font-family:sans-serif">هذا الملف حُذف من النظام</h3>');
  if (sh.expires_at && new Date(sh.expires_at) < new Date())
    return res.status(410).send('<meta charset=utf-8><h3 style="font-family:sans-serif">انتهت صلاحية هذا الرابط</h3>');
  res.download(path.join(__dirname, '..', 'uploads', sh.stored), sh.name);
});

// WebSocket: مصادقة بالتوكن، وأي تغيير في النظام يبث «changed» فيعيد كل عميل تحميل حالته
io.use((socket, next) => {
  try { socket.user = jwt.verify(socket.handshake.auth.token, process.env.SECRET || 'dev'); next(); }
  catch { next(new Error('unauthorized')); }
});
const broadcast = () => io.emit('changed');
routes.onChange(broadcast);
mailer.onChange(broadcast);

mailer.startPolling();
mailer.startScheduler();
mailer.startReminders();
mailer.startPurge();

const PORT = process.env.PORT || 4000;
server.listen(PORT, () => console.log(`محور يعمل الآن → http://localhost:${PORT}  (الدخول: sultan@mihwar.local / 123456)`));
