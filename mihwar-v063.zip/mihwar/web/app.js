/* محور — عميل الويب: كل البيانات من الخادم، وكل تعديل عبر REST، والتحديثات لحظية عبر WebSocket */
const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;');
let TOKEN=localStorage.getItem('mihwar_token')||null;
let S=null; // حالة النظام كاملة من الخادم
let socket=null;

/* ---------- الاتصال بالخادم ---------- */
async function api(path,method='GET',body,isForm){
  const opt={method,headers:{Authorization:'Bearer '+TOKEN,'X-Tenant':localStorage.getItem('mihwar_tenant')||'all'}};
  if(body&&!isForm){opt.headers['Content-Type']='application/json';opt.body=JSON.stringify(body);}
  if(isForm)opt.body=body;
  const res=await fetch('/api'+path,opt);
  if(res.status===401){logout(true);throw new Error('انتهت الجلسة');}
  const j=await res.json().catch(()=>({}));
  if(!res.ok){toast(j.error||'حدث خطأ غير متوقع');throw new Error(j.error||'err');}
  return j;
}
let reloadTimer=null;
function scheduleReload(){clearTimeout(reloadTimer);reloadTimer=setTimeout(loadState,200);}
async function loadState(){S=await api('/state');renderAll();}
function connectSocket(){
  socket=io({auth:{token:TOKEN}});
  socket.on('changed',scheduleReload);
}
async function doLogin(){
  try{
    const r=await fetch('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({email:$('#loginEmail').value.trim(),password:$('#loginPass').value})});
    const j=await r.json();
    if(!r.ok){$('#loginErr').textContent=j.error||'تعذر الدخول';return;}
    TOKEN=j.token;localStorage.setItem('mihwar_token',TOKEN);
    $('#loginWrap').style.display='none';connectSocket();await loadState();
    toast('أهلاً '+j.user.name.split(' ')[0]+' — النظام متصل ومباشر');
  }catch(e){$('#loginErr').textContent='تعذر الاتصال بالخادم';}
}
function logout(expired){localStorage.removeItem('mihwar_token');TOKEN=null;
  if(socket)socket.disconnect();
  $('#loginWrap').style.display='grid';
  if(expired)$('#loginErr').textContent='انتهت الجلسة — سجّل الدخول من جديد';}
$('#loginPass').addEventListener('keydown',e=>{if(e.key==='Enter')doLogin();});

/* ---------- أدوات ---------- */
function toast(txt,link,fn){const el=document.createElement('div');el.className='toast';
  el.innerHTML=esc(txt)+(link?` <button class="tk" onclick="${fn}">${esc(link)}</button>`:'');
  $('#toasts').appendChild(el);setTimeout(()=>el.remove(),3800);}
function openModal(id){$('#'+id).classList.add('open');}
function closeModal(id){$('#'+id).classList.remove('open');}
const roleAr={owner:'مالك النظام',admin:'مدير',member:'عضو',viewer:'مشاهد'};
const M=id=>S.members.find(m=>m.id===id)||{name:'النظام',color:'#8A9199'};
const P=id=>S.projects.find(p=>p.id===id)||{name:'—',color:'#999'};
const E=id=>S.emails.find(e=>e.id===id);
const T=id=>S.tasks.find(t=>t.id===id);
const ini=n=>(n||'؟').split(' ')[0].slice(0,2);
function avatarEl(id,xs){const m=M(id);return `<div class="avatar ${xs?'xs':''}" style="background:${m.color}" title="${esc(m.name)}">${ini(m.name)}</div>`;}
const statuses=[['todo','قيد الانتظار'],['inprog','قيد التنفيذ'],['review','قيد المراجعة'],['done','مكتملة']];
const todayISO=()=>new Date().toISOString().slice(0,10);
const isLate=d=>d&&d<todayISO();
function fmtD(iso){if(!iso)return'—';const t=todayISO();
  const tomorrow=new Date(Date.now()+864e5).toISOString().slice(0,10);
  if(iso===t)return'اليوم';if(iso===tomorrow)return'غداً';
  return new Date(iso).toLocaleDateString('ar',{day:'numeric',month:'long'});}
function fmtWhen(ts){if(!ts)return'';const d=new Date(ts.replace(' ','T')+'Z');const diff=(Date.now()-d)/60000;
  if(diff<2)return'الآن';if(diff<60)return'قبل '+Math.round(diff)+' دقيقة';
  if(diff<1440)return'قبل '+Math.round(diff/60)+' ساعة';
  return d.toLocaleDateString('ar',{day:'numeric',month:'long'});}
function fmtSize(b){if(!b)return'';return b>1048576?(b/1048576).toFixed(1)+' م.ب':Math.max(1,Math.round(b/1024))+' ك.ب';}

/* ---------- الجهات ---------- */
const TN=id=>((S&&S.tenants)||[]).find(t=>t.id===id)||{name:'',color:'#888'};
const isAllMode=()=>!(S&&S.curTenant);
function switchTenant(v){localStorage.setItem('mihwar_tenant',v);loadState();toast(v==='all'?'اللوحة الموحدة — كل جهاتك معاً':'انتقلت لجهة: '+TN(+v).name);}
async function createTenant(){
  const n=$('#tnName').value.trim();if(!n){toast('اكتب اسم الجهة');return;}
  const r=await api('/tenants','POST',{name:n});
  $('#tnName').value='';closeModal('tenantModal');
  localStorage.setItem('mihwar_tenant',r.id);await loadState();
  toast('أُنشئت الجهة وانتقلت إليها — ادعُ أعضاءها من الإعدادات');
}
/* ---------- التنقل ---------- */
function go(view){
  document.querySelectorAll('#nav button').forEach(b=>b.classList.toggle('on',b.dataset.view===view));
  document.querySelectorAll('.view').forEach(v=>v.classList.toggle('on',v.id==='view-'+view));
  if(view==='chat'&&S){if(curChan)markChanRead(curChan);renderChat();}
}
$('#nav').addEventListener('click',e=>{const b=e.target.closest('button');if(b)go(b.dataset.view);});

/* ---------- لوحة التحكم ---------- */
function renderDashboard(){
  $('#helloName').textContent=S.me.name.split(' ')[0];
  $('#meName').textContent=S.me.name;$('#meRole').textContent=roleAr[S.me.role];
  $('#meAvatar').textContent=ini(S.me.name);$('#meAvatar').style.background=S.me.color;
  $('#modeTag').textContent=S.devMode?'وضع التطوير — الإرسال البريدي محاكى':'نظام مباشر';
  $('#todayStr').textContent=new Date().toLocaleDateString('ar',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
  const my=S.tasks.filter(t=>t.assignee_id===S.me.id&&t.status!=='done');
  const late=S.tasks.filter(t=>isLate(t.due)&&t.status!=='done');
  $('#statMy').textContent=my.length;$('#statLate').textContent=late.length;
  $('#statMail').textContent=S.emails.filter(e=>!e.replied_at&&e.task_id&&!S.scheduled.some(s=>s.email_id===e.id)).length;
  $('#dashProjects').innerHTML=S.projects.filter(p=>p.status==='نشط').map(p=>{
    const pt=S.tasks.filter(t=>t.project_id===p.id),dn=pt.filter(t=>t.status==='done').length;
    const pct=pt.length?Math.round(dn/pt.length*100):0;
    return `<div class="rowitem" onclick="go('projects')">
      <span style="width:9px;height:9px;border-radius:3px;background:${p.color};flex:none"></span>
      <div class="grow"><div>${esc(p.name)}</div><div class="sub">${pt.length} مهام · ${dn} مكتملة</div></div>
      <div class="progress" style="width:110px"><i style="width:${pct}%"></i></div>
      <b style="font-size:12px;width:34px;text-align:left">${pct}%</b></div>`;}).join('')||'<div class="empty">لا مشاريع نشطة</div>';
  $('#dashMailboxes').innerHTML=S.mailboxes.map(m=>`<div class="rowitem mailrow" onclick="go('settings')">
    <span class="st ${m.status==='ok'?'ok':m.status==='dev'?'warn':'err'}"></span>
    <div class="grow"><div style="direction:ltr;text-align:right">${esc(m.email)}</div>
    <div class="sub">${m.proto} · ${m.status==='dev'?'صندوق تجريبي (استخدم المحاكاة)':m.status==='err'?('خطأ: '+esc(m.last_error||'')):('آخر مزامنة '+fmtWhen(m.last_sync))} · ${m.processed} معالجة</div></div></div>`).join('');
  const dts=S.tasks.filter(t=>t.status!=='done'&&t.due&&t.due<=todayISO()).sort((a,b)=>a.due<b.due?-1:1);
  $('#dashTasks').innerHTML=dts.length?dts.map(t=>`<div class="rowitem" onclick="openDrawer(${t.id})">
    <span class="prio ${t.prio}"></span><div class="grow trunc">${esc(t.title)}</div>
    ${t.src==='mail'?'<span class="chip blue">✉ بريد</span>':''}
    <span class="due ${isLate(t.due)?'late':''}" style="font-size:11.5px">${isLate(t.due)?'متأخرة — ':''}${fmtD(t.due)}</span>
    ${t.assignee_id?avatarEl(t.assignee_id,1):''}</div>`).join(''):'<div class="empty">لا مهام مستحقة اليوم 🎉</div>';
  $('#dashActivity').innerHTML=S.activity.map(a=>`<div class="rowitem" style="cursor:default"><div class="grow"><div style="font-size:12.5px">${esc(a.body)}</div><div class="sub">${fmtWhen(a.created_at)}</div></div></div>`).join('');
}

/* ---------- المهام ---------- */
let taskView='kanban';
$('#taskTabs').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;
  taskView=b.dataset.tv;document.querySelectorAll('#taskTabs button').forEach(x=>x.classList.toggle('on',x===b));renderTasks();});
$('#taskProjFilter').addEventListener('change',renderTasks);
$('#onlyMine').addEventListener('change',renderTasks);
function filteredTasks(){const pf=$('#taskProjFilter').value;
  return S.tasks.filter(t=>(!pf||t.project_id==pf)&&(!$('#onlyMine').checked||t.assignee_id===S.me.id));}
function taskCard(t){const p=P(t.project_id);
  return `<div class="kcard" draggable="true" data-id="${t.id}" onclick="openDrawer(${t.id})">
    <div class="t">${esc(t.title)}</div>
    <div class="meta"><span class="prio ${t.prio}"></span>
      <span class="chip gray" style="background:${p.color}18;color:${p.color}">${esc(p.name.split(' ').slice(0,2).join(' '))}</span>
      ${isAllMode()&&S.tenants.length>1?`<span class="chip purple">${esc(TN(t.tenant_id).name.split(' ')[0])}</span>`:''}
      ${t.src==='mail'?'<span title="وصلت عبر البريد">✉</span>':''}<span class="grow"></span>
      ${t.due?`<span class="due ${isLate(t.due)&&t.status!=='done'?'late':''}">${fmtD(t.due)}</span>`:''}
      ${t.assignee_id?avatarEl(t.assignee_id,1):''}</div></div>`;}
function renderTasks(){
  const keep=$('#taskProjFilter').value;
  $('#taskProjFilter').innerHTML='<option value="">كل المشاريع</option>'+S.projects.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('');
  $('#taskProjFilter').value=keep;
  const ft=filteredTasks();
  $('#taskKanban').style.display=taskView==='kanban'?'grid':'none';
  $('#taskList').style.display=taskView==='list'?'block':'none';
  if(taskView==='kanban'){
    $('#taskKanban').innerHTML=statuses.map(([k,label])=>{
      const col=ft.filter(t=>t.status===k);
      return `<div class="kcol" data-st="${k}"><h4>${label} <b>${col.length}</b></h4>${col.map(taskCard).join('')||'<div style="font-size:11.5px;color:#A8ADB6;text-align:center;padding:14px">اسحب مهمة هنا</div>'}</div>`;}).join('');
    bindDnD();
  }else{
    $('#taskList').innerHTML=`<table class="tbl"><thead><tr><th>المهمة</th><th>المشروع</th><th>المسؤول</th><th>الاستحقاق</th><th>الحالة</th></tr></thead><tbody>${
      ft.map(t=>`<tr class="click" onclick="openDrawer(${t.id})"><td><span class="prio ${t.prio}"></span> ${esc(t.title)} ${t.src==='mail'?'<span class="chip blue">✉</span>':''}</td>
      <td style="color:${P(t.project_id).color}">${esc(P(t.project_id).name)}</td><td>${t.assignee_id?esc(M(t.assignee_id).name):'—'}</td>
      <td class="due ${isLate(t.due)&&t.status!=='done'?'late':''}">${fmtD(t.due)}</td>
      <td><span class="chip ${t.status==='done'?'teal':t.status==='inprog'?'amber':'gray'}">${statuses.find(s=>s[0]===t.status)[1]}</span></td></tr>`).join('')||'<tr><td colspan="5" class="empty">لا مهام مطابقة</td></tr>'}</tbody></table>`;
  }
}
function bindDnD(){
  let dragId=null;
  document.querySelectorAll('.kcard').forEach(c=>{
    c.addEventListener('dragstart',()=>{dragId=+c.dataset.id;c.classList.add('drag');});
    c.addEventListener('dragend',()=>c.classList.remove('drag'));});
  document.querySelectorAll('.kcol').forEach(col=>{
    col.addEventListener('dragover',e=>{e.preventDefault();col.classList.add('over');});
    col.addEventListener('dragleave',()=>col.classList.remove('over'));
    col.addEventListener('drop',async e=>{e.preventDefault();col.classList.remove('over');
      const t=T(dragId);if(t&&t.status!==col.dataset.st){
        t.status=col.dataset.st;renderTasks();
        await api('/tasks/'+dragId,'PATCH',{status:col.dataset.st});}});});
}
let curTask=null;
function openDrawer(id){
  curTask=T(id);const t=curTask;if(!t)return;
  $('#dTitle').innerHTML=esc(t.title)+`<div style="font-size:10.5px;color:var(--muted);font-weight:400">أُنشئت ${fmtWhen(t.created_at)}${t.src==='mail'?' · من البريد':''}</div>`;
  const em=t.email_id?E(t.email_id):null;
  $('#dBody').innerHTML=`
    <div class="frow">
      <div class="field"><label>الحالة</label><select id="dStatus">${statuses.map(([k,l])=>`<option value="${k}" ${t.status===k?'selected':''}>${l}</option>`).join('')}</select></div>
      <div class="field"><label>المسؤول</label><select id="dAssignee"><option value="">—</option>${S.members.map(m=>`<option value="${m.id}" ${t.assignee_id===m.id?'selected':''}>${esc(m.name)}</option>`).join('')}</select></div>
    </div>
    <div class="frow">
      <div class="field"><label>الأولوية</label><select id="dPrio">${[['p1','عالية'],['p2','متوسطة'],['p3','منخفضة']].map(([k,l])=>`<option value="${k}" ${t.prio===k?'selected':''}>${l}</option>`).join('')}</select></div>
    </div>
    <div class="frow">
      <div class="field"><label>المشروع</label><select id="dProj">${S.projects.map(p=>`<option value="${p.id}" ${t.project_id===p.id?'selected':''}>${esc(p.name)}</option>`).join('')}</select></div>
      <div class="field"><label>الاستحقاق</label><input type="date" id="dDue" value="${t.due||''}"></div>
    </div>
    <div class="field"><label>الوصف</label><textarea id="dDesc">${esc(t.descr||'')}</textarea></div>
    ${em?`<div class="ai-card"><div class="hdr">✉ مصدر المهمة: بريد وارد</div><p style="font-size:12.5px">من رسالة «${esc(em.subject)}» — <button class="btn ghost sm" onclick="closeDrawer();go('mail');openMail(${em.id})">فتح الرسالة والرد ←</button></p></div>`:''}
    <div class="field"><label>التعليقات (${t.comments.length})</label>
      <div>${t.comments.map(c=>`<div class="comment ${c.is_mail?'mailc':''}">${c.user_id?avatarEl(c.user_id,1):'<div class="avatar xs" style="background:#8A9199">✉</div>'}<div class="bubble"><span class="who">${esc(c.uname||'نظام البريد')}<span class="when">${fmtWhen(c.created_at)}</span>${c.is_mail?' <span class="chip blue">بريد</span>':''}</span><div style="font-size:12.5px;white-space:pre-line">${esc(c.body)}</div></div></div>`).join('')||'<div class="empty" style="padding:14px">لا تعليقات بعد</div>'}</div>
      <div style="display:flex;gap:8px;margin-top:8px"><input id="dNewComment" placeholder="أضف تعليقاً…" style="flex:1;border:1px solid var(--line);border-radius:8px;padding:8px 11px;outline:none"><button class="btn" onclick="addComment()">إضافة</button></div>
    </div>`;
  $('#taskDrawer').classList.add('open');
}
function closeDrawer(){$('#taskDrawer').classList.remove('open');curTask=null;}
async function saveTaskDrawer(){
  if(!curTask)return;
  await api('/tasks/'+curTask.id,'PATCH',{status:$('#dStatus').value,assignee_id:+$('#dAssignee').value||null,
    project_id:+$('#dProj').value,due:$('#dDue').value||null,descr:$('#dDesc').value,prio:$('#dPrio').value});
  toast('حُفظت التغييرات وتزامنت مع كل الأجهزة');closeDrawer();
}
async function addComment(){
  const v=$('#dNewComment').value.trim();if(!v||!curTask)return;
  const id=curTask.id;await api('/tasks/'+id+'/comments','POST',{body:v});
  await loadState();openDrawer(id);
}
async function delTask(){if(!curTask)return;
  if(!confirm('حذف مهمة «'+curTask.title+'»؟ ستنتقل لسلة المحذوفات 180 يوماً ويمكن استعادتها.'))return;
  const id=curTask.id;
  await api('/tasks/'+id,'DELETE');
  toast('حُذفت المهمة إلى سلة المحذوفات','تراجع',`restoreItem('task',${id})`);closeDrawer();}
function openTaskModal(){
  $('#ntProj').innerHTML=S.projects.filter(p=>p.status==='نشط').map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('');
  $('#ntAssignee').innerHTML=S.members.map(m=>`<option value="${m.id}" ${m.id===S.me.id?'selected':''}>${esc(m.name)}</option>`).join('');
  $('#ntTitle').value='';$('#ntDesc').value='';
  $('#ntDue').value=new Date(Date.now()+864e5).toISOString().slice(0,10);
  openModal('taskModal');setTimeout(()=>$('#ntTitle').focus(),50);
}
async function createTask(){
  const title=$('#ntTitle').value.trim();
  if(!title){toast('اكتب عنواناً للمهمة أولاً');return;}
  await api('/tasks','POST',{title,project_id:+$('#ntProj').value,assignee_id:+$('#ntAssignee').value,
    due:$('#ntDue').value,prio:$('#ntPrio').value,descr:$('#ntDesc').value});
  closeModal('taskModal');toast('أُنشئت المهمة وأُشعر المسؤول عنها');go('tasks');
}

/* ---------- المشاريع والمنتجات ---------- */
function renderProjects(){
  $('#projRows').innerHTML=S.projects.map(p=>{
    const pt=S.tasks.filter(t=>t.project_id===p.id),dn=pt.filter(t=>t.status==='done').length;
    const pct=pt.length?Math.round(dn/pt.length*100):0;
    const prod=S.products.find(x=>x.id===p.product_id);
    return `<tr class="click" onclick="$('#taskProjFilter').value='${p.id}';go('tasks');renderTasks()">
      <td><span style="display:inline-block;width:9px;height:9px;border-radius:3px;background:${p.color};margin-left:7px"></span><b>${esc(p.name)}</b>${isAllMode()&&S.tenants.length>1?` <span class="chip purple">${esc(TN(p.tenant_id).name)}</span>`:''}</td>
      <td>${prod?'<span class="chip purple">◈ '+esc(prod.name)+'</span>':'<span style="color:var(--muted)">—</span>'}</td>
      <td>${dn} / ${pt.length}</td>
      <td><div style="display:flex;align-items:center;gap:8px"><div class="progress"><i style="width:${pct}%"></i></div><span style="font-size:11.5px">${pct}%</span></div></td>
      <td><span class="chip ${p.status==='نشط'?'teal':'gray'}">${p.status}</span></td></tr>`;}).join('');
}
function renderProducts(){
  $('#prodCards').innerHTML=S.products.map(pr=>{
    const linked=S.projects.filter(p=>p.product_id===pr.id);
    const linkedTasks=S.tasks.filter(t=>linked.some(p=>p.id===t.project_id));
    return `<div class="card w-6">
      <h3>◈ ${esc(pr.name)} <span class="grow"></span><span class="chip teal">${esc(pr.status)}</span>
        <button class="btn sm ghost warn" onclick="delProduct(${pr.id},'${esc(pr.name)}')">حذف</button></h3>
      <div style="padding:13px 16px">
        <p style="font-size:12.5px;color:var(--muted);margin-bottom:10px">${esc(pr.descr)} · المالك: ${esc(M(pr.owner_id).name)}</p>
        <div style="font-size:12px;font-weight:700;margin-bottom:5px">الإصدارات</div>
        ${pr.releases.map(r=>`<div style="display:flex;gap:8px;align-items:center;font-size:12.5px;padding:4px 0"><span class="chip ${r.status==='صادر'?'gray':'amber'}">${esc(r.status)}</span> الإصدار ${esc(r.version)} <span style="color:var(--muted);font-size:11px">· ${fmtD(r.date)}</span></div>`).join('')||'<span style="font-size:12px;color:var(--muted)">لا إصدارات</span>'}
        <div style="font-size:12px;font-weight:700;margin:10px 0 5px">المشاريع المرتبطة (${linked.length}) · ${linkedTasks.length} مهمة</div>
        ${linked.map(p=>`<button class="btn sm" style="margin:0 0 6px 6px" onclick="$('#taskProjFilter').value='${p.id}';go('tasks');renderTasks()">${esc(p.name)} ←</button>`).join('')||'<span style="font-size:12px;color:var(--muted)">لا مشاريع مرتبطة</span>'}
      </div></div>`;}).join('');
}

/* ---------- البريد ---------- */
let curMail=null,mailTab='inbox';
const localDrafts={}; // تحرير محلي حتى لا يمسحه تحديث لحظي أثناء الكتابة
$('#mailTabs').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;
  mailTab=b.dataset.mt;document.querySelectorAll('#mailTabs button').forEach(x=>x.classList.toggle('on',x===b));renderMail();});
function openMail(id){curMail=id;mailTab='inbox';
  document.querySelectorAll('#mailTabs button').forEach(x=>x.classList.toggle('on',x.dataset.mt==='inbox'));renderMail();}
let draftTimer=null;
function draftInput(id,val){localDrafts[id]=val;clearTimeout(draftTimer);
  draftTimer=setTimeout(()=>api('/emails/'+id+'/draft','PATCH',{draft:val}).catch(()=>{}),800);}
function renderMail(){
  const inbox=S.emails.filter(e=>e.task_id||e.approved===null||e.approved===-1);
  if(curMail===null&&inbox.length)curMail=inbox[0].id;
  $('#mailInbox').style.display=mailTab==='inbox'?'grid':'none';
  $('#mailReview').style.display=mailTab==='review'?'block':'none';
  $('#mailSched').style.display=mailTab==='sched'?'block':'none';
  $('#revCount').textContent=S.review.length?`(${S.review.length})`:'';
  $('#schedCount').textContent=S.scheduled.length?`(${S.scheduled.length})`:'';
  const pending=inbox.filter(e=>!e.replied_at&&!S.scheduled.some(s=>s.email_id===e.id)).length;
  $('#mailBadge').textContent=pending;$('#mailBadge').style.display=pending?'':'none';

  $('#mailListEl').innerHTML=inbox.map(e=>`<div class="mailitem ${e.id===curMail?'on':''}" onclick="openMail(${e.id})">
    <div class="top"><b>${esc(e.from_name)}</b><time>${fmtWhen(e.received_at)}</time></div>
    <div class="sub">${esc(e.subject)}</div>
    <div class="prev">${esc((e.body||'').split('\n').filter(Boolean)[0]||'')}</div>
    <div style="margin-top:5px;display:flex;gap:5px">${e.mb_scope==='personal'?'<span class="chip purple">شخصي</span>':''}${e.approved===null&&!e.task_id?'<span class="chip purple">⏳ مسودة مهمة بانتظارك</span>':e.replied_at?'<span class="chip teal">✓ تم الرد</span>':S.scheduled.some(s=>s.email_id===e.id)?'<span class="chip amber">⏱ رد مجدول</span>':'<span class="chip blue">بانتظار الرد</span>'}</div></div>`).join('')
    ||'<div class="empty">لا رسائل بعد — جرّب «محاكاة بريد وارد» أو اربط صندوقاً حقيقياً من الإعدادات</div>';

  const e=E(curMail);
  if(!e){$('#mailDetail').innerHTML='<div class="card empty">اختر رسالة من القائمة</div>';}
  else{
    const sch=S.scheduled.find(s=>s.email_id===e.id);
    const draftVal=localDrafts[e.id]!==undefined?localDrafts[e.id]:(e.draft||'');
    $('#mailDetail').innerHTML=`
      ${e.approved===null&&!e.task_id?`<div class="ai-card" style="background:var(--purple-soft);border-color:#D7D0F0">
        <div class="hdr" style="color:var(--purple)">⏳ مسودة مهمة مقترحة من المحرك — اعتمدها أو ارفضها</div>
        <div class="frow" style="margin-top:8px">
          <div class="field" style="flex:2"><label>عنوان المهمة</label><input id="apTitle" value="${esc(e.proposed_title||e.subject)}"></div>
        </div>
        <div class="frow">
          <div class="field"><label>المشروع</label><select id="apProj">${S.projects.filter(p=>p.status==='نشط').map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('')}</select></div>
          <div class="field"><label>المسؤول (يُشعر فوراً)</label><select id="apAssignee"><option value="">—</option>${S.members.filter(m=>m.active).map(m=>`<option value="${m.id}" ${m.id===S.me.id?'selected':''}>${esc(m.name)}</option>`).join('')}</select></div>
        </div>
        <button class="btn pri sm" onclick="approveEmail(${e.id})">✓ اعتماد وإنشاء المهمة</button>
        <button class="btn sm" onclick="openLinkTask(${e.id})">🔗 ربط بمهمة قائمة</button>
        <button class="btn sm ghost warn" onclick="rejectEmail(${e.id})">رفض — لا مهمة</button>
      </div>`:''}
      ${e.approved===-1&&!e.task_id?`<div class="ai-card" style="background:#EEEDE7;border-color:var(--line)"><div class="hdr" style="color:var(--muted)">رُفضت مسودة المهمة — الرسالة محفوظة للرجوع</div><button class="btn sm" onclick="openLinkTask(${e.id})">🔗 ربطها بمهمة قائمة</button></div>`:''}
      <div class="ai-card">
        <div class="hdr">✦ الملخص الذكي <span class="chip teal" style="margin-right:auto">${S.devMode&&!window.AI_ON?'مولّد احتياطي (أضف مفتاح API للذكاء الكامل)':'Claude'}</span></div>
        <ul>${(e.summary||[]).map(s=>`<li>${esc(s)}</li>`).join('')}</ul>
      </div>
      <div class="mail-body">
        <div class="from"><div class="avatar" style="background:#2B5E9E">${ini(e.from_name)}</div>
          <div class="grow"><b>${esc(e.from_name)}</b> <span style="color:var(--muted);font-size:11.5px;direction:ltr;display:inline-block">&lt;${esc(e.from_email)}&gt;</span>
          <div style="font-size:11.5px;color:var(--muted)">${fmtWhen(e.received_at)}</div></div>
          ${e.task_id?`<button class="btn sm ghost" onclick="openDrawer(${e.task_id})">فتح المهمة المرتبطة ←</button><button class="btn sm ghost" onclick="openLinkTask(${e.id})" title="نقل الربط لمهمة أخرى">🔗</button>`:''}</div>
        <div style="white-space:pre-line">${esc(e.body)}</div>
        ${(e.attachments||[]).map(a=>`<a class="attach" href="/api/files/${a.id}/download" target="_blank">📎 ${esc(a.name)} <small style="color:var(--muted)">${fmtSize(a.size)}</small></a>`).join('')}
      </div>
      ${e.replied_at?`<div class="ai-card" style="background:#EFF7F1;border-color:#C4E0CC"><div class="hdr" style="color:#1E6B45">✓ أُرسل الرد ${fmtWhen(e.replied_at)}</div><p style="font-size:12.5px">الرد موثّق كتعليق على المهمة المرتبطة${S.devMode?' (وضع تطوير — الإرسال محاكى)':' ووصل ضمن نفس سلسلة المحادثة'}.</p></div>`:''}
      ${sch?`<div class="ai-card" style="background:var(--amber-soft);border-color:#EBD9B4"><div class="hdr" style="color:var(--amber)">⏱ رد مجدول — ${esc(sch.send_at)}</div><p style="font-size:12.5px">عدّله أو ألغه من تبويب «الردود المجدولة» قبل موعده.</p></div>`:''}
      ${!e.replied_at&&!sch?`
      <div class="reply-box">
        <div class="rb-head">✦ مسودة رد ذكية — عدّلها بحرية ثم أرسل أو جدول</div>
        <textarea id="replyText" oninput="draftInput(${e.id},this.value)">${esc(draftVal)}</textarea>
        <div class="rb-foot">
          <button class="btn pri" onclick="sendReply(${e.id})">إرسال الآن</button>
          <button class="btn" onclick="$('#schDate').value=new Date(Date.now()+864e5).toISOString().slice(0,10);openModal('schedModal')">⏱ جدولة الإرسال</button>
          <button class="btn ghost" onclick="regenDraft(${e.id})">↺ توليد مسودة جديدة</button>
          <span class="grow"></span><span style="font-size:11px;color:var(--muted)">حفظ تلقائي</span>
        </div>
      </div>`:''}`;
  }

  $('#mailReview').innerHTML=`<table class="tbl"><thead><tr><th>المرسل</th><th>العنوان</th><th>سبب عدم التحويل</th><th style="width:220px"></th></tr></thead><tbody>${
    S.review.map(r=>`<tr><td style="direction:ltr;text-align:right">${esc(r.from_email)}</td><td>${esc(r.subject)}</td><td style="color:var(--muted);font-size:12px">${esc(r.reason)}</td>
    <td style="text-align:left"><button class="btn sm pri" onclick="reviewToTask(${r.id})">تحويل لمهمة</button> <button class="btn sm" onclick="reviewIgnore(${r.id})">تجاهل</button></td></tr>`).join('')||
    '<tr><td colspan="4" class="empty">قائمة المراجعة فارغة — كل الرسائل صُنفت تلقائياً ✓</td></tr>'}</tbody></table>`;

  $('#mailSched').innerHTML=S.scheduled.length?S.scheduled.map(s=>`<div class="sched-row">
    <span class="chip amber">⏱ ${esc(s.send_at)}</span>
    <div class="grow"><b>${esc(s.subject)}</b><div style="font-size:11.5px;color:var(--muted)">إلى: <span style="direction:ltr;display:inline-block">${esc(s.to_email)}</span> · ${esc((s.body||'').slice(0,60))}…</div></div>
    <button class="btn sm" onclick="openMail(${s.email_id});cancelSchedule(${s.id},1)">تعديل</button>
    <button class="btn sm warn" onclick="cancelSchedule(${s.id})">إلغاء الجدولة</button></div>`).join(''):
    '<div class="empty">لا ردود مجدولة — جدول رداً من أي رسالة في الوارد</div>';
}
async function sendReply(id){
  const body=$('#replyText').value;
  const r=await api('/emails/'+id+'/send','POST',{body});
  delete localDrafts[id];
  const e=E(id);
  toast(r.dev?'أُرسل الرد (وضع تطوير — محاكى) ووثّق على المهمة':'أُرسل الرد ✓ ووثّق كتعليق على المهمة','فتح المهمة ←',`openDrawer(${e.task_id})`);
}
async function confirmSchedule(){
  const dt=$('#schDate').value,tm=$('#schTime').value;
  if(!dt){toast('حدد تاريخ الإرسال');return;}
  const body=$('#replyText')?$('#replyText').value:undefined;
  await api('/emails/'+curMail+'/schedule','POST',{send_at:dt+' '+tm+':00',body});
  delete localDrafts[curMail];
  closeModal('schedModal');toast('جُدول الإرسال — '+dt+' الساعة '+tm);
}
async function cancelSchedule(id,silent){await api('/scheduled/'+id,'DELETE');
  if(!silent)toast('أُلغيت الجدولة — المسودة ما زالت محفوظة');}
async function regenDraft(id){
  toast('يولّد الذكاء الاصطناعي مسودة جديدة…');
  delete localDrafts[id];
  const r=await api('/emails/'+id+'/regenerate','POST',{});
  if(r.engine==='claude')window.AI_ON=true;
}
async function reviewToTask(id){const r=await api('/review/'+id+'/convert','POST',{});
  toast('حُولت لمهمة','عرض ←',`openDrawer(${r.task_id})`);}
async function reviewIgnore(id){await api('/review/'+id,'DELETE');toast('تُجوهلت الرسالة');}
async function simulateEmail(){
  $('#simGo').disabled=true;$('#simGo').textContent='يعالج… (تحليل ← تلخيص ← مهمة)';
  try{
    const r=await api('/dev/simulate-email','POST',{mailbox_id:+$('#simMailbox').value||null,from_name:$('#simName').value,from_email:$('#simEmail').value,
      subject:$('#simSubject').value,body:$('#simBody').value});
    closeModal('simModal');
    toast(r.task_id?'عولجت الرسالة: ملخص ذكي + مسودة رد + مهمة جديدة':'وصلت الرسالة — بانتظار توجيه صاحب الصندوق','فتح البريد ←',"go('mail')");
  }finally{$('#simGo').disabled=false;$('#simGo').textContent='إرسال للمعالجة';}
}

/* ---------- الدردشة ---------- */
let curChan=null;
function chanUnread(c){
  const last=(S.reads&&S.reads[c.id])||0;
  return S.messages.filter(m=>m.channel_id===c.id&&m.id>last&&m.user_id!==S.me.id).length;
}
function markChanRead(id){
  const has=S.messages.some(m=>m.channel_id===id&&m.id>((S.reads&&S.reads[id])||0)&&m.user_id!==S.me.id);
  S.reads=S.reads||{};const mx=Math.max(0,...S.messages.filter(m=>m.channel_id===id).map(m=>m.id));
  S.reads[id]=mx;
  if(has)api('/channels/'+id+'/read','POST',{}).catch(()=>{});
}
function renderChat(){
  if(curChan===null&&S.channels.length)curChan=S.channels[0].id;
  const inChat=$('#view-chat').classList.contains('on');
  if(inChat&&curChan)markChanRead(curChan);
  const totalUnread=S.channels.reduce((a,c)=>a+chanUnread(c),0);
  $('#chatBadge').textContent=totalUnread;$('#chatBadge').style.display=totalUnread?'':'none';
  const chanBtn=c=>{const nm=(c.is_dm?('· '+esc(M(c.dm_a===S.me.id?c.dm_b:c.dm_a).name)):esc(c.name))+(!c.is_dm&&isAllMode()&&S.tenants.length>1?` <span style="font-size:10px;color:var(--muted)">${esc(TN(c.tenant_id).name)}</span>`:'');
    const u=chanUnread(c);
    return `<button class="chan ${c.id===curChan?'on':''}" onclick="curChan=${c.id};markChanRead(${c.id});renderChat()">${nm}${u?`<span class="badge">${u}</span>`:''}</button>`;};
  $('#chanList').innerHTML='<h3>القنوات <span class="grow"></span><button class="lnk" style="font-size:12px;color:var(--accent-ink)" onclick="openModal(\'chanModal\')">+ قناة</button></h3>'+S.channels.filter(c=>!c.is_dm).map(chanBtn).join('')
    +'<h3>رسائل مباشرة <span class="grow"></span><button class="lnk" style="font-size:12px;color:var(--accent-ink)" onclick="openDm()">+ محادثة</button></h3>'+(S.channels.filter(c=>c.is_dm).map(chanBtn).join('')||'<div class="empty" style="padding:12px">لا محادثات مباشرة</div>');
  const ch=S.channels.find(c=>c.id===curChan);if(!ch)return;
  $('#chanTitle').innerHTML=(ch.is_dm?'محادثة مباشرة · '+esc(M(ch.dm_a===S.me.id?ch.dm_b:ch.dm_a).name):esc(ch.name))
    +'<span class="grow"></span><span style="font-size:11px;color:var(--muted);font-weight:400">لحظي عبر WebSocket</span>';
  const msgs=S.messages.filter(m=>m.channel_id===curChan);
  $('#msgs').innerHTML=msgs.map(m=>`
    <div class="msg ${m.user_id===S.me.id?'mine':''}">${avatarEl(m.user_id)}<div class="body">
      <div class="who">${esc(m.uname)} <time>${fmtWhen(m.created_at)}</time></div>
      <div class="txt">${esc(m.body)}</div>
      ${m.task_id?`<span class="tasklink" onclick="openDrawer(${m.task_id})">☑ تحوّلت لمهمة — فتح ←</span>`:''}
    </div><div class="acts">
      ${m.task_id?'':`<button onclick="msgToTask(${m.id})">☑ تحويل لمهمة</button>`}
    </div></div>`).join('')||'<div class="empty">لا رسائل بعد — ابدأ الحوار</div>';
  $('#msgs').scrollTop=$('#msgs').scrollHeight;
}
async function sendMsg(){
  const v=$('#msgInput').value.trim();if(!v||!curChan)return;
  $('#msgInput').value='';
  await api('/messages','POST',{channel_id:curChan,body:v});
  if(v.includes('@'))toast('أُشعر العضو المُشار إليه فوراً');
}
$('#msgInput').addEventListener('keydown',e=>{if(e.key==='Enter')sendMsg();});
async function msgToTask(id){const r=await api('/messages/'+id+'/task','POST',{});
  toast('تحوّلت الرسالة لمهمة وربطت بالمحادثة','فتح ←',`openDrawer(${r.task_id})`);}

/* ---------- الملفات ---------- */
$('#fileFilter').addEventListener('change',renderFiles);
const srcLabel={mail:'✉ مرفق بريد',task:'☑ مرفق مهمة',upload:'↥ رفع مباشر'};
const extColor={pdf:'#B3372F',png:'#2B5E9E',jpg:'#2B5E9E',fig:'#5B4BAE',xlsx:'#1E8E5A',docx:'#2B5E9E',pptx:'#A16207'};
function renderFiles(){
  const f=$('#fileFilter').value;
  const q=($('#fileSearch')?.value||'').trim();
  const list=S.files.filter(x=>(!f||x.src===f)&&(!q||x.name.includes(q)));
  $('#filesGrid').innerHTML=list.map(fl=>{
    const ext=(fl.name.split('.').pop()||'').toLowerCase();
    return `<div class="card fcard" onclick="window.open('/api/files/${fl.id}/download')">
    <div class="fic" style="background:${extColor[ext]||'#5F5E5A'}">${esc(ext.toUpperCase().slice(0,4)||'ملف')}</div>
    <b>${esc(fl.name)}</b><small>${fmtSize(fl.size)} · ${esc(fl.uname||'نظام البريد')} · ${fmtWhen(fl.created_at)}</small>
    <div class="facts"><span class="chip gray">${srcLabel[fl.src]||fl.src}</span><span class="grow"></span>
      <button class="btn sm ghost" onclick="event.stopPropagation();openShare(${fl.id})">مشاركة</button>
      <button class="btn sm ghost warn" title="حذف (سلة المحذوفات)" onclick="event.stopPropagation();delFile(${fl.id},'${esc(fl.name)}')">🗑</button></div>
  </div>`;}).join('')||'<div class="empty card" style="grid-column:1/-1">لا ملفات من هذا المصدر — ارفع أول ملف</div>';
}
let shareFileId=null;
function openShare(id){shareFileId=id;
  $('#shareName').textContent=S.files.find(f=>f.id===id).name;
  $('#shareLink').value='';updShareLink();openModal('shareModal');}
document.addEventListener('change',e=>{if(e.target.id==='shareType')updShareLink();});
async function updShareLink(){
  const pub=$('#shareType').value==='pub';
  const r=await api('/files/'+shareFileId+'/share','POST',{type:pub?'pub':'in'});
  $('#shareLink').value=location.origin+r.url+(pub?'  (تنتهي بعد 7 أيام)':'  (للأعضاء فقط)');
}
function copyLink(){$('#shareLink').select();navigator.clipboard?.writeText($('#shareLink').value.split('  ')[0]);toast('نُسخ الرابط');}
function fakeUpload(){
  const inp=document.createElement('input');inp.type='file';
  inp.onchange=async()=>{
    if(!inp.files[0])return;
    const fd=new FormData();fd.append('file',inp.files[0]);
    await api('/files','POST',fd,true);
    toast('رُفع الملف وظهر لكل الأعضاء فوراً');
  };inp.click();
}

/* ---------- الإعدادات ---------- */
const roleOpts=['admin','member','viewer'];
function renderSettings(){
  $('#mailboxRows').innerHTML=S.mailboxes.map(m=>`<div class="mailbox-row">
    <span class="st ${m.status==='ok'?'ok':m.status==='dev'?'warn':'err'}" style="width:9px;height:9px;border-radius:50%"></span>
    <div class="grow"><div style="direction:ltr;text-align:right;font-weight:500">${esc(m.email)}</div>
      <div style="font-size:11.5px;color:${m.status==='err'?'var(--danger)':'var(--muted)'}">${m.status==='dev'?'صندوق تجريبي — استخدم «محاكاة بريد وارد»':m.status==='err'?('فشل الاتصال: '+esc(m.last_error||'')+' — إعادة محاولة تلقائية'):('آخر مزامنة '+fmtWhen(m.last_sync))} · ${m.processed} رسالة معالجة</div></div>
    <span class="chip ${m.scope==='personal'?'purple':'teal'}">${m.scope==='personal'?('شخصي · '+esc((m.owner_name||'').split(' ')[0])):'فريق'}</span>
    <code>${m.is_import?'استيراد':m.proto}${m.auth_type==='oauth_ms'?' · MS':''}</code>
    <button class="btn sm" onclick="editMailbox(${m.id})">تعديل</button>
    ${m.auth_type==='oauth_ms'&&!m.ms_linked?`<button class="btn sm pri" onclick="msConnect(${m.id})">ربط الحساب</button>`:''}
    ${m.status!=='dev'?`<button class="btn sm" onclick="api('/mailboxes/${m.id}/sync','POST',{}).then(()=>toast('اكتملت المزامنة ✓'))">↺ مزامنة</button>`:''}
    <button class="btn sm warn" onclick="if(confirm('إزالة هذا الصندوق؟'))api('/mailboxes/${m.id}','DELETE')">إزالة</button>
  </div>`).join('');
  if(isAllMode()&&S.tenants.length>1){
    $('#memberRows').innerHTML='<tr><td class="empty">بدّل من القائمة العلوية لجهة محددة لإدارة أعضائها وأدوارهم</td></tr>';
  } else $('#memberRows').innerHTML=S.members.map(m=>`<tr style="${m.active?'':'opacity:.5'}"><td style="width:40px">${avatarEl(m.id,1)}</td>
    <td>${esc(m.name)}<div style="font-size:10.5px;color:var(--muted);direction:ltr;text-align:right">${esc(m.email)}</div></td>
    <td style="width:120px">${m.role==='owner'?'<span class="chip teal">مالك</span>':`<select onchange="api('/members/${m.id}','PATCH',{role:this.value}).then(()=>toast('تغيّرت الصلاحية — سُجّل في سجل التدقيق'))">
      ${roleOpts.map(r=>`<option value="${r}" ${m.role===r?'selected':''}>${roleAr[r]}</option>`).join('')}</select>`}</td>
    <td style="width:110px">${m.role==='owner'?'':`<button class="btn sm warn" title="إزالة من هذه الجهة فقط" onclick="if(confirm('إزالة ${esc(m.name)} من هذه الجهة؟ حسابه يبقى في جهاته الأخرى.'))api('/members/${m.id}','PATCH',{remove:true})">إزالة</button>`}</td></tr>`).join('');
  $('#notifPrefs').innerHTML=['إسناد مهمة إليّ','اقتراب أو تجاوز موعد استحقاق','إشارة (@) باسمي','تعليق على مهمة أتابعها','رسالة مباشرة جديدة'].map(n=>
    `<label style="display:flex;gap:9px;align-items:center;font-size:13px;padding:6px 0"><input type="checkbox" checked> ${n} <span class="grow"></span><span class="chip gray">داخلي + جوال (قادم)</span></label>`).join('');
}
function mbProtoHint(){$('#mbHint').style.display=$('#mbProto').value==='POP3'?'block':'none';
  $('#mbPort').placeholder=$('#mbProto').value==='IMAP'?'993':'995';}
let detectBusy=false;
async function autoDetect(force){
  const em=$('#mbEmail').value.trim();
  if(!em.includes('@')||detectBusy)return;
  if(!force&&($('#mbHost').value||editMbId))return; // لا نعيد الاكتشاف فوق إعدادات قائمة إلا بطلب صريح
  detectBusy=true;const box=$('#mbDetect');
  box.style.display='';box.style.background='var(--bg)';box.style.color='var(--muted)';box.textContent='🔍 نفحص مستضيف '+em.split('@')[1]+'…';
  try{
    const r=await api('/mail-autodetect?email='+encodeURIComponent(em));
    if(r.host){
      $('#mbProto').value=r.proto||'IMAP';$('#mbHost').value=r.host;$('#mbPort').value=r.port||993;
      $('#mbSmtpHost').value=r.smtp_host||'';$('#mbSmtpPort').value=r.smtp_port||587;
      if(!$('#mbUser').value)$('#mbUser').value=em;
      $('#mbAuth').value=r.auth_type||'password';mbAuthHint();mbProtoHint();
    }
    box.style.background=r.found?'var(--accent-soft)':'var(--amber-soft)';
    box.style.color=r.found?'var(--accent-ink)':'var(--amber)';
    box.innerHTML=(r.found?('✓ '+esc(r.provider||'')+' — '):'')+esc(r.note||'');
  }catch(e){box.style.display='none';}
  detectBusy=false;
}
let editMbId=null;
function openMailboxModal(){
  editMbId=null;$('#mbTitle').textContent='ربط صندوق بريد جديد';$('#mbSaveBtn').textContent='اختبار الاتصال والربط';
  ['mbEmail','mbHost','mbPort','mbUser','mbPass','mbSmtpHost','mbMsId','mbMsSecret'].forEach(id=>$('#'+id).value='');
  $('#mbSmtpPort').value='587';$('#mbMsTenant').value='common';$('#mbAuth').value='password';$('#mbProto').value='IMAP';
  $('#mbDetect').style.display='none';$('#mbPass').placeholder='••••••••';$('#mbScope').value='team';$('#mbScope').disabled=false;mbScopeHint();mbAuthHint();mbProtoHint();openModal('mailboxModal');
}
function editMailbox(id){
  const m=S.mailboxes.find(x=>x.id===id);if(!m)return;
  editMbId=id;$('#mbTitle').textContent='تعديل صندوق: '+m.email;$('#mbSaveBtn').textContent='حفظ التعديلات وإعادة الاختبار';
  $('#mbEmail').value=m.email;$('#mbProto').value=m.proto;$('#mbHost').value=m.host||'';$('#mbPort').value=m.port||'';
  $('#mbUser').value=m.username||'';$('#mbPass').value='';$('#mbPass').placeholder='اتركها فارغة للإبقاء على الحالية';
  $('#mbSmtpHost').value=m.smtp_host||'';$('#mbSmtpPort').value=m.smtp_port||'587';
  $('#mbAuth').value=m.auth_type||'password';$('#mbMsId').value=m.ms_client_id||'';$('#mbMsSecret').value='';
  $('#mbMsSecret').placeholder='اتركه فارغاً للإبقاء على الحالي';
  $('#mbMsTenant').value=m.ms_tenant||'common';
  $('#mbScope').value=m.scope||'team';$('#mbScope').disabled=!['owner','admin'].includes(S.me.role);
  mbScopeHint();mbAuthHint();mbProtoHint();
  $('#mbProject').value=m.default_project_id||'';
  openModal('mailboxModal');
}
async function addMailbox(){
  const isMs=$('#mbAuth').value==='oauth_ms';
  await api(editMbId?'/mailboxes/'+editMbId:'/mailboxes',editMbId?'PATCH':'POST',{email:$('#mbEmail').value.trim(),proto:$('#mbProto').value,
    host:$('#mbHost').value.trim(),port:+$('#mbPort').value||null,username:$('#mbUser').value.trim()||$('#mbEmail').value.trim(),
    password:$('#mbPass').value,smtp_host:$('#mbSmtpHost').value.trim(),smtp_port:+$('#mbSmtpPort').value||587,
    default_project_id:+$('#mbProject').value||null,auth_type:$('#mbAuth').value,scope:$('#mbScope').value,
    ms_client_id:isMs?$('#mbMsId').value.trim():null,ms_client_secret:isMs?$('#mbMsSecret').value:null,ms_tenant:isMs?$('#mbMsTenant').value.trim()||'common':null});
  closeModal('mailboxModal');
  toast(editMbId?'حُفظت التعديلات وأُعيد اختبار الاتصال — راقب حالة الصندوق':(isMs?'أُضيف الصندوق — اضغط «ربط الحساب» بجانبه لإكمال تفويض مايكروسوفت':'أُضيف الصندوق وبدأ اختبار الاتصال — راقب حالته في القائمة'));
  editMbId=null;
}

/* ---------- الإشعارات والبحث ---------- */
$('#bellBtn').addEventListener('click',e=>{e.stopPropagation();$('#notifPop').classList.toggle('open');});
document.addEventListener('click',e=>{if(!e.target.closest('#notifPop')&&!e.target.closest('#bellBtn'))$('#notifPop').classList.remove('open');
  if(!e.target.closest('.search'))$('#searchPop').classList.remove('open');});
function renderNotifs(){
  $('#bellDot').style.display=S.notifications.some(n=>!n.is_read)?'':'none';
  $('#notifList').innerHTML=S.notifications.map(n=>`<div class="rowitem" style="cursor:default;${n.is_read?'opacity:.55':''}">
    <span style="width:7px;height:7px;border-radius:50%;background:${n.is_read?'transparent':'var(--accent)'};flex:none"></span>
    <div class="grow"><div style="font-size:12.5px">${esc(n.body)}</div><div class="sub">${fmtWhen(n.created_at)}</div></div></div>`).join('')
    ||'<div class="empty">لا إشعارات</div>';
}
function markAllRead(){api('/notifications/read','POST',{});}
let searchTimer=null;
$('#searchInput').addEventListener('input',function(){
  const q=this.value.trim();const pop=$('#searchPop');
  if(q.length<2){pop.classList.remove('open');return;}
  clearTimeout(searchTimer);
  searchTimer=setTimeout(async()=>{
    const r=await api('/search?q='+encodeURIComponent(q));
    let html='';
    if(r.tasks.length)html+='<div class="grp">مهام</div>'+r.tasks.map(t=>`<button class="hit" onclick="openDrawer(${t.id});$('#searchPop').classList.remove('open')">☑ ${esc(t.title)}</button>`).join('');
    if(r.projects.length)html+='<div class="grp">مشاريع</div>'+r.projects.map(p=>`<button class="hit" onclick="go('projects');$('#searchPop').classList.remove('open')">▤ ${esc(p.name)}</button>`).join('');
    if(r.emails.length)html+='<div class="grp">بريد</div>'+r.emails.map(e=>`<button class="hit" onclick="go('mail');openMail(${e.id});$('#searchPop').classList.remove('open')">✉ ${esc(e.subject)} — ${esc(e.from_name)}</button>`).join('');
    if(r.files.length)html+='<div class="grp">ملفات</div>'+r.files.map(f=>`<button class="hit" onclick="go('files');$('#searchPop').classList.remove('open')">▣ ${esc(f.name)}</button>`).join('');
    if(r.events&&r.events.length)html+='<div class="grp">تقويم</div>'+r.events.map(e=>`<button class="hit" onclick="go('calendar');$('#searchPop').classList.remove('open')">▦ ${esc(e.title)} <span style="color:var(--muted);font-size:11px">${e.starts_at.slice(0,10)}</span></button>`).join('');
    if(r.messages.length)html+='<div class="grp">دردشة</div>'+r.messages.map(m=>`<button class="hit" onclick="go('chat');curChan=${m.channel_id};renderChat();$('#searchPop').classList.remove('open')">💬 ${esc(m.body.slice(0,60))}</button>`).join('');
    pop.innerHTML=html||'<div class="empty" style="padding:16px">لا نتائج</div>';
    pop.classList.add('open');
  },250);
});

/* ---------- التشغيل ---------- */
function renderAll(){
  if(!S)return;
  const sel=$('#tenantSel');
  sel.innerHTML='<option value="all">◈ كل الجهات — لوحة موحدة</option>'+S.tenants.map(t=>`<option value="${t.id}">${esc(t.name)}</option>`).join('');
  sel.value=S.curTenant||'all';
  $('#newTenantBtn').style.display=S.me.super?'':'none';
  $('#membersTenantChip').textContent=isAllMode()?'':TN(S.curTenant).name;
  renderDashboard();renderTasks();renderProjects();renderProducts();renderMail();renderChat();renderFiles();renderSettings();renderNotifs();renderCalendar();renderBookingCard();renderTrash();
  $('#mbProject').innerHTML=S.projects.filter(p=>p.status==='نشط').map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('');
  $('#simMailbox').innerHTML=S.mailboxes.map(m=>`<option value="${m.id}">${esc(m.email)} — ${m.scope==='personal'?'شخصي':'فريق'}</option>`).join('');
  $('#pjProduct').innerHTML='<option value="">— بدون منتج —</option>'+S.products.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('');
  // بطاقة بريد النظام (للمدراء) — لا نلمس الحقول أثناء كتابة المستخدم
  const adm=['owner','admin'].includes(S.me.role);
  $('#sysMailCard').style.display=adm?'':'none';
  if(adm&&document.activeElement.closest?.('#sysMailCard')==null){
    $('#smHost').value=S.systemMail.host||'';$('#smPort').value=S.systemMail.port||'587';
    $('#smUser').value=S.systemMail.user||'';$('#smFrom').value=S.systemMail.from||'';
    $('#smBase').value=S.baseUrl||'';$('#smEnabled').checked=!!S.systemMail.enabled;$('#smUploadMax').value=S.systemMail.upload_max_mb??0;
  }
  $('#sysMailStatus').className='chip '+(S.systemMail.configured?'teal':'gray');
  $('#sysMailStatus').textContent=S.devMode?'وضع تطوير — الإرسال محاكى':(S.systemMail.configured?'مهيأ ✓':'غير مهيأ');
  $('#aiCard').style.display=adm?'':'none';
  if(adm&&document.activeElement.closest?.('#aiCard')==null){
    $('#aiProvider').value=S.ai.provider;aiProviderHint();
    $('#aiModel').value=S.ai.provider==='anthropic'?(S.ai.model||''):'';
    $('#aiModel2').value=S.ai.provider==='custom'?(S.ai.model||''):'';
    $('#aiBase').value=S.ai.baseUrl||'';$('#mailMode').value=S.mailTaskMode;
  }
  $('#aiStatus').className='chip '+((S.ai.provider==='anthropic'&&S.ai.keySet)||(S.ai.provider==='custom'&&S.ai.baseUrl)?'teal':'gray');
  $('#aiStatus').textContent=S.ai.provider==='off'?'احتياطي مدمج':((S.ai.provider==='anthropic'&&!S.ai.keySet)?'يحتاج مفتاحاً':'جاهز ✓');
  if(curTask){const fresh=T(curTask.id);if(fresh&&$('#taskDrawer').classList.contains('open')&&document.activeElement.tagName!=='INPUT'&&document.activeElement.tagName!=='TEXTAREA'&&document.activeElement.tagName!=='SELECT'){curTask=fresh;}}
}
(async()=>{
  if(TOKEN){
    try{$('#loginWrap').style.display='none';connectSocket();await loadState();}
    catch(e){logout(true);}
  }
})();

/* ==================== v0.2: التقويم الموحد ==================== */
let calOffset=0;
function calShift(d){calOffset+=d;renderCalendar();}
const evColor=e=>e.source==='booking'?'bk':'ev';
function evTime(iso){const d=new Date(iso);return d.toLocaleTimeString('ar',{hour:'2-digit',minute:'2-digit'});}
function evDay(iso){return String(iso).slice(0,10);}
function renderCalendar(){
  if(!document.querySelector('#calGrid'))return;
  const base=new Date();base.setDate(1);base.setMonth(base.getMonth()+calOffset);
  const y=base.getFullYear(),m=base.getMonth();
  $('#calTitle').textContent=base.toLocaleDateString('ar',{month:'long',year:'numeric'});
  const first=new Date(y,m,1),start=new Date(first);start.setDate(1-first.getDay());
  const todayStr=new Date().toISOString().slice(0,10);
  // تجميع العناصر باليوم
  const byDay={};
  const add=(d,item)=>{(byDay[d]=byDay[d]||[]).push(item);};
  for(const e of (S.events||[])) add(evDay(e.starts_at),{t:'e',e});
  for(const t of S.tasks) if(t.due&&t.status!=='done') add(t.due,{t:'t',e:t});
  const dows=['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
  let html=dows.map(d=>`<div class="cal-dow">${d}</div>`).join('');
  for(let i=0;i<42;i++){
    const d=new Date(start);d.setDate(start.getDate()+i);
    const ds=d.toISOString().slice(0,10);
    const items=(byDay[ds]||[]).slice(0,3);
    const more=(byDay[ds]||[]).length-3;
    html+=`<div class="cal-cell ${d.getMonth()!==m?'dim':''} ${ds===todayStr?'today':''}" onclick="calDayClick('${ds}')">
      <div class="dn">${d.getDate()}</div>
      ${items.map(it=>it.t==='e'
        ?`<div class="cal-item ${evColor(it.e)}" title="${esc(it.e.title)}">${it.e.all_day?'':evTime(it.e.starts_at)+' '}${esc(it.e.title)}</div>`
        :`<div class="cal-item tk ${isLate(it.e.due)?'late':''}" title="${esc(it.e.title)}">☑ ${esc(it.e.title)}</div>`).join('')}
      ${more>0?`<div style="color:var(--muted)">+${more} أخرى</div>`:''}
    </div>`;
  }
  $('#calGrid').innerHTML=html;
  // القادم 14 يوماً
  const horizon=new Date(Date.now()+14*864e5);
  const up=[];
  for(const e of (S.events||[])){const d=new Date(e.starts_at);if(d>=new Date(Date.now()-36e5)&&d<=horizon)up.push({when:e.starts_at,html:
    `<div class="up-item"><span class="chip ${e.source==='booking'?'amber':'teal'}">${e.source==='booking'?'حجز':'اجتماع'}</span>
     <time>${new Date(e.starts_at).toLocaleDateString('ar',{weekday:'long',day:'numeric',month:'long'})} · ${e.all_day?'كل اليوم':evTime(e.starts_at)}</time>
     <div class="grow">${esc(e.title)}${e.location?' · '+esc(e.location):''}${e.attendee_email?' · <span style="direction:ltr;display:inline-block">'+esc(e.attendee_email)+'</span>':''}${e.organizer?' · من '+esc(e.organizer):''}</div>
     ${e.source!=='ics'?`<button class="btn sm warn" onclick="delEvent(${e.id})">حذف</button>`:''}</div>`});}
  for(const t of S.tasks){if(t.due&&t.status!=='done'&&t.due<=horizon.toISOString().slice(0,10))up.push({when:t.due+'T23:59',html:
    `<div class="up-item"><span class="chip blue">مهمة</span><time class="${isLate(t.due)?'due late':''}">${fmtD(t.due)}</time>
     <div class="grow" style="cursor:pointer" onclick="openDrawer(${t.id})">${esc(t.title)}</div></div>`});}
  up.sort((a,b)=>a.when<b.when?-1:1);
  $('#upList').innerHTML=up.map(u=>u.html).join('')||'<div class="empty">لا شيء قادم — أسبوعان هادئان 🎉</div>';
}
function calDayClick(ds){openEventModal();$('#evDate').value=ds;}
function openEventModal(){$('#evTitle').value='';$('#evDate').value=new Date().toISOString().slice(0,10);openModal('eventModal');setTimeout(()=>$('#evTitle').focus(),50);}
async function createEvent(){
  const t=$('#evTitle').value.trim();if(!t){toast('اكتب عنوان الحدث');return;}
  const d=$('#evDate').value;
  await api('/events','POST',{title:t,starts_at:d+'T'+$('#evStart').value+':00',ends_at:d+'T'+$('#evEnd').value+':00',location:$('#evLoc').value});
  closeModal('eventModal');toast('أُضيف للتقويم');go('calendar');
}
async function delEvent(id){await api('/events/'+id,'DELETE');toast('حُذف من التقويم');}

/* ==================== الدعوات والملف الشخصي ==================== */
function openInvite(){
  if(isAllMode()&&S.tenants.length>1){toast('بدّل لجهة محددة من القائمة العلوية ثم ادعُ العضو إليها');return;}$('#invForm').style.display='';$('#invResult').style.display='none';$('#invGo').style.display='';
  $('#invName').value='';$('#invEmail').value='';openModal('inviteModal');}
async function sendInvite(){
  const r=await api('/members/invite','POST',{name:$('#invName').value.trim(),email:$('#invEmail').value.trim(),role:$('#invRole').value});
  $('#invForm').style.display='none';$('#invGo').style.display='none';$('#invResult').style.display='';
  $('#invLink').value=r.link;
  $('#invMailNote').textContent=S.systemMail.configured&&!S.devMode?'وأُرسلت الدعوة أيضاً على بريده تلقائياً.':'(بريد النظام غير مفعّل بعد — أرسل الرابط بنفسك)';
}
function copyInvLink(){$('#invLink').select();navigator.clipboard?.writeText($('#invLink').value);toast('نُسخ رابط الدعوة');}
function openProfile(ev){if(ev)ev.stopPropagation();$('#pfName').value=S.me.name;
  $('#pfNotify').checked=!!S.members.find(m=>m.id===S.me.id)?.notify_email;openModal('profileModal');}
async function saveProfile(){
  await api('/me','PATCH',{name:$('#pfName').value.trim(),notify_email:$('#pfNotify').checked});
  toast('حُفظ ملفك الشخصي');
}
async function changePassword(){
  const n=$('#pfNew').value;
  if(n.length<8){toast('كلمة المرور الجديدة 8 أحرف على الأقل');return;}
  if(n!==$('#pfNew2').value){toast('الكلمتان غير متطابقتين');return;}
  await api('/me/password','POST',{current:$('#pfCur').value,newpass:n});
  $('#pfCur').value='';$('#pfNew').value='';$('#pfNew2').value='';
  toast('تغيّرت كلمة مرورك ✓');
}

/* ==================== مشاريع ومنتجات ==================== */
function prepProjectModal(){
  const f=$('#pjTenantField');
  if(isAllMode()&&S.tenants.length>1){f.style.display='';
    $('#pjTenant').innerHTML=S.tenants.filter(t=>t.my_role!=='viewer').map(t=>`<option value="${t.id}">${esc(t.name)}</option>`).join('');}
  else f.style.display='none';
}
async function createProject(){
  const n=$('#pjName').value.trim();if(!n){toast('اكتب اسم المشروع');return;}
  await api('/projects','POST',{name:n,color:$('#pjColor').value,product_id:+$('#pjProduct').value||null,tenant_id:isAllMode()?+$('#pjTenant').value||null:null});
  $('#pjName').value='';closeModal('projectModal');toast('أُنشئ المشروع');
}
async function createProduct(){
  const n=$('#prName').value.trim();if(!n){toast('اكتب اسم المنتج');return;}
  await api('/products','POST',{name:n,descr:$('#prDesc').value});
  $('#prName').value='';$('#prDesc').value='';closeModal('productModal');toast('أُضيف المنتج');
}

/* ==================== بريد النظام + الحجز ==================== */
async function saveSystemMail(){
  await api('/system-smtp','POST',{host:$('#smHost').value.trim(),port:+$('#smPort').value||587,
    user:$('#smUser').value.trim(),pass:$('#smPass').value,from:$('#smFrom').value.trim(),
    base_url:$('#smBase').value.trim(),enabled:$('#smEnabled').checked,upload_max_mb:+$('#smUploadMax').value||0});
  $('#smPass').value='';toast('حُفظ إعداد بريد النظام');
}
async function testSystemMail(){
  const r=await api('/system-smtp/test','POST',{});
  toast(r.dev?'وضع التطوير: الإرسال محاكى وسُجّل في النشاط':r.skipped?'بريدك ينتهي بـ .local — حدّث بريدك أولاً':'أُرسلت رسالة الاختبار إلى '+r.to+' ✓');
}
const dayNames=['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
/* ==================== مايكروسوفت OAuth ==================== */
function mbScopeHint(){
  const p=$('#mbScope').value==='personal';
  $('#mbScopeHintP').style.display=p?'':'none';
  $('#mbProjectField').style.display=p?'none':'';
  const adm=['owner','admin'].includes(S.me.role);
  if(!adm){$('#mbScope').value='personal';$('#mbScope').disabled=true;$('#mbScopeHintP').style.display='';$('#mbProjectField').style.display='none';}
}
function mbAuthHint(){const ms=$('#mbAuth').value==='oauth_ms';$('#msFields').style.display=ms?'':'none';
  if(ms){if(!$('#mbHost').value)$('#mbHost').value='outlook.office365.com';if(!$('#mbSmtpHost').value)$('#mbSmtpHost').value='smtp.office365.com';$('#mbProto').value='IMAP';}}
async function msConnect(id){
  const r=await api('/mailboxes/'+id+'/ms-auth-url');
  window.open(r.url,'_blank');
  toast('أكمل تسجيل الدخول في نافذة مايكروسوفت — بعد النجاح تبدأ المزامنة تلقائياً');
}

/* ==================== v0.3: دوال جديدة ==================== */
async function delProduct(id,nm){
  if(!confirm('حذف منتج «'+nm+'»؟ مشاريعه تبقى ويُفك ربطها فقط.'))return;
  await api('/products/'+id,'DELETE');toast('حُذف المنتج وفُك ربط مشاريعه');
}
async function approveEmail(id){
  const r=await api('/emails/'+id+'/approve','POST',{title:$('#apTitle').value.trim(),
    project_id:+$('#apProj').value,assignee_id:+$('#apAssignee').value||null});
  toast('اعتُمدت المهمة ✓','فتح ←',`openDrawer(${r.task_id})`);
}
async function rejectEmail(id){await api('/emails/'+id+'/reject','POST',{});toast('رُفضت المسودة — الرسالة محفوظة');}
let linkEmailId=null;
function openLinkTask(id){linkEmailId=id;$('#ltSearch').value='';ltFilter();openModal('linkTaskModal');setTimeout(()=>$('#ltSearch').focus(),50);}
function ltFilter(){
  const q=$('#ltSearch').value.trim();
  const em=E(linkEmailId);
  const list=S.tasks.filter(t=>t.status!=='done'&&(!em||t.id!==em.task_id)&&(!q||t.title.includes(q))).slice(0,15);
  $('#ltList').innerHTML=list.map(t=>`<button class="hit" style="display:block;width:100%;text-align:right;padding:9px 12px;border-bottom:1px solid var(--line)" onclick="doLinkTask(${t.id})">
    <span class="prio ${t.prio}"></span> ${esc(t.title)} <span style="color:${P(t.project_id).color};font-size:11px">· ${esc(P(t.project_id).name)}</span></button>`).join('')
    ||'<div class="empty" style="padding:14px">لا مهام مطابقة</div>';
}
async function doLinkTask(taskId){
  const r=await api('/emails/'+linkEmailId+'/link-task','POST',{task_id:taskId});
  closeModal('linkTaskModal');toast('رُبطت الرسالة بالمهمة ونُقلت مرفقاتها','فتح ←',`openDrawer(${r.task_id})`);
}

/* روابط الحجز المزدوجة */
const bkKinds=[{k:'inperson',label:'الاجتماعات الحضورية',hint:'بوقت انتقال يُحجب قبل الموعد وبعده'},{k:'online',label:'الاجتماعات الأونلاين',hint:'بدون وقت انتقال'}];
function renderBookingCard(){
  if(!document.querySelector('#bkSections'))return;
  const rows=Object.fromEntries((S.bookingTypes||[]).map(b=>[b.kind,b]));
  $('#bkSections').innerHTML=bkKinds.map(({k,label,hint})=>{
    const b=rows[k]||{enabled:0,slug:'',duration:k==='inperson'?60:30,days:'0,1,2,3,4',start_hour:9,end_hour:17,buffer_before:k==='inperson'?45:0,buffer_after:k==='inperson'?45:0};
    const link=b.enabled&&b.slug&&S.baseUrl?S.baseUrl+'/book/'+b.slug:'';
    return `<div style="border:1px solid var(--line);border-radius:10px;padding:12px 14px;margin-bottom:12px">
      <label style="font-size:13.5px;font-weight:700;display:flex;gap:8px;align-items:center"><input type="checkbox" id="bk_${k}_en" ${b.enabled?'checked':''}> ${label} <span style="font-weight:400;font-size:11px;color:var(--muted)">${hint}</span></label>
      <div class="frow" style="margin-top:10px">
        <div class="field"><label>معرّف الرابط</label><input id="bk_${k}_slug" value="${esc(b.slug||'')}" placeholder="${k==='inperson'?'dhaifullah-office':'dhaifullah'}" style="direction:ltr"></div>
        <div class="field" style="max-width:110px"><label>المدة (د)</label><select id="bk_${k}_dur">${[15,30,45,60,90].map(d=>`<option ${b.duration==d?'selected':''}>${d}</option>`).join('')}</select></div>
      </div>
      ${k==='inperson'?`<div class="frow">
        <div class="field"><label>انتقال قبل الاجتماع (د)</label><input id="bk_${k}_bb" type="number" min="0" value="${b.buffer_before??45}"></div>
        <div class="field"><label>انتقال بعد الاجتماع (د)</label><input id="bk_${k}_ba" type="number" min="0" value="${b.buffer_after??45}"></div>
      </div>`:''}
      <div class="frow">
        <div class="field"><label>من الساعة</label><input id="bk_${k}_sh" type="number" min="0" max="23" value="${b.start_hour}"></div>
        <div class="field"><label>إلى الساعة</label><input id="bk_${k}_eh" type="number" min="1" max="24" value="${b.end_hour}"></div>
      </div>
      <div class="field"><label>أيام العمل</label><div style="display:flex;gap:6px;flex-wrap:wrap">${dayNames.map((n,i)=>`<label style="font-size:12px;display:flex;gap:4px;align-items:center;border:1px solid var(--line);border-radius:7px;padding:3px 8px"><input type="checkbox" class="bk_${k}_day" value="${i}" ${String(b.days||'').split(',').includes(String(i))?'checked':''}>${n}</label>`).join('')}</div></div>
      <button class="btn pri sm" onclick="saveBookingType('${k}')">حفظ</button>
      ${link?`<div class="copy-link" style="margin-top:8px"><input readonly value="${link}" style="direction:ltr;border:1px solid var(--line);border-radius:8px;padding:8px 11px"><button class="btn" onclick="navigator.clipboard?.writeText('${link}');toast('نُسخ الرابط')">نسخ</button></div>`:''}
    </div>`;}).join('');
}
async function saveBookingType(k){
  const days=[...document.querySelectorAll('.bk_'+k+'_day:checked')].map(c=>c.value).join(',');
  await api('/booking-types','POST',{kind:k,enabled:$('#bk_'+k+'_en').checked,slug:$('#bk_'+k+'_slug').value.trim(),
    duration:+$('#bk_'+k+'_dur').value,days,start_hour:+$('#bk_'+k+'_sh').value,end_hour:+$('#bk_'+k+'_eh').value,
    buffer_before:k==='inperson'?+$('#bk_'+k+'_bb').value:0,buffer_after:k==='inperson'?+$('#bk_'+k+'_ba').value:0});
  toast('حُفظ رابط '+(k==='inperson'?'الحضوري':'الأونلاين'));
  if(!S.baseUrl)toast('نبّه: اضبط «رابط النظام الأساسي» في بطاقة بريد النظام ليكتمل الرابط');
}

/* إعدادات محرك الذكاء */
function aiProviderHint(){
  const p=$('#aiProvider').value;
  $('#aiAnthFields').style.display=p==='anthropic'?'':'none';
  $('#aiCustomFields').style.display=p==='custom'?'':'none';
}
async function saveAiSettings(){
  const p=$('#aiProvider').value;
  await api('/ai-settings','POST',{provider:p,
    api_key:p==='anthropic'?$('#aiKey').value:undefined,
    custom_key:p==='custom'?$('#aiCustomKey').value:undefined,
    base_url:p==='custom'?$('#aiBase').value.trim():undefined,
    model:(p==='custom'?$('#aiModel2').value:$('#aiModel').value).trim(),
    mail_task_mode:$('#mailMode').value});
  $('#aiKey').value='';$('#aiCustomKey').value='';
  toast('حُفظت إعدادات المحرك');
}
async function testAi(){
  toast('يختبر المحرك…');
  const r=await api('/ai-settings/test','POST',{});
  toast(r.ok?('المحرك يستجيب ✓'+(r.note?' — '+r.note:'')):('✗ '+(r.error||'المحرك لا يستجيب')));
}

/* ==================== v0.4: السلة والقنوات ==================== */
async function delFile(id,nm){
  if(!confirm('حذف ملف «'+nm+'»؟ سينتقل لسلة المحذوفات 180 يوماً وتتعطل روابط مشاركته.'))return;
  await api('/files/'+id,'DELETE');
  toast('حُذف الملف إلى سلة المحذوفات','تراجع',`restoreItem('file',${id})`);
}
async function restoreItem(type,id){
  await api('/trash/restore','POST',{type,id});
  toast('استُعيد العنصر بكامل بياناته ✓');
}
async function purgeItem(type,id,nm){
  if(!confirm('مسح «'+nm+'» نهائياً؟ لا يمكن التراجع بعدها إطلاقاً.'))return;
  await api('/trash/'+type+'/'+id,'DELETE');
  toast('مُسح نهائياً');
}
function renderTrash(){
  if(!document.querySelector('#trashCard'))return;
  const adm=['owner','admin'].includes(S.me.role);
  $('#trashCard').style.display=adm?'':'none';
  if(!adm)return;
  const tr=S.trash||{files:[],tasks:[]};
  const total=tr.files.length+tr.tasks.length;
  $('#trashCount').textContent=total?total+' عنصر':'فارغة';
  const row=(type,id,icon,nm,extra,it)=>`<div class="rowitem" style="cursor:default">
    <span>${icon}</span><div class="grow"><div class="trunc" style="max-width:260px">${esc(nm)} ${isAllMode()&&S.tenants.length>1&&it.tname?`<span class="chip purple">${esc(it.tname)}</span>`:''}</div>
    <div class="sub">حذفها ${esc(it.dname||'—')} · ${fmtWhen(it.deleted_at)} · ${extra}</div></div>
    <span class="chip ${it.days_left<=14?'red':'gray'}">${it.days_left} يوماً متبقية</span>
    <button class="btn sm" onclick="restoreItem('${type}',${id})">استعادة</button>
    <button class="btn sm ghost warn" onclick="purgeItem('${type}',${id},'${esc(nm)}')">مسح نهائي</button></div>`;
  $('#trashList').innerHTML=
    tr.tasks.map(t=>row('task',t.id,'☑',t.title,'مهمة',t)).join('')+
    tr.files.map(f=>row('file',f.id,'▣',f.name,fmtSize(f.size),f)).join('')
    ||'<div class="empty" style="padding:14px">السلة فارغة — كل شيء في مكانه ✓</div>';
}
async function emptyTrash(){
  const tr=S.trash||{files:[],tasks:[]};const n=tr.files.length+tr.tasks.length;
  if(!n){toast('السلة فارغة أصلاً');return;}
  if(!confirm('مسح كل محتويات السلة نهائياً ('+n+' عنصر)؟ لا رجعة بعدها إطلاقاً.'))return;
  const r=await api('/trash','DELETE');
  toast('أُفرغت السلة: '+r.files+' ملف و'+r.tasks+' مهمة مُسحت نهائياً');
}
async function createChannel(){
  const n=$('#chName').value.trim();if(!n){toast('اكتب اسم القناة');return;}
  const r=await api('/channels','POST',{name:n});
  $('#chName').value='';closeModal('chanModal');curChan=r.id;toast('أُنشئت القناة');go('chat');
}
function openDm(){
  $('#dmUser').innerHTML=S.members.filter(m=>m.active&&m.id!==S.me.id).map(m=>`<option value="${m.id}">${esc(m.name)}</option>`).join('');
  openModal('dmModal');
}
async function startDm(){
  const r=await api('/channels/dm','POST',{user_id:+$('#dmUser').value});
  closeModal('dmModal');curChan=r.id;go('chat');renderChat();
}

/* ==================== v0.6.2: استيراد .eml ==================== */
function openImport(){
  $('#impMailbox').innerHTML='<option value="">صندوق الاستيراد الشخصي (يُنشأ تلقائياً)</option>'+
    S.mailboxes.map(m=>`<option value="${m.id}">${esc(m.email)} — ${m.scope==='personal'?'شخصي':'فريق'}</option>`).join('');
  $('#impFiles').value='';$('#impStatus').textContent='';
  openModal('importModal');
}
async function doImport(){
  const files=$('#impFiles').files;
  if(!files.length){toast('اختر ملفات .eml أو zip');return;}
  const fd=new FormData();
  fd.append('mailbox_id',$('#impMailbox').value);
  for(const f of files)fd.append('emls',f);
  $('#impGo').disabled=true;$('#impStatus').textContent='⏳ يعالج '+files.length+' ملفاً — التلخيص الذكي قد يستغرق ثواني لكل رسالة…';
  try{
    const r=await fetch(API+'/emails/import',{method:'POST',headers:{Authorization:'Bearer '+TOKEN,'X-Tenant':localStorage.getItem('mihwar_tenant')||'all'},body:fd}).then(x=>x.json());
    if(r.error)throw new Error(r.error);
    if(r.queued){
      $('#impStatus').innerHTML='⏳ دفعة كبيرة ('+r.queued+' رسالة) — تُعالج بالخلفية الآن، والرسائل بتظهر تباعاً في بريدك وبيوصلك إشعار 🔔 عند الاكتمال. تقدر تسكّر النافذة.';
      toast('بدأت معالجة '+r.queued+' رسالة بالخلفية');
    } else {
      $('#impStatus').innerHTML='✓ استُوردت <b>'+r.ok+'</b> رسالة'+(r.dup?' · تُخطيت '+r.dup+' مكررة':'')+(r.fail?' · تعذرت '+r.fail:'');
      toast('اكتمل الاستيراد — رسائلك بانتظار توجيهك في البريد');
    }
  }catch(e){$('#impStatus').textContent='✗ '+e.message;}
  $('#impGo').disabled=false;
}
