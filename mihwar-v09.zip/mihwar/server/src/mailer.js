// عامل البريد: القراءة (IMAP/POP3) → التحليل → التحويل لمهام، والإرسال (SMTP) الفوري والمجدول.
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { simpleParser } = require('mailparser');
const nodemailer = require('nodemailer');
const { db } = require('./db');
const { summarizeAndDraft } = require('./ai');
const { pop3Fetch } = require('./pop3');
const { parseIcs, buildIcs } = require('./ics');
const msauth = require('./msauth');

const DEV = String(process.env.MAIL_DEV_MODE || 'true') === 'true';
let emit = () => {};
function onChange(fn) { emit = fn; }

/* ---- تشفير بيانات دخول الصناديق ---- */
const KEY = crypto.createHash('sha256').update(process.env.SECRET || 'dev').digest();
function enc(t) { if (!t) return null; const iv = crypto.randomBytes(12); const c = crypto.createCipheriv('aes-256-gcm', KEY, iv);
  const e = Buffer.concat([c.update(t, 'utf8'), c.final()]); return Buffer.concat([iv, c.getAuthTag(), e]).toString('base64'); }
function dec(b) { if (!b) return null; const raw = Buffer.from(b, 'base64'); const d = crypto.createDecipheriv('aes-256-gcm', KEY, raw.subarray(0, 12));
  d.setAuthTag(raw.subarray(12, 28)); return Buffer.concat([d.update(raw.subarray(28)), d.final()]).toString('utf8'); }


/* ---- إعدادات النظام (مفتاح/قيمة) ---- */
function getSetting(k) { const r = db.prepare('SELECT value FROM settings WHERE key=?').get(k); return r ? r.value : null; }
function setSetting(k, v) { db.prepare('INSERT INTO settings(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(k, v); }

/* ---- بريد النظام: إيميلات التنبيه والتأكيدات ---- */
function systemSmtpConfigured() { return !!(getSetting('smtp_host') && getSetting('smtp_user')); }
async function sendSystemMail(to, subject, text, icsStr) {
  if (!to || /@mihwar\.local$/.test(to)) return { skipped: true };
  if (DEV || !systemSmtpConfigured()) {
    logAct(`(وضع تطوير) بريد نظام محاكى إلى ${to}: ${subject}`);
    return { dev: true };
  }
  const tr = nodemailer.createTransport({
    host: getSetting('smtp_host'), port: Number(getSetting('smtp_port')) || 587,
    secure: (Number(getSetting('smtp_port')) || 587) === 465,
    auth: { user: getSetting('smtp_user'), pass: dec(getSetting('smtp_pass_enc')) },
  });
  return tr.sendMail({
    from: getSetting('smtp_from') || getSetting('smtp_user'), to, subject, text,
    attachments: icsStr ? [{ filename: 'invite.ics', content: icsStr, contentType: 'text/calendar; method=REQUEST' }] : [],
  });
}
async function notifyUser(userId, body, emailToo) {
  db.prepare('INSERT INTO notifications(user_id,body) VALUES (?,?)').run(userId, body);
  if (emailToo && getSetting('notify_email_enabled') !== '0') {
    const u = db.prepare('SELECT email,notify_email FROM users WHERE id=? AND active=1').get(userId);
    if (u && u.notify_email) sendSystemMail(u.email, 'محور — ' + body.slice(0, 70), body + '\n\nافتح النظام: ' + (getSetting('base_url') || '')).catch(() => {});
  }
}


/* ---- سلة المحذوفات: مسح نهائي بعد 180 يوماً ---- */
function startPurge() {
  const tick = () => {
    try {
      for (const f of db.prepare("SELECT * FROM files WHERE deleted_at IS NOT NULL AND deleted_at < datetime('now','-180 day')").all()) {
        try { fs.unlinkSync(path.join(__dirname, '..', 'uploads', f.stored)); } catch {}
        db.prepare('DELETE FROM shares WHERE file_id=?').run(f.id);
        db.prepare('DELETE FROM files WHERE id=?').run(f.id);
      }
      const t = db.prepare("DELETE FROM tasks WHERE deleted_at IS NOT NULL AND deleted_at < datetime('now','-180 day')").run();
      if (t.changes) logAct('مُسحت عناصر تجاوزت 180 يوماً في سلة المحذوفات نهائياً');
    } catch (e) { logAct('خطأ في مهمة التنظيف: ' + e.message); }
  };
  setTimeout(tick, 30000); setInterval(tick, 12 * 3600000);
}

/* ---- تذكير الاستحقاق: كل ساعة، مهام اليوم غير المكتملة ---- */
function startReminders() {
  const tick = () => {
    const due = db.prepare("SELECT * FROM tasks WHERE due=date('now') AND status!='done' AND reminder_sent IS NULL AND assignee_id IS NOT NULL AND deleted_at IS NULL").all();
    for (const t of due) {
      notifyUser(t.assignee_id, `تذكير: مهمة «${t.title}» تستحق اليوم`, true);
      db.prepare("UPDATE tasks SET reminder_sent=datetime('now') WHERE id=?").run(t.id);
    }
    if (due.length) emit();
  };
  setTimeout(tick, 15000); setInterval(tick, 3600000);
}


require('./ai').init({ getSetting, dec, enc });
/* ---- خط معالجة رسالة واردة (مشترك بين IMAP وPOP3 والمحاكاة) ---- */
async function processIncoming(mailbox, parsed) {
  const messageId = parsed.messageId || ('gen-' + crypto.randomUUID());
  if (db.prepare('SELECT id FROM emails WHERE message_id=?').get(messageId)) return null; // مكررة

  // التقاط دعوات الاجتماعات (.ics) → التقويم الموحد
  try {
    for (const att of parsed.attachments || []) {
      const isCal = /calendar/i.test(att.contentType || '') || /\.ics$/i.test(att.filename || '');
      if (!isCal) continue;
      const { events } = parseIcs(att.content.toString('utf8'));
      for (const ev of events) {
        if (ev.cancelled && ev.uid) {
          db.prepare("UPDATE events SET status='cancelled' WHERE uid=?").run(ev.uid);
          logAct(`أُلغي اجتماع من التقويم: «${ev.summary}»`);
        } else if (ev.uid && db.prepare('SELECT id FROM events WHERE uid=?').get(ev.uid)) {
          db.prepare('UPDATE events SET title=?,starts_at=?,ends_at=?,location=?,organizer=?,status=\'ok\' WHERE uid=?')
            .run(ev.summary, ev.starts_at, ev.ends_at, ev.location, ev.organizer, ev.uid);
        } else {
          db.prepare("INSERT INTO events(title,starts_at,ends_at,all_day,location,organizer,source,uid,mailbox_id,tenant_id,user_id) VALUES (?,?,?,?,?,?,'ics',?,?,?,?)")
            .run(ev.summary, ev.starts_at, ev.ends_at, ev.all_day, ev.location, ev.organizer, ev.uid, mailbox.id,
              mailbox.scope==='personal'?null:mailbox.tenant_id, mailbox.scope==='personal'?mailbox.owner_id:null);
          logAct(`دعوة اجتماع أُضيفت للتقويم: «${ev.summary}»`);
          if (mailbox.scope==='personal'&&mailbox.owner_id) notifyUser(mailbox.owner_id, `دعوة اجتماع جديدة: ${ev.summary}`, false); else notifyAll(`دعوة اجتماع جديدة: ${ev.summary}`, mailbox.tenant_id);
        }
      }
    }
  } catch (e) { logAct('تعذر قراءة دعوة تقويم مرفقة: ' + String(e.message).slice(0, 80)); }

  const fromAddr = (parsed.from && parsed.from.value && parsed.from.value[0]) || {};
  const email = {
    from_name: fromAddr.name || fromAddr.address || 'غير معروف',
    from_email: fromAddr.address || '',
    subject: parsed.subject || '(بدون عنوان)',
    body: (parsed.text || '').trim() || (parsed.html ? String(parsed.html).replace(/<[^>]+>/g, ' ').trim() : ''),
  };

  // سلسلة رد؟ → تعليق على المهمة الأصلية بدل مهمة جديدة
  const refs = [].concat(parsed.inReplyTo || [], parsed.references || []).filter(Boolean);
  for (const ref of refs) {
    const parent = db.prepare('SELECT * FROM emails WHERE message_id=?').get(ref);
    if (parent && parent.task_id) {
      db.prepare('INSERT INTO comments(task_id,user_id,body,is_mail) VALUES (?,NULL,?,1)')
        .run(parent.task_id, `رد جديد من ${email.from_name}:\n${email.body.slice(0, 1500)}`);
      db.prepare('INSERT INTO emails(mailbox_id,message_id,from_name,from_email,subject,body,task_id) VALUES (?,?,?,?,?,?,?)')
        .run(mailbox.id, messageId, email.from_name, email.from_email, email.subject, email.body, parent.task_id);
      logAct(`رد بريدي جديد أُضيف كتعليق على مهمة رقم ${parent.task_id}`);
      try { // ذكاء الإغلاق: هل هذا الرد تأكيد إنجاز؟ نقترح الإغلاق ولا نغلق — القرار للمستخدم
        const t2 = db.prepare("SELECT * FROM tasks WHERE id=? AND status!='done' AND deleted_at IS NULL").get(parent.task_id);
        if (t2 && await require('./ai').detectCompletion(email)) {
          db.prepare('UPDATE tasks SET close_suggested=1 WHERE id=?').run(t2.id);
          const who = t2.assignee_id || mailbox.owner_id;
          if (who) notifyUser(who, `✓ البريد يشير لإنجاز «${t2.title}» — راجع اقتراح الإغلاق على المهمة`, false);
          logAct(`المحرك اقترح إغلاق «${t2.title}» بناءً على رد بريدي مؤكِّد`, mailbox.tenant_id);
        }
      } catch {}
      notifyAll(`رد جديد من ${email.from_name} على «${parent.subject}»`, mailbox.tenant_id);
      emit(); return { thread: true, tid: parent.task_id };
    }
  }

  const personal = mailbox.scope === 'personal';
  if (!personal && !mailbox.default_project_id) {
    db.prepare('INSERT INTO review_queue(from_email,subject,body,reason) VALUES (?,?,?,?)')
      .run(email.from_email, email.subject, email.body, 'الصندوق غير مربوط بمشروع — تصنيف يدوي');
    emit(); return null;
  }

  const ai = await summarizeAndDraft(email, mailbox.represents_email || null);
  const approveMode = personal || getSetting('mail_task_mode') === 'approve'; // الشخصي دائماً بتوجيه صاحبه
  unwrapFW(email);
  // v0.9: قواعد البريد — أول قاعدة مطابقة (لقواعد صاحب الصندوق)
  let ruleHit = null;
  try {
    const rules = db.prepare('SELECT * FROM mail_rules WHERE active=1 AND owner_id=? ORDER BY id').all(mailbox.owner_id || -1);
    const hay = { from: ((email.real_from_email || email.from_email || '') + ' ' + (email.real_from_name || email.from_name || '')).toLowerCase(),
                  subject: ((email.orig_subject || '') + ' ' + (email.subject || '')).toLowerCase() };
    ruleHit = rules.find(r2 => (hay[r2.field] || '').includes(String(r2.pattern).toLowerCase())) || null;
  } catch {}
  const eid = db.prepare('INSERT INTO emails(mailbox_id,message_id,from_name,from_email,subject,body,body_html,summary,draft,proposed_title,approved,real_from_name,real_from_email,fw_to,fw_cc,orig_subject) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
    .run(mailbox.id, messageId, email.from_name, email.from_email, email.subject, email.body, parsed.html ? String(parsed.html).slice(0, 300000) : null,
      JSON.stringify(ai.summary), ai.draft, ai.task_title || email.subject, approveMode ? null : 1, email.real_from_name||null, email.real_from_email||null, email.fw_to||null, email.fw_cc||null, email.orig_subject||null).lastInsertRowid;
  if (ai.audience) db.prepare('UPDATE emails SET audience_role=?, audience_note=? WHERE id=?').run(ai.audience.role, ai.audience.note, eid);
  if (ruleHit && ruleHit.folder_id) db.prepare('UPDATE emails SET folder_id=? WHERE id=?').run(ruleHit.folder_id, eid);
  let tid = null;
  if (!approveMode) {
    if (ruleHit && ruleHit.prio) ai.prio = ruleHit.prio;
    if (ruleHit && ruleHit.project_id) mailbox = { ...mailbox, default_project_id: ruleHit.project_id };
    const aiDue = (ai.due_hint && /^\d{4}-\d{2}-\d{2}$/.test(ai.due_hint)) ? ai.due_hint : null;
    tid = db.prepare("INSERT INTO tasks(title,descr,project_id,due,prio,status,src,email_id,tenant_id) VALUES (?,?,?,COALESCE(?,date('now','+2 day')),?,'todo','mail',?,"+(mailbox.tenant_id||'NULL')+")")
      .run(ai.task_title || email.subject, `وصلت عبر البريد من ${email.from_name} <${email.from_email}> — الملخص والرد الذكي داخل الرسالة المرتبطة.${ai.action ? '\nالإجراء المطلوب: ' + ai.action : ''}`, mailbox.default_project_id, aiDue, ai.prio || 'p2', eid).lastInsertRowid;
    db.prepare('UPDATE emails SET task_id=? WHERE id=?').run(tid, eid);
  }

  // حفظ المرفقات في تخزين الملفات وربطها بالمهمة
  let inlineIdx = 0;
  for (const att of parsed.attachments || []) {
    if (!att.content || !att.content.length) continue;
    const mime = att.contentType || '';
    const { stored, hash } = storeBlob(att.content, mime); // بصمة: المتكرر لا يُخزن مرتين
    if (/^image\//i.test(mime)) {
      // كل صور البريد (توقيعات/شعارات/لقطات) → متن الرسالة، لا تدخل نظام الملفات
      db.prepare('INSERT INTO email_inline(email_id,cid,name,stored,hash,mime,size) VALUES (?,?,?,?,?,?,?)')
        .run(eid, att.cid || ('img-' + (++inlineIdx)), att.filename || 'صورة', stored, hash, mime, att.content.length);
    } else {
      db.prepare("INSERT INTO files(name,stored,size,mime,src,task_id,email_id,tenant_id) VALUES (?,?,?,?, 'mail',?,?,?)")
        .run(att.filename || 'مرفق', stored, att.size || att.content.length, mime, tid || null, eid,
          mailbox.scope==='personal' ? null : (mailbox.tenant_id || null));
    }
  }
  db.prepare('UPDATE mailboxes SET processed=processed+1,last_sync=datetime(\'now\'),status=\'ok\',last_error=NULL WHERE id=?').run(mailbox.id);
  if (personal) {
    if (mailbox.owner_id) notifyUser(mailbox.owner_id, `بريد جديد في صندوقك الشخصي بانتظار توجيهك: ${email.subject}`, true);
  } else if (approveMode) {
    logAct(`بريد وارد بانتظار الموافقة: «${email.subject}»`);
    notifyAll(`بريد جديد بانتظار موافقتك: ${email.subject}`, mailbox.tenant_id);
  } else {
    logAct(`بريد وارد تحوّل تلقائياً لمهمة: «${email.subject}»`);
    notifyAll(`بريد جديد تحوّل لمهمة: ${email.subject}`, mailbox.tenant_id);
  }
  emit(); return { eid, tid };
}

/* ---- السحب الدوري ---- */
const pollLocks = new Set();
async function pollMailbox(mb) {
  if (mb.is_import) return; // صندوق استيراد يدوي — لا سحب
  if (pollLocks.has(mb.id)) return { busy: true }; // سحب جارٍ — لا نفتح اتصالاً موازياً
  pollLocks.add(mb.id);
  try { return await pollMailboxInner(mb); }
  finally { pollLocks.delete(mb.id); }
}
async function pollMailboxInner(mb) {
  const pass = dec(mb.pass_enc);
  try {
    if (mb.proto === 'IMAP') {
      const { ImapFlow } = require('imapflow');
      let auth = { user: mb.username, pass };
      if (mb.auth_type === 'oauth_ms') {
        if (!mb.ms_refresh_enc) throw new Error('لم يُربط حساب مايكروسوفت بعد — اضغط «ربط الحساب» في الإعدادات');
        auth = { user: mb.username, accessToken: await msauth.getAccessToken(mb, enc, dec) };
      }
      const client = new ImapFlow({ host: mb.host, port: mb.port || 993, secure: true, auth, logger: false,
        socketTimeout: 60000, greetingTimeout: 20000, connectionTimeout: 20000 });
      let pollDone = false; // بعد اكتمال السحب بنجاح، أخطاء إغلاق المقبس اللاحقة ليست فشلاً
      client.on('error', (e) => { // بدون هذا المستمع، مهلة المقبس تنهار بالعملية كاملة
        if (pollDone) return;
        db.prepare("UPDATE mailboxes SET status='err', last_error=? WHERE id=?")
          .run('انقطاع اتصال: ' + String(e && e.message || e).slice(0, 120), mb.id);
      });
      const batch = [];
      let lastUid = mb.last_uid || 0, validity = 0;
      await client.connect();
      const lock = await client.getMailboxLock('INBOX');
      try {
        validity = Number(client.mailbox.uidValidity || 0);
        if (mb.uid_validity && Number(mb.uid_validity) !== validity) lastUid = 0; // أعاد الخادم ترقيمه — منع التكرار يحمي من الازدواج
        // المرحلة ١: تنزيل خام سريع فقط — لا معالجة والاتصال مفتوح
        for await (const msg of client.fetch({ uid: (lastUid + 1) + ':*' }, { source: true, uid: true }, { uid: true })) {
          if (msg.uid <= lastUid) continue; // '*' قد تعيد آخر رسالة حتى لو سبق جلبها
          batch.push({ uid: msg.uid, source: msg.source });
          if (batch.length >= 150) break; // سقف الدفعة — البقية بالدورة التالية
        }
      } finally { lock.release(); }
      pollDone = true;
      try { await client.logout(); } catch { /* إغلاق المزود للمقبس بعد النجاح — غير مهم */ }
      // المرحلة ٢: المعالجة والتلخيص بعد إغلاق الاتصال — لا مهلة تهددنا
      let maxUid = lastUid;
      for (const item of batch) {
        try {
          const parsed = await simpleParser(item.source);
          await processIncoming(mb, parsed);
        } catch (pe) { logAct('تعذرت معالجة رسالة أثناء السحب: ' + String(pe.message).slice(0, 80)); }
        if (item.uid > maxUid) {
          maxUid = item.uid;
          db.prepare('UPDATE mailboxes SET last_uid=?, uid_validity=? WHERE id=?').run(maxUid, validity, mb.id); // تقدم محفوظ رسالة برسالة
        }
      }
    } else { // POP3
      const known = new Set(db.prepare('SELECT uid FROM seen_uids WHERE mailbox_id=?').all(mb.id).map(r => r.uid));
      const res = await pop3Fetch({ host: mb.host, port: mb.port || 995, user: mb.username, pass }, known);
      for (const m of res.messages) {
        const parsed = await simpleParser(m.raw);
        await processIncoming(mb, parsed);
        db.prepare('INSERT OR IGNORE INTO seen_uids(mailbox_id,uid) VALUES (?,?)').run(mb.id, m.uid);
      }
    }
    db.prepare("UPDATE mailboxes SET last_sync=datetime('now'),status='ok',last_error=NULL WHERE id=?").run(mb.id);
  } catch (e) {
    db.prepare("UPDATE mailboxes SET status='err',last_error=? WHERE id=?").run(String(e.message).slice(0, 200), mb.id);
    emit();
  }
}

function startPolling() {
  setInterval(() => { // v0.9: إيقاظ رسائل الغفوة
    try {
      const due = db.prepare("SELECT e.id,e.subject,mb.owner_id FROM emails e LEFT JOIN mailboxes mb ON mb.id=e.mailbox_id WHERE e.snooze_until IS NOT NULL AND e.snooze_until<=datetime('now')").all();
      for (const e of due) {
        db.prepare('UPDATE emails SET snooze_until=NULL WHERE id=?').run(e.id);
        if (e.owner_id) notifyUser(e.owner_id, `⏰ رجعت رسالة من الغفوة: «${String(e.subject).slice(0,60)}»`, false);
      }
      if (due.length) emit();
    } catch {}
  }, 60e3);
  const every = (Number(process.env.MAIL_POLL_SECONDS) || 90) * 1000;
  setInterval(() => {
    for (const mb of db.prepare("SELECT * FROM mailboxes WHERE status!='dev'").all()) pollMailbox(mb).catch(() => {});
  }, every);
}

/* ---- الإرسال عبر SMTP والجدولة ---- */
async function smtpSend(mb, { to, subject, text, inReplyTo }) {
  if (DEV || !mb || !mb.smtp_host) {
    return { dev: true, messageId: '<dev-' + crypto.randomUUID() + '@mihwar.local>' };
  }
  let auth = { user: mb.username, pass: dec(mb.pass_enc) };
  if (mb.auth_type === 'oauth_ms')
    auth = { type: 'OAuth2', user: mb.username, accessToken: await msauth.getAccessToken(mb, enc, dec) };
  const tr = nodemailer.createTransport({ host: mb.smtp_host, port: mb.smtp_port || 587,
    secure: (mb.smtp_port || 587) === 465, auth });
  return tr.sendMail({ from: mb.email, to, subject, text,
    inReplyTo: inReplyTo || undefined, references: inReplyTo || undefined });
}

async function sendReply(emailId, body, userId) {
  const em = db.prepare('SELECT * FROM emails WHERE id=?').get(emailId);
  if (!em) throw new Error('الرسالة غير موجودة');
  const mb = db.prepare('SELECT * FROM mailboxes WHERE id=?').get(em.mailbox_id);
  const info = await smtpSend(mb, { to: em.from_email, subject: 'رد: ' + em.subject, text: body, inReplyTo: em.message_id });
  db.prepare("UPDATE emails SET replied_at=datetime('now'), draft=? WHERE id=?").run(body, emailId);
  if (em.task_id) db.prepare('INSERT INTO comments(task_id,user_id,body,is_mail) VALUES (?,?,?,1)')
    .run(em.task_id, userId, `أُرسل الرد بالبريد إلى ${em.from_email}${info.dev ? ' (وضع تطوير — لم يُرسل فعلياً)' : ''}:\n${body}`);
  logAct(`أُرسل رد بالبريد على «${em.subject}»`);
  emit(); return info;
}

function startScheduler() {
  setInterval(async () => {
    const due = db.prepare("SELECT * FROM scheduled WHERE status='pending' AND send_at<=datetime('now')").all();
    for (const s of due) {
      try {
        await sendReply(s.email_id, s.body, s.created_by);
        db.prepare("UPDATE scheduled SET status='sent' WHERE id=?").run(s.id);
      } catch (e) {
        db.prepare("UPDATE scheduled SET status='failed' WHERE id=?").run(s.id);
      }
      emit();
    }
  }, 30000);
}


/* فك تغليف الرسائل المحوّلة (FW): استخراج المرسل والمستلمين والعنوان الأصليين من متن التحويل */
function unwrapFW(email) {
  const head = String(email.body || '').slice(0, 2500);
  const m = head.match(/From:\s*"?([^"<\r\n]+?)"?\s*<([^>\s]+)>/);
  if (!m) return email;
  email.real_from_name = m[1].trim();
  email.real_from_email = m[2].trim();
  email.fw_to = (head.match(/^To:\s*(.+)$/m) || [])[1] || null;
  email.fw_cc = (head.match(/^Cc:\s*(.+)$/m) || [])[1] || null;
  const os = (head.match(/^Subject:\s*(.+)$/m) || [])[1];
  email.orig_subject = os ? os.trim() : null;
  return email;
}

/* تخزين بالبصمة: نفس المحتوى لا يُكتب مرتين مهما تكرر (توقيعات، شعارات...) */
function storeBlob(content, mime) {
  const hash = crypto.createHash('sha256').update(content).digest('hex');
  const ex = db.prepare('SELECT stored FROM blobs WHERE hash=?').get(hash);
  if (ex) return { stored: ex.stored, hash, reused: true };
  const ext = mime && mime.includes('png') ? '.png' : mime && mime.includes('jpe') ? '.jpg' : mime && mime.includes('gif') ? '.gif' : '';
  const stored = Date.now() + '-' + hash.slice(0, 10) + ext;
  fs.writeFileSync(path.join(__dirname, '..', 'uploads', stored), content);
  db.prepare('INSERT INTO blobs(hash,stored,size,mime) VALUES (?,?,?,?)').run(hash, stored, content.length, mime || '');
  return { stored, hash, reused: false };
}
/* حذف فيزيائي آمن: فقط إن لم يعد أي سجل يشير للمخزون */
function safeUnlink(stored) {
  const refs = db.prepare('SELECT (SELECT COUNT(*) FROM files WHERE stored=?) + (SELECT COUNT(*) FROM email_inline WHERE stored=?) c').get(stored, stored).c;
  if (refs === 0) { try { fs.unlinkSync(path.join(__dirname, '..', 'uploads', stored)); } catch {} db.prepare('DELETE FROM blobs WHERE stored=?').run(stored); }
}

function conf(key, dflt) { const r = db.prepare('SELECT value FROM settings WHERE key=?').get(key); return r ? r.value : dflt; }
function setConf(key, val) { db.prepare('INSERT INTO settings(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(key, String(val)); }

function logAct(body, tenantId) { db.prepare('INSERT INTO activity(body,tenant_id) VALUES (?,?)').run(body, tenantId || null); }
function notifyAll(body, tenantId) {
  const users = tenantId
    ? db.prepare('SELECT u.id FROM users u JOIN memberships m ON m.user_id=u.id WHERE u.active=1 AND m.tenant_id=?').all(tenantId)
    : db.prepare('SELECT id FROM users WHERE active=1').all();
  for (const u of users) db.prepare('INSERT INTO notifications(user_id,body) VALUES (?,?)').run(u.id, body);
}


/* ═══ v0.9: تقرير أسبوعي + نسخ احتياطي يومي ═══ */
function buildWeeklyReport() {
  const done = db.prepare("SELECT COUNT(*) c FROM tasks WHERE status='done' AND deleted_at IS NULL AND created_at>=datetime('now','-30 day')").get().c;
  const overdue = db.prepare("SELECT title,due FROM tasks WHERE status!='done' AND deleted_at IS NULL AND due<date('now') ORDER BY due LIMIT 8").all();
  const upcoming = db.prepare("SELECT title,due FROM tasks WHERE status!='done' AND deleted_at IS NULL AND due BETWEEN date('now') AND date('now','+7 day') ORDER BY due LIMIT 10").all();
  const mails = db.prepare("SELECT COUNT(*) c FROM emails WHERE received_at>=datetime('now','-7 day')").get().c;
  const li = a => a.map(t => `<li>${String(t.title).replace(/</g,'&lt;')} <small style="color:#888">(${t.due})</small></li>`).join('') || '<li style="color:#888">لا شيء 🎉</li>';
  return `<div dir="rtl" style="font-family:system-ui;max-width:560px">
    <h2 style="color:#123F3A">📊 تقريرك الأسبوعي — محور</h2>
    <p>✅ مهام منجزة: <b>${done}</b> · 📧 وصل هذا الأسبوع: <b>${mails} رسالة</b></p>
    <h3 style="color:#B3372F">⚠️ متأخرة (${overdue.length})</h3><ul>${li(overdue)}</ul>
    <h3 style="color:#1E6B45">📅 قادمة خلال أسبوع (${upcoming.length})</h3><ul>${li(upcoming)}</ul>
    <p style="color:#888;font-size:12px">أُرسل تلقائياً من نظام محور</p></div>`;
}
async function sendWeeklyReports(force) {
  if (conf('weekly_report', '1') !== '1' && !force) return 0;
  const admins = db.prepare("SELECT DISTINCT u.* FROM users u JOIN memberships m2 ON m2.user_id=u.id WHERE m2.role IN ('owner','admin') AND u.active=1").all();
  let n = 0;
  for (const u of admins) { try { await sendMail(u.email, '📊 تقريرك الأسبوعي — محور', buildWeeklyReport()); n++; } catch {} }
  logAct('أُرسل التقرير الأسبوعي إلى ' + n + ' مدير 📊');
  return n;
}
let _lastWeekly = '';
setInterval(() => {
  const now = new Date(), stamp = now.toISOString().slice(0, 10);
  if (now.getDay() === 0 && now.getHours() === 9 && _lastWeekly !== stamp) { _lastWeekly = stamp; sendWeeklyReports().catch(() => {}); }
}, 10 * 60e3);

function runBackup() {
  const dir = path.join(__dirname, '..', 'backups');
  if (!fs.existsSync(dir)) fs.mkdirSync(dir);
  const name = 'mihwar-' + new Date().toISOString().slice(0, 10) + '.db';
  const full = path.join(dir, name);
  try { fs.unlinkSync(full); } catch {}
  db.prepare('VACUUM INTO ?').run(full);
  const all = fs.readdirSync(dir).filter(f => f.endsWith('.db')).sort();
  while (all.length > 14) { try { fs.unlinkSync(path.join(dir, all.shift())); } catch {} }
  setConf('last_backup', new Date().toISOString());
  return name;
}
let _lastBk = '';
setInterval(() => {
  const stamp = new Date().toISOString().slice(0, 10);
  if (new Date().getHours() === 3 && _lastBk !== stamp) { _lastBk = stamp; try { runBackup(); logAct('نسخة احتياطية يومية 🛡'); } catch (e) { logAct('تعذر النسخ الاحتياطي: ' + e.message); } }
}, 10 * 60e3);
setTimeout(() => { try { if (!conf('last_backup', '')) { runBackup(); logAct('أول نسخة احتياطية أُخذت 🛡'); } } catch {} }, 15e3);

module.exports = { runBackup, sendWeeklyReports, conf, setConf, storeBlob, safeUnlink, processIncoming, pollMailbox, startPolling, startScheduler, startReminders, startPurge, sendReply, enc, dec, onChange, logAct, notifyAll, notifyUser, getSetting, setSetting, sendSystemMail, systemSmtpConfigured, buildIcs };
