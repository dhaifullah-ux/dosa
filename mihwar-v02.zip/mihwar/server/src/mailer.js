// عامل البريد: القراءة (IMAP/POP3) → التحليل → التحويل لمهام، والإرسال (SMTP) الفوري والمجدول.
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { simpleParser } = require('mailparser');
const nodemailer = require('nodemailer');
const { db } = require('./db');
const { summarizeAndDraft } = require('./ai');
const { pop3Fetch } = require('./pop3');
const { parseIcs, buildIcs } = require('./ics');
const msauth = require('./msauth');

const DEV = String(process.env.MAIL_DEV_MODE || 'true') === 'true';
let emit = () => {};
function onChange(fn) { emit = fn; }

/* ---- تشفير بيانات دخول الصناديق ---- */
const KEY = crypto.createHash('sha256').update(process.env.SECRET || 'dev').digest();
function enc(t) { if (!t) return null; const iv = crypto.randomBytes(12); const c = crypto.createCipheriv('aes-256-gcm', KEY, iv);
  const e = Buffer.concat([c.update(t, 'utf8'), c.final()]); return Buffer.concat([iv, c.getAuthTag(), e]).toString('base64'); }
function dec(b) { if (!b) return null; const raw = Buffer.from(b, 'base64'); const d = crypto.createDecipheriv('aes-256-gcm', KEY, raw.subarray(0, 12));
  d.setAuthTag(raw.subarray(12, 28)); return Buffer.concat([d.update(raw.subarray(28)), d.final()]).toString('utf8'); }


/* ---- إعدادات النظام (مفتاح/قيمة) ---- */
function getSetting(k) { const r = db.prepare('SELECT value FROM settings WHERE key=?').get(k); return r ? r.value : null; }
function setSetting(k, v) { db.prepare('INSERT INTO settings(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(k, v); }

/* ---- بريد النظام: إيميلات التنبيه والتأكيدات ---- */
function systemSmtpConfigured() { return !!(getSetting('smtp_host') && getSetting('smtp_user')); }
async function sendSystemMail(to, subject, text, icsStr) {
  if (!to || /@mihwar\.local$/.test(to)) return { skipped: true };
  if (DEV || !systemSmtpConfigured()) {
    logAct(`(وضع تطوير) بريد نظام محاكى إلى ${to}: ${subject}`);
    return { dev: true };
  }
  const tr = nodemailer.createTransport({
    host: getSetting('smtp_host'), port: Number(getSetting('smtp_port')) || 587,
    secure: (Number(getSetting('smtp_port')) || 587) === 465,
    auth: { user: getSetting('smtp_user'), pass: dec(getSetting('smtp_pass_enc')) },
  });
  return tr.sendMail({
    from: getSetting('smtp_from') || getSetting('smtp_user'), to, subject, text,
    attachments: icsStr ? [{ filename: 'invite.ics', content: icsStr, contentType: 'text/calendar; method=REQUEST' }] : [],
  });
}
async function notifyUser(userId, body, emailToo) {
  db.prepare('INSERT INTO notifications(user_id,body) VALUES (?,?)').run(userId, body);
  if (emailToo && getSetting('notify_email_enabled') !== '0') {
    const u = db.prepare('SELECT email,notify_email FROM users WHERE id=? AND active=1').get(userId);
    if (u && u.notify_email) sendSystemMail(u.email, 'محور — ' + body.slice(0, 70), body + '\n\nافتح النظام: ' + (getSetting('base_url') || '')).catch(() => {});
  }
}

/* ---- تذكير الاستحقاق: كل ساعة، مهام اليوم غير المكتملة ---- */
function startReminders() {
  const tick = () => {
    const due = db.prepare("SELECT * FROM tasks WHERE due=date('now') AND status!='done' AND reminder_sent IS NULL AND assignee_id IS NOT NULL").all();
    for (const t of due) {
      notifyUser(t.assignee_id, `تذكير: مهمة «${t.title}» تستحق اليوم`, true);
      db.prepare("UPDATE tasks SET reminder_sent=datetime('now') WHERE id=?").run(t.id);
    }
    if (due.length) emit();
  };
  setTimeout(tick, 15000); setInterval(tick, 3600000);
}

/* ---- خط معالجة رسالة واردة (مشترك بين IMAP وPOP3 والمحاكاة) ---- */
async function processIncoming(mailbox, parsed) {
  const messageId = parsed.messageId || ('gen-' + crypto.randomUUID());
  if (db.prepare('SELECT id FROM emails WHERE message_id=?').get(messageId)) return null; // منع التكرار

  // التقاط دعوات الاجتماعات (.ics) → التقويم الموحد
  try {
    for (const att of parsed.attachments || []) {
      const isCal = /calendar/i.test(att.contentType || '') || /\.ics$/i.test(att.filename || '');
      if (!isCal) continue;
      const { events } = parseIcs(att.content.toString('utf8'));
      for (const ev of events) {
        if (ev.cancelled && ev.uid) {
          db.prepare("UPDATE events SET status='cancelled' WHERE uid=?").run(ev.uid);
          logAct(`أُلغي اجتماع من التقويم: «${ev.summary}»`);
        } else if (ev.uid && db.prepare('SELECT id FROM events WHERE uid=?').get(ev.uid)) {
          db.prepare('UPDATE events SET title=?,starts_at=?,ends_at=?,location=?,organizer=?,status=\'ok\' WHERE uid=?')
            .run(ev.summary, ev.starts_at, ev.ends_at, ev.location, ev.organizer, ev.uid);
        } else {
          db.prepare("INSERT INTO events(title,starts_at,ends_at,all_day,location,organizer,source,uid,mailbox_id) VALUES (?,?,?,?,?,?,'ics',?,?)")
            .run(ev.summary, ev.starts_at, ev.ends_at, ev.all_day, ev.location, ev.organizer, ev.uid, mailbox.id);
          logAct(`دعوة اجتماع أُضيفت للتقويم: «${ev.summary}»`);
          notifyAll(`دعوة اجتماع جديدة: ${ev.summary}`);
        }
      }
    }
  } catch (e) { logAct('تعذر قراءة دعوة تقويم مرفقة: ' + String(e.message).slice(0, 80)); }

  const fromAddr = (parsed.from && parsed.from.value && parsed.from.value[0]) || {};
  const email = {
    from_name: fromAddr.name || fromAddr.address || 'غير معروف',
    from_email: fromAddr.address || '',
    subject: parsed.subject || '(بدون عنوان)',
    body: (parsed.text || '').trim() || (parsed.html ? String(parsed.html).replace(/<[^>]+>/g, ' ').trim() : ''),
  };

  // سلسلة رد؟ → تعليق على المهمة الأصلية بدل مهمة جديدة
  const refs = [].concat(parsed.inReplyTo || [], parsed.references || []).filter(Boolean);
  for (const ref of refs) {
    const parent = db.prepare('SELECT * FROM emails WHERE message_id=?').get(ref);
    if (parent && parent.task_id) {
      db.prepare('INSERT INTO comments(task_id,user_id,body,is_mail) VALUES (?,NULL,?,1)')
        .run(parent.task_id, `رد جديد من ${email.from_name}:\n${email.body.slice(0, 1500)}`);
      db.prepare('INSERT INTO emails(mailbox_id,message_id,from_name,from_email,subject,body,task_id) VALUES (?,?,?,?,?,?,?)')
        .run(mailbox.id, messageId, email.from_name, email.from_email, email.subject, email.body, parent.task_id);
      logAct(`رد بريدي جديد أُضيف كتعليق على مهمة رقم ${parent.task_id}`);
      notifyAll(`رد جديد من ${email.from_name} على «${parent.subject}»`);
      emit(); return parent.task_id;
    }
  }

  if (!mailbox.default_project_id) {
    db.prepare('INSERT INTO review_queue(from_email,subject,body,reason) VALUES (?,?,?,?)')
      .run(email.from_email, email.subject, email.body, 'الصندوق غير مربوط بمشروع — تصنيف يدوي');
    emit(); return null;
  }

  const ai = await summarizeAndDraft(email);
  const eid = db.prepare('INSERT INTO emails(mailbox_id,message_id,from_name,from_email,subject,body,summary,draft) VALUES (?,?,?,?,?,?,?,?)')
    .run(mailbox.id, messageId, email.from_name, email.from_email, email.subject, email.body, JSON.stringify(ai.summary), ai.draft).lastInsertRowid;
  const tid = db.prepare("INSERT INTO tasks(title,descr,project_id,due,prio,status,src,email_id) VALUES (?,?,?,date('now','+2 day'),'p2','todo','mail',?)")
    .run(email.subject, `وصلت عبر البريد من ${email.from_name} <${email.from_email}> — الملخص والرد الذكي داخل الرسالة المرتبطة.`, mailbox.default_project_id, eid).lastInsertRowid;
  db.prepare('UPDATE emails SET task_id=? WHERE id=?').run(tid, eid);

  // حفظ المرفقات في تخزين الملفات وربطها بالمهمة
  for (const att of parsed.attachments || []) {
    const stored = crypto.randomUUID() + '_' + (att.filename || 'attachment');
    fs.writeFileSync(path.join(__dirname, '..', 'uploads', stored), att.content);
    db.prepare("INSERT INTO files(name,stored,size,mime,src,task_id,email_id) VALUES (?,?,?,?, 'mail',?,?)")
      .run(att.filename || 'مرفق', stored, att.size || att.content.length, att.contentType || '', tid, eid);
  }
  db.prepare('UPDATE mailboxes SET processed=processed+1,last_sync=datetime(\'now\'),status=\'ok\',last_error=NULL WHERE id=?').run(mailbox.id);
  logAct(`بريد وارد تحوّل تلقائياً لمهمة: «${email.subject}»`);
  notifyAll(`بريد جديد تحوّل لمهمة: ${email.subject}`);
  emit(); return tid;
}

/* ---- السحب الدوري ---- */
async function pollMailbox(mb) {
  const pass = dec(mb.pass_enc);
  try {
    if (mb.proto === 'IMAP') {
      const { ImapFlow } = require('imapflow');
      let auth = { user: mb.username, pass };
      if (mb.auth_type === 'oauth_ms') {
        if (!mb.ms_refresh_enc) throw new Error('لم يُربط حساب مايكروسوفت بعد — اضغط «ربط الحساب» في الإعدادات');
        auth = { user: mb.username, accessToken: await msauth.getAccessToken(mb, enc, dec) };
      }
      const client = new ImapFlow({ host: mb.host, port: mb.port || 993, secure: true, auth, logger: false });
      await client.connect();
      const lock = await client.getMailboxLock('INBOX');
      try {
        for await (const msg of client.fetch({ seen: false }, { source: true })) {
          const parsed = await simpleParser(msg.source);
          await processIncoming(mb, parsed);
          await client.messageFlagsAdd(msg.uid, ['\\Seen'], { uid: true });
        }
      } finally { lock.release(); }
      await client.logout();
    } else { // POP3
      const known = new Set(db.prepare('SELECT uid FROM seen_uids WHERE mailbox_id=?').all(mb.id).map(r => r.uid));
      const res = await pop3Fetch({ host: mb.host, port: mb.port || 995, user: mb.username, pass }, known);
      for (const m of res.messages) {
        const parsed = await simpleParser(m.raw);
        await processIncoming(mb, parsed);
        db.prepare('INSERT OR IGNORE INTO seen_uids(mailbox_id,uid) VALUES (?,?)').run(mb.id, m.uid);
      }
    }
    db.prepare("UPDATE mailboxes SET last_sync=datetime('now'),status='ok',last_error=NULL WHERE id=?").run(mb.id);
  } catch (e) {
    db.prepare("UPDATE mailboxes SET status='err',last_error=? WHERE id=?").run(String(e.message).slice(0, 200), mb.id);
    emit();
  }
}

function startPolling() {
  const every = (Number(process.env.MAIL_POLL_SECONDS) || 90) * 1000;
  setInterval(() => {
    for (const mb of db.prepare("SELECT * FROM mailboxes WHERE status!='dev'").all()) pollMailbox(mb).catch(() => {});
  }, every);
}

/* ---- الإرسال عبر SMTP والجدولة ---- */
async function smtpSend(mb, { to, subject, text, inReplyTo }) {
  if (DEV || !mb || !mb.smtp_host) {
    return { dev: true, messageId: '<dev-' + crypto.randomUUID() + '@mihwar.local>' };
  }
  let auth = { user: mb.username, pass: dec(mb.pass_enc) };
  if (mb.auth_type === 'oauth_ms')
    auth = { type: 'OAuth2', user: mb.username, accessToken: await msauth.getAccessToken(mb, enc, dec) };
  const tr = nodemailer.createTransport({ host: mb.smtp_host, port: mb.smtp_port || 587,
    secure: (mb.smtp_port || 587) === 465, auth });
  return tr.sendMail({ from: mb.email, to, subject, text,
    inReplyTo: inReplyTo || undefined, references: inReplyTo || undefined });
}

async function sendReply(emailId, body, userId) {
  const em = db.prepare('SELECT * FROM emails WHERE id=?').get(emailId);
  if (!em) throw new Error('الرسالة غير موجودة');
  const mb = db.prepare('SELECT * FROM mailboxes WHERE id=?').get(em.mailbox_id);
  const info = await smtpSend(mb, { to: em.from_email, subject: 'رد: ' + em.subject, text: body, inReplyTo: em.message_id });
  db.prepare("UPDATE emails SET replied_at=datetime('now'), draft=? WHERE id=?").run(body, emailId);
  if (em.task_id) db.prepare('INSERT INTO comments(task_id,user_id,body,is_mail) VALUES (?,?,?,1)')
    .run(em.task_id, userId, `أُرسل الرد بالبريد إلى ${em.from_email}${info.dev ? ' (وضع تطوير — لم يُرسل فعلياً)' : ''}:\n${body}`);
  logAct(`أُرسل رد بالبريد على «${em.subject}»`);
  emit(); return info;
}

function startScheduler() {
  setInterval(async () => {
    const due = db.prepare("SELECT * FROM scheduled WHERE status='pending' AND send_at<=datetime('now')").all();
    for (const s of due) {
      try {
        await sendReply(s.email_id, s.body, s.created_by);
        db.prepare("UPDATE scheduled SET status='sent' WHERE id=?").run(s.id);
      } catch (e) {
        db.prepare("UPDATE scheduled SET status='failed' WHERE id=?").run(s.id);
      }
      emit();
    }
  }, 30000);
}

function logAct(body) { db.prepare('INSERT INTO activity(body) VALUES (?)').run(body); }
function notifyAll(body) {
  for (const u of db.prepare('SELECT id FROM users WHERE active=1').all())
    db.prepare('INSERT INTO notifications(user_id,body) VALUES (?,?)').run(u.id, body);
}

module.exports = { processIncoming, pollMailbox, startPolling, startScheduler, startReminders, sendReply, enc, dec, onChange, logAct, notifyAll, notifyUser, getSetting, setSetting, sendSystemMail, systemSmtpConfigured, buildIcs };
