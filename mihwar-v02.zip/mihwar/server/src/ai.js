// التلخيص الذكي ومسودات الردود.
// عند توفر ANTHROPIC_API_KEY يُستدعى Claude، وإلا يعمل مولّد احتياطي مبسط حتى لا يتعطل الخط.
const https = require('https');

function callClaude(prompt) {
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return Promise.resolve(null);
  const body = JSON.stringify({
    model: 'claude-sonnet-4-6',
    max_tokens: 900,
    messages: [{ role: 'user', content: prompt }],
  });
  return new Promise((resolve) => {
    const req = https.request({
      hostname: 'api.anthropic.com', path: '/v1/messages', method: 'POST',
      headers: {
        'Content-Type': 'application/json', 'x-api-key': key,
        'anthropic-version': '2023-06-01', 'Content-Length': Buffer.byteLength(body),
      }, timeout: 25000,
    }, (res) => {
      let data = ''; res.on('data', c => data += c);
      res.on('end', () => {
        try { resolve(JSON.parse(data).content.map(c => c.text || '').join('')); }
        catch { resolve(null); }
      });
    });
    req.on('error', () => resolve(null));
    req.on('timeout', () => { req.destroy(); resolve(null); });
    req.write(body); req.end();
  });
}

function fallback(email) {
  const lines = (email.body || '').split('\n').map(s => s.trim()).filter(Boolean);
  const summary = [
    `رسالة من ${email.from_name || email.from_email} بعنوان: ${email.subject}`,
    ...lines.slice(0, 2).map(l => l.length > 110 ? l.slice(0, 110) + '…' : l),
  ];
  const draft = `مرحباً ${email.from_name || ''}،\n\nشكراً لتواصلكم بخصوص «${email.subject}». استلمنا رسالتكم وسنعود إليكم بالرد التفصيلي في أقرب وقت.\n\nمع خالص التحية`;
  return { summary, draft, engine: 'fallback' };
}

async function summarizeAndDraft(email) {
  const prompt = `أنت مساعد داخل نظام إدارة عمل. اقرأ رسالة البريد التالية ثم أعد JSON فقط دون أي نص آخر بالشكل:
{"summary":["نقطة 1","نقطة 2","نقطة 3"],"draft":"نص مسودة رد مهنية"}
اكتب الملخص والمسودة بنفس لغة الرسالة (عربي أو إنجليزي). الملخص 2-4 نقاط موجزة تلتقط الطلب والأهمية والمهلة إن وجدت. المسودة رد مهني مهذب قابل للإرسال مباشرة.

المرسل: ${email.from_name} <${email.from_email}>
العنوان: ${email.subject}
النص:
${(email.body || '').slice(0, 4000)}`;
  const raw = await callClaude(prompt);
  if (raw) {
    try {
      const clean = raw.replace(/```json|```/g, '').trim();
      const j = JSON.parse(clean);
      if (Array.isArray(j.summary) && j.draft) return { summary: j.summary, draft: j.draft, engine: 'claude' };
    } catch { /* يسقط للاحتياطي */ }
  }
  return fallback(email);
}
module.exports = { summarizeAndDraft };
