// واجهات REST — كل التعديلات تمر من هنا وتبث حدث تحديث لحظي لكل المتصلين.
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const crypto = require('crypto');
const path = require('path');
const { simpleParser } = require('mailparser');
const { db } = require('./db');
const mailer = require('./mailer');

const SECRET = process.env.SECRET || 'dev';
const upload = multer({ dest: path.join(__dirname, '..', 'uploads'), limits: { fileSize: 200 * 1024 * 1024 } });
const r = express.Router();
let emit = () => {};
r.onChange = fn => { emit = fn; };

/* ---------- المصادقة والصلاحيات ---------- */
r.post('/auth/login', (req, res) => {
  const { email, password } = req.body || {};
  const u = db.prepare('SELECT * FROM users WHERE email=? AND active=1').get(String(email || '').toLowerCase());
  if (!u || !bcrypt.compareSync(password || '', u.pass)) return res.status(401).json({ error: 'بيانات الدخول غير صحيحة' });
  const token = jwt.sign({ id: u.id, role: u.role }, SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: u.id, name: u.name, email: u.email, role: u.role, color: u.color } });
});

function auth(req, res, next) {
  try {
    const t = (req.headers.authorization || '').replace('Bearer ', '');
    req.user = jwt.verify(t, SECRET);
    const u = db.prepare('SELECT active,role FROM users WHERE id=?').get(req.user.id);
    if (!u || !u.active) throw new Error();
    req.user.role = u.role; next();
  } catch { res.status(401).json({ error: 'انتهت الجلسة — سجّل الدخول من جديد' }); }
}
const canEdit = req => req.user.role !== 'viewer';
const isAdmin = req => ['owner', 'admin'].includes(req.user.role);
function guardEdit(req, res, next) { if (!canEdit(req)) return res.status(403).json({ error: 'صلاحيتك للمشاهدة فقط' }); next(); }
function guardAdmin(req, res, next) { if (!isAdmin(req)) return res.status(403).json({ error: 'تتطلب صلاحية إدارية' }); next(); }
r.use(auth);

/* ---------- الحالة الكاملة (يقرأها العميل بعد كل تحديث لحظي) ---------- */
r.get('/state', (req, res) => {
  const uid = req.user.id;
  res.json({
    me: db.prepare('SELECT id,name,email,role,color FROM users WHERE id=?').get(uid),
    members: db.prepare('SELECT id,name,email,role,color,active,notify_email FROM users').all(),
    products: db.prepare('SELECT * FROM products').all().map(p => ({ ...p,
      releases: db.prepare('SELECT * FROM releases WHERE product_id=? ORDER BY date DESC').all(p.id) })),
    projects: db.prepare('SELECT * FROM projects').all(),
    tasks: db.prepare('SELECT * FROM tasks ORDER BY id DESC').all().map(t => ({ ...t,
      comments: db.prepare('SELECT c.*,u.name uname,u.color ucolor FROM comments c LEFT JOIN users u ON u.id=c.user_id WHERE task_id=? ORDER BY c.id').all(t.id) })),
    emails: db.prepare('SELECT * FROM emails WHERE summary IS NOT NULL ORDER BY id DESC LIMIT 100').all()
      .map(e => ({ ...e, summary: JSON.parse(e.summary || '[]'),
        attachments: db.prepare('SELECT id,name,size FROM files WHERE email_id=?').all(e.id) })),
    review: db.prepare('SELECT * FROM review_queue ORDER BY id DESC').all(),
    scheduled: db.prepare("SELECT s.*,e.subject esubject FROM scheduled s LEFT JOIN emails e ON e.id=s.email_id WHERE s.status='pending' ORDER BY send_at").all(),
    channels: db.prepare('SELECT * FROM channels').all().filter(c => !c.is_dm || c.dm_a === uid || c.dm_b === uid),
    messages: db.prepare('SELECT m.*,u.name uname,u.color ucolor FROM messages m JOIN users u ON u.id=m.user_id ORDER BY m.id').all(),
    files: db.prepare('SELECT f.*,u.name uname FROM files f LEFT JOIN users u ON u.id=f.uploader_id ORDER BY f.id DESC').all(),
    mailboxes: db.prepare("SELECT id,email,proto,host,port,smtp_host,default_project_id,status,last_sync,processed,last_error,auth_type,(ms_refresh_enc IS NOT NULL) ms_linked FROM mailboxes").all(),
    notifications: db.prepare('SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 30').all(uid),
    activity: db.prepare('SELECT * FROM activity ORDER BY id DESC LIMIT 20').all(),
    events: db.prepare("SELECT * FROM events WHERE status='ok' AND starts_at >= datetime('now','-7 day') ORDER BY starts_at LIMIT 300").all(),
    booking: db.prepare('SELECT * FROM booking_settings WHERE user_id=?').get(uid) || null,
    systemMail: { configured: mailer.systemSmtpConfigured(), from: mailer.getSetting('smtp_from') || mailer.getSetting('smtp_user') || '', enabled: mailer.getSetting('notify_email_enabled') !== '0',
      ...(isAdmin(req) ? { host: mailer.getSetting('smtp_host') || '', port: mailer.getSetting('smtp_port') || '587', user: mailer.getSetting('smtp_user') || '' } : {}) },
    baseUrl: mailer.getSetting('base_url') || '',
    devMode: String(process.env.MAIL_DEV_MODE || 'true') === 'true',
  });
});

/* ---------- المهام ---------- */
r.post('/tasks', guardEdit, (req, res) => {
  const { title, project_id, assignee_id, due, prio, descr } = req.body;
  if (!title || !project_id) return res.status(400).json({ error: 'العنوان والمشروع مطلوبان' });
  const id = db.prepare('INSERT INTO tasks(title,descr,project_id,assignee_id,due,prio) VALUES (?,?,?,?,?,?)')
    .run(title, descr || '', project_id, assignee_id || null, due || null, prio || 'p2').lastInsertRowid;
  mailer.logAct(`${name(req)} أنشأ مهمة «${title}»`);
  if (assignee_id && assignee_id !== req.user.id)
    db.prepare('INSERT INTO notifications(user_id,body) VALUES (?,?)').run(assignee_id, `أُسندت إليك مهمة: ${title}`);
  emit(); res.json({ id });
});
r.patch('/tasks/:id', guardEdit, (req, res) => {
  const t = db.prepare('SELECT * FROM tasks WHERE id=?').get(req.params.id);
  if (!t) return res.status(404).json({ error: 'المهمة غير موجودة' });
  const f = { ...t, ...pick(req.body, ['title', 'descr', 'project_id', 'assignee_id', 'due', 'prio', 'status']) };
  db.prepare('UPDATE tasks SET title=?,descr=?,project_id=?,assignee_id=?,due=?,prio=?,status=? WHERE id=?')
    .run(f.title, f.descr, f.project_id, f.assignee_id, f.due, f.prio, f.status, t.id);
  if (req.body.status && req.body.status !== t.status)
    mailer.logAct(`${name(req)} نقل «${t.title}» إلى ${stName(req.body.status)}`);
  if (req.body.assignee_id && req.body.assignee_id !== t.assignee_id && req.body.assignee_id !== req.user.id)
    db.prepare('INSERT INTO notifications(user_id,body) VALUES (?,?)').run(req.body.assignee_id, `أُسندت إليك مهمة: ${t.title}`);
  emit(); res.json({ ok: 1 });
});
r.delete('/tasks/:id', guardEdit, (req, res) => {
  db.prepare('UPDATE files SET task_id=NULL WHERE task_id=?').run(req.params.id); // الملفات تبقى في المكتبة
  db.prepare('DELETE FROM tasks WHERE id=?').run(req.params.id);
  emit(); res.json({ ok: 1 });
});
r.post('/tasks/:id/comments', guardEdit, (req, res) => {
  if (!req.body.body) return res.status(400).json({ error: 'نص التعليق مطلوب' });
  db.prepare('INSERT INTO comments(task_id,user_id,body) VALUES (?,?,?)').run(req.params.id, req.user.id, req.body.body);
  const t = db.prepare('SELECT * FROM tasks WHERE id=?').get(req.params.id);
  if (t && t.assignee_id && t.assignee_id !== req.user.id)
    db.prepare('INSERT INTO notifications(user_id,body) VALUES (?,?)').run(t.assignee_id, `تعليق جديد على «${t.title}»`);
  emit(); res.json({ ok: 1 });
});

/* ---------- البريد ---------- */
r.post('/emails/:id/send', guardEdit, async (req, res) => {
  try { const info = await mailer.sendReply(Number(req.params.id), req.body.body || '', req.user.id);
    res.json({ ok: 1, dev: !!info.dev }); }
  catch (e) { res.status(400).json({ error: e.message }); }
});
r.post('/emails/:id/schedule', guardEdit, (req, res) => {
  const em = db.prepare('SELECT * FROM emails WHERE id=?').get(req.params.id);
  if (!em) return res.status(404).json({ error: 'الرسالة غير موجودة' });
  if (!req.body.send_at) return res.status(400).json({ error: 'حدد موعد الإرسال' });
  db.prepare('INSERT INTO scheduled(email_id,to_email,subject,body,send_at,created_by) VALUES (?,?,?,?,?,?)')
    .run(em.id, em.from_email, 'رد: ' + em.subject, req.body.body || em.draft, req.body.send_at.replace('T', ' '), req.user.id);
  db.prepare('UPDATE emails SET draft=? WHERE id=?').run(req.body.body || em.draft, em.id);
  mailer.logAct(`${name(req)} جدول رداً على «${em.subject}»`); emit(); res.json({ ok: 1 });
});
r.delete('/scheduled/:id', guardEdit, (req, res) => {
  db.prepare("DELETE FROM scheduled WHERE id=? AND status='pending'").run(req.params.id); emit(); res.json({ ok: 1 });
});
r.patch('/emails/:id/draft', guardEdit, (req, res) => { // حفظ تلقائي للمسودة
  db.prepare('UPDATE emails SET draft=? WHERE id=?').run(req.body.draft || '', req.params.id); res.json({ ok: 1 });
});
r.post('/emails/:id/regenerate', guardEdit, async (req, res) => {
  const em = db.prepare('SELECT * FROM emails WHERE id=?').get(req.params.id);
  const ai = await require('./ai').summarizeAndDraft(em);
  db.prepare('UPDATE emails SET summary=?,draft=? WHERE id=?').run(JSON.stringify(ai.summary), ai.draft, em.id);
  emit(); res.json({ ok: 1, engine: ai.engine });
});
r.post('/review/:id/convert', guardEdit, async (req, res) => {
  const rq = db.prepare('SELECT * FROM review_queue WHERE id=?').get(req.params.id);
  if (!rq) return res.status(404).json({ error: 'غير موجودة' });
  const pid = req.body.project_id || db.prepare('SELECT id FROM projects LIMIT 1').get().id;
  const mb = db.prepare('SELECT * FROM mailboxes LIMIT 1').get();
  const tid = await mailer.processIncoming({ ...mb, default_project_id: pid },
    { messageId: 'review-' + rq.id + '-' + Date.now(), subject: rq.subject,
      from: { value: [{ name: rq.from_email, address: rq.from_email }] }, text: rq.body, attachments: [] });
  db.prepare('DELETE FROM review_queue WHERE id=?').run(rq.id); emit(); res.json({ ok: 1, task_id: tid });
});
r.delete('/review/:id', guardEdit, (req, res) => {
  db.prepare('DELETE FROM review_queue WHERE id=?').run(req.params.id); emit(); res.json({ ok: 1 });
});

/* محاكاة بريد وارد — لتجربة الخط كاملاً بدون خادم بريد فعلي */
r.post('/dev/simulate-email', guardEdit, async (req, res) => {
  const mb = db.prepare('SELECT * FROM mailboxes ORDER BY id LIMIT 1').get();
  const raw = `Message-ID: <sim-${Date.now()}@demo.local>\r\nFrom: ${req.body.from_name || 'عميل تجريبي'} <${req.body.from_email || 'client@example.com'}>\r\nSubject: ${req.body.subject || 'رسالة تجريبية'}\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n${req.body.body || 'نص الرسالة التجريبية.'}`;
  const parsed = await simpleParser(Buffer.from(raw));
  const tid = await mailer.processIncoming(mb, parsed);
  res.json({ ok: 1, task_id: tid });
});

/* ---------- الدردشة ---------- */
r.post('/messages', guardEdit, (req, res) => {
  const { channel_id, body } = req.body;
  if (!channel_id || !body) return res.status(400).json({ error: 'القناة والنص مطلوبان' });
  const id = db.prepare('INSERT INTO messages(channel_id,user_id,body) VALUES (?,?,?)').run(channel_id, req.user.id, body).lastInsertRowid;
  // إشارات @
  for (const m of db.prepare('SELECT id,name FROM users').all())
    if (m.id !== req.user.id && body.includes('@' + m.name.split(' ')[0]))
      db.prepare('INSERT INTO notifications(user_id,body) VALUES (?,?)').run(m.id, `${name(req)} أشار إليك في الدردشة`);
  emit(); res.json({ id });
});
r.post('/messages/:id/task', guardEdit, (req, res) => {
  const m = db.prepare('SELECT * FROM messages WHERE id=?').get(req.params.id);
  if (!m) return res.status(404).json({ error: 'الرسالة غير موجودة' });
  const pid = req.body.project_id || db.prepare('SELECT id FROM projects WHERE status=\'نشط\' LIMIT 1').get().id;
  const tid = db.prepare("INSERT INTO tasks(title,descr,project_id,assignee_id,due) VALUES (?,?,?,?,date('now','+3 day'))")
    .run(m.body.slice(0, 80), 'أُنشئت من رسالة دردشة — الرسالة الأصلية مرتبطة بالمهمة.', pid, m.user_id).lastInsertRowid;
  db.prepare('UPDATE messages SET task_id=? WHERE id=?').run(tid, m.id);
  mailer.logAct(`${name(req)} حوّل رسالة دردشة إلى مهمة`); emit(); res.json({ task_id: tid });
});

/* ---------- الملفات ---------- */
r.post('/files', guardEdit, upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'لم يصل أي ملف' });
  const id = db.prepare("INSERT INTO files(name,stored,size,mime,src,uploader_id,task_id) VALUES (?,?,?,?,'upload',?,?)")
    .run(req.file.originalname, req.file.filename, req.file.size, req.file.mimetype, req.user.id, req.body.task_id || null).lastInsertRowid;
  mailer.logAct(`${name(req)} رفع ملف «${req.file.originalname}»`); emit(); res.json({ id });
});
r.get('/files/:id/download', (req, res) => {
  const f = db.prepare('SELECT * FROM files WHERE id=?').get(req.params.id);
  if (!f) return res.status(404).end();
  res.download(path.join(__dirname, '..', 'uploads', f.stored), f.name);
});
r.post('/files/:id/share', guardEdit, (req, res) => {
  const token = crypto.randomBytes(8).toString('hex');
  const pub = req.body.type === 'pub';
  db.prepare("INSERT INTO shares(file_id,token,expires_at) VALUES (?,?,?)")
    .run(req.params.id, token, pub ? new Date(Date.now() + 7 * 864e5).toISOString() : null);
  res.json({ url: (pub ? '/s/' : '/api/files/') + (pub ? token : req.params.id + '/download'), pub });
});

/* ---------- الإعدادات ---------- */
r.post('/mailboxes', guardAdmin, (req, res) => {
  const b = req.body;
  if (!b.email || !b.proto) return res.status(400).json({ error: 'البريد والبروتوكول مطلوبان' });
  const id = db.prepare('INSERT INTO mailboxes(email,proto,host,port,username,pass_enc,smtp_host,smtp_port,default_project_id,auth_type,ms_client_id,ms_client_secret_enc,ms_tenant) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)')
    .run(b.email, b.proto, b.host || null, b.port || (b.proto === 'IMAP' ? 993 : 995), b.username || b.email,
      mailer.enc(b.password || ''), b.smtp_host || null, b.smtp_port || 587, b.default_project_id || null,
      b.auth_type || 'password', b.ms_client_id || null, b.ms_client_secret ? mailer.enc(b.ms_client_secret) : null, b.ms_tenant || 'common').lastInsertRowid;
  const mb = db.prepare('SELECT * FROM mailboxes WHERE id=?').get(id);
  if (mb.auth_type === 'oauth_ms') db.prepare("UPDATE mailboxes SET status='pending', last_error='بانتظار ربط حساب مايكروسوفت' WHERE id=?").run(id);
  else mailer.pollMailbox(mb); // اختبار اتصال فوري
  emit(); res.json({ id });
});
r.delete('/mailboxes/:id', guardAdmin, (req, res) => {
  db.prepare('DELETE FROM mailboxes WHERE id=?').run(req.params.id); emit(); res.json({ ok: 1 });
});
r.post('/mailboxes/:id/sync', guardEdit, async (req, res) => {
  const mb = db.prepare('SELECT * FROM mailboxes WHERE id=?').get(req.params.id);
  if (mb && mb.status !== 'dev') await mailer.pollMailbox(mb);
  emit(); res.json({ ok: 1 });
});
r.patch('/members/:id', guardAdmin, (req, res) => {
  const target = db.prepare('SELECT * FROM users WHERE id=?').get(req.params.id);
  if (!target) return res.status(404).json({ error: 'العضو غير موجود' });
  if (target.role === 'owner') return res.status(403).json({ error: 'لا يمكن تعديل صلاحية المالك' });
  if (req.body.role) db.prepare('UPDATE users SET role=? WHERE id=?').run(req.body.role, target.id);
  if (req.body.active !== undefined) db.prepare('UPDATE users SET active=? WHERE id=?').run(req.body.active ? 1 : 0, target.id);
  mailer.logAct(`${name(req)} عدّل صلاحية ${target.name} (سجل التدقيق)`); emit(); res.json({ ok: 1 });
});
r.post('/notifications/read', (req, res) => {
  db.prepare('UPDATE notifications SET is_read=1 WHERE user_id=?').run(req.user.id); emit(); res.json({ ok: 1 });
});


/* ---------- الملف الشخصي ---------- */
r.patch('/me', (req, res) => {
  if (req.body.name) db.prepare('UPDATE users SET name=? WHERE id=?').run(String(req.body.name).slice(0, 60), req.user.id);
  if (req.body.notify_email !== undefined) db.prepare('UPDATE users SET notify_email=? WHERE id=?').run(req.body.notify_email ? 1 : 0, req.user.id);
  emit(); res.json({ ok: 1 });
});
r.post('/me/password', (req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
  if (!bcrypt.compareSync(req.body.current || '', u.pass)) return res.status(400).json({ error: 'كلمة المرور الحالية غير صحيحة' });
  if (!req.body.newpass || req.body.newpass.length < 8) return res.status(400).json({ error: 'كلمة المرور الجديدة 8 أحرف على الأقل' });
  db.prepare('UPDATE users SET pass=? WHERE id=?').run(bcrypt.hashSync(req.body.newpass, 10), req.user.id);
  res.json({ ok: 1 });
});

/* ---------- دعوة الأعضاء برابط ---------- */
r.post('/members/invite', guardAdmin, (req, res) => {
  const { name: nm, email, role } = req.body;
  if (!nm || !email) return res.status(400).json({ error: 'الاسم والبريد مطلوبان' });
  if (db.prepare('SELECT id FROM users WHERE email=?').get(String(email).toLowerCase()))
    return res.status(400).json({ error: 'هذا البريد مسجل مسبقاً' });
  const token = crypto.randomBytes(16).toString('hex');
  db.prepare('INSERT INTO users(name,email,pass,role,color,active,invite_token,must_set_pass) VALUES (?,?,?,?,?,1,?,1)')
    .run(nm, String(email).toLowerCase(), bcrypt.hashSync(crypto.randomUUID(), 10), role || 'member',
      ['#5B4BAE', '#2B5E9E', '#B3372F', '#A16207', '#1E8E5A'][db.prepare('SELECT COUNT(*) c FROM users').get().c % 5], token);
  mailer.logAct(`${name(req)} دعا عضواً جديداً: ${nm}`);
  const base = mailer.getSetting('base_url') || (req.protocol + '://' + req.get('host'));
  const link = base + '/invite/' + token;
  // إن كان بريد النظام مهيأً نرسل الدعوة تلقائياً أيضاً
  mailer.sendSystemMail(email, 'دعوة للانضمام إلى محور', `مرحباً ${nm}،\n\nدُعيت للانضمام لنظام محور. افتح الرابط لتعيين كلمة مرورك:\n${link}`).catch(() => {});
  emit(); res.json({ ok: 1, link });
});

/* ---------- مشاريع ومنتجات من الواجهة ---------- */
r.post('/projects', guardEdit, (req, res) => {
  if (!req.body.name) return res.status(400).json({ error: 'اسم المشروع مطلوب' });
  const id = db.prepare('INSERT INTO projects(name,color,product_id) VALUES (?,?,?)')
    .run(req.body.name, req.body.color || '#0E766B', req.body.product_id || null).lastInsertRowid;
  mailer.logAct(`${name(req)} أنشأ مشروع «${req.body.name}»`); emit(); res.json({ id });
});
r.patch('/projects/:id', guardEdit, (req, res) => {
  if (req.body.status) db.prepare('UPDATE projects SET status=? WHERE id=?').run(req.body.status, req.params.id);
  emit(); res.json({ ok: 1 });
});
r.post('/products', guardEdit, (req, res) => {
  if (!req.body.name) return res.status(400).json({ error: 'اسم المنتج مطلوب' });
  const id = db.prepare('INSERT INTO products(name,descr,owner_id) VALUES (?,?,?)')
    .run(req.body.name, req.body.descr || '', req.user.id).lastInsertRowid;
  mailer.logAct(`${name(req)} أضاف منتج «${req.body.name}»`); emit(); res.json({ id });
});

/* ---------- بريد النظام (إيميلات التنبيه) ---------- */
r.post('/system-smtp', guardAdmin, (req, res) => {
  const b = req.body;
  mailer.setSetting('smtp_host', b.host || ''); mailer.setSetting('smtp_port', String(b.port || 587));
  mailer.setSetting('smtp_user', b.user || ''); mailer.setSetting('smtp_from', b.from || b.user || '');
  if (b.pass) mailer.setSetting('smtp_pass_enc', mailer.enc(b.pass));
  mailer.setSetting('notify_email_enabled', b.enabled === false ? '0' : '1');
  if (b.base_url) mailer.setSetting('base_url', String(b.base_url).replace(/\/$/, ''));
  emit(); res.json({ ok: 1 });
});
r.post('/system-smtp/test', guardAdmin, async (req, res) => {
  try {
    const me = db.prepare('SELECT email FROM users WHERE id=?').get(req.user.id);
    const info = await mailer.sendSystemMail(me.email, 'محور — رسالة اختبار', 'إعداد بريد النظام يعمل بنجاح ✓');
    res.json({ ok: 1, dev: !!info.dev, skipped: !!info.skipped, to: me.email });
  } catch (e) { res.status(400).json({ error: 'فشل الإرسال: ' + e.message }); }
});

/* ---------- التقويم: أحداث يدوية ---------- */
r.post('/events', guardEdit, (req, res) => {
  const b = req.body;
  if (!b.title || !b.starts_at) return res.status(400).json({ error: 'العنوان ووقت البداية مطلوبان' });
  const id = db.prepare("INSERT INTO events(title,starts_at,ends_at,location,notes,source,user_id) VALUES (?,?,?,?,?,'manual',?)")
    .run(b.title, b.starts_at, b.ends_at || null, b.location || '', b.notes || '', req.user.id).lastInsertRowid;
  mailer.logAct(`${name(req)} أضاف للتقويم: «${b.title}»`); emit(); res.json({ id });
});
r.delete('/events/:id', guardEdit, (req, res) => {
  db.prepare('DELETE FROM events WHERE id=?').run(req.params.id); emit(); res.json({ ok: 1 });
});

/* ---------- إعدادات رابط الحجز ---------- */
r.post('/booking-settings', (req, res) => {
  const b = req.body;
  const slug = String(b.slug || '').toLowerCase().replace(/[^a-z0-9-]/g, '');
  if (b.enabled && !slug) return res.status(400).json({ error: 'حدد معرّف الرابط بأحرف إنجليزية' });
  const taken = slug && db.prepare('SELECT user_id FROM booking_settings WHERE slug=? AND user_id!=?').get(slug, req.user.id);
  if (taken) return res.status(400).json({ error: 'هذا المعرّف مستخدم لعضو آخر' });
  db.prepare(`INSERT INTO booking_settings(user_id,slug,enabled,duration,days,start_hour,end_hour,title)
    VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET slug=excluded.slug,enabled=excluded.enabled,
    duration=excluded.duration,days=excluded.days,start_hour=excluded.start_hour,end_hour=excluded.end_hour,title=excluded.title`)
    .run(req.user.id, slug || null, b.enabled ? 1 : 0, Number(b.duration) || 30, b.days || '0,1,2,3,4',
      Number(b.start_hour) ?? 9, Number(b.end_hour) ?? 17, b.title || 'اجتماع');
  emit(); res.json({ ok: 1 });
});

/* ---------- ربط مايكروسوفت: رابط التفويض ---------- */
r.get('/mailboxes/:id/ms-auth-url', guardAdmin, (req, res) => {
  const mb = db.prepare('SELECT * FROM mailboxes WHERE id=?').get(req.params.id);
  if (!mb || mb.auth_type !== 'oauth_ms') return res.status(400).json({ error: 'الصندوق ليس بنمط مايكروسوفت OAuth2' });
  if (!mb.ms_client_id) return res.status(400).json({ error: 'أدخل Client ID أولاً' });
  const base = mailer.getSetting('base_url');
  if (!base) return res.status(400).json({ error: 'اضبط رابط النظام الأساسي أولاً في إعدادات بريد النظام (مثال: https://t.do.sa)' });
  const state = jwt.sign({ mb: mb.id }, SECRET, { expiresIn: '15m' });
  res.json({ url: require('./msauth').authUrl(mb, base, state) });
});

/* ---------- البحث الموحد ---------- */
r.get('/search', (req, res) => {
  const q = '%' + (req.query.q || '') + '%';
  res.json({
    tasks: db.prepare('SELECT id,title FROM tasks WHERE title LIKE ? LIMIT 5').all(q),
    projects: db.prepare('SELECT id,name FROM projects WHERE name LIKE ? LIMIT 4').all(q),
    emails: db.prepare('SELECT id,subject,from_name FROM emails WHERE (subject LIKE ? OR from_name LIKE ? OR body LIKE ?) AND summary IS NOT NULL LIMIT 4').all(q, q, q),
    files: db.prepare('SELECT id,name FROM files WHERE name LIKE ? LIMIT 4').all(q),
    messages: db.prepare('SELECT id,channel_id,body FROM messages WHERE body LIKE ? LIMIT 4').all(q),
  });
});

function pick(o, ks) { const r2 = {}; ks.forEach(k => { if (o[k] !== undefined) r2[k] = o[k]; }); return r2; }
function name(req) { return db.prepare('SELECT name FROM users WHERE id=?').get(req.user.id).name; }
function stName(s) { return { todo: 'قيد الانتظار', inprog: 'قيد التنفيذ', review: 'قيد المراجعة', done: 'مكتملة' }[s] || s; }
module.exports = r;
