// مصادقة Microsoft 365 عبر OAuth2 — لأن مايكروسوفت أوقفت كلمات المرور العادية لـIMAP
const https = require('https');
const { db } = require('./db');
const tokenCache = new Map(); // mailboxId -> {token, exp}

function form(obj) { return Object.entries(obj).map(([k, v]) => k + '=' + encodeURIComponent(v)).join('&'); }
function post(host, path, body) {
  return new Promise((resolve, reject) => {
    const data = form(body);
    const req = https.request({ host, path, method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Content-Length': Buffer.byteLength(data) },
      timeout: 20000 }, res => {
      let out = ''; res.on('data', c => out += c);
      res.on('end', () => { try { resolve(JSON.parse(out)); } catch { reject(new Error('رد غير مفهوم من مايكروسوفت')); } });
    });
    req.on('error', reject); req.on('timeout', () => { req.destroy(); reject(new Error('انتهت مهلة الاتصال بمايكروسوفت')); });
    req.write(data); req.end();
  });
}

const SCOPES = 'offline_access https://outlook.office365.com/IMAP.AccessAsUser.All https://outlook.office365.com/SMTP.Send';

function authUrl(mb, baseUrl, state) {
  return `https://login.microsoftonline.com/${mb.ms_tenant || 'common'}/oauth2/v2.0/authorize?` + form({
    client_id: mb.ms_client_id, response_type: 'code',
    redirect_uri: baseUrl + '/api/ms-callback', response_mode: 'query',
    scope: SCOPES, state, login_hint: mb.email,
  }).replace(/&/g, '&');
}

async function exchangeCode(mb, code, baseUrl, dec) {
  const j = await post('login.microsoftonline.com', `/${mb.ms_tenant || 'common'}/oauth2/v2.0/token`, {
    client_id: mb.ms_client_id, client_secret: dec(mb.ms_client_secret_enc), code,
    redirect_uri: baseUrl + '/api/ms-callback', grant_type: 'authorization_code', scope: SCOPES,
  });
  if (!j.refresh_token) throw new Error(j.error_description || 'لم يصل refresh_token');
  return j; // {access_token, refresh_token, expires_in}
}

async function getAccessToken(mb, enc, dec) {
  const c = tokenCache.get(mb.id);
  if (c && c.exp > Date.now() + 60000) return c.token;
  const j = await post('login.microsoftonline.com', `/${mb.ms_tenant || 'common'}/oauth2/v2.0/token`, {
    client_id: mb.ms_client_id, client_secret: dec(mb.ms_client_secret_enc),
    refresh_token: dec(mb.ms_refresh_enc), grant_type: 'refresh_token', scope: SCOPES,
  });
  if (!j.access_token) throw new Error('فشل تجديد رمز مايكروسوفت: ' + (j.error_description || '').slice(0, 120));
  if (j.refresh_token) db.prepare('UPDATE mailboxes SET ms_refresh_enc=? WHERE id=?').run(enc(j.refresh_token), mb.id);
  tokenCache.set(mb.id, { token: j.access_token, exp: Date.now() + (j.expires_in || 3600) * 1000 });
  return j.access_token;
}
module.exports = { authUrl, exchangeCode, getAccessToken };
