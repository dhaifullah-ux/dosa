// محرك الذكاء الاصطناعي — مكوّن نظام بثلاثة أوضاع تُدار من الإعدادات:
//  anthropic: المحرك الافتراضي (Claude — أفضل جودة عربي/إنجليزي)
//  custom:    ربط AI خاص عبر أي خدمة متوافقة مع OpenAI API (يشمل نماذج ذاتية الاستضافة Ollama/vLLM)
//  off:       المولّد الاحتياطي المدمج فقط
const https = require('https');
const http = require('http');

let deps = null; // حقن متأخر لكسر الاعتماد الدائري مع mailer
function init(d) { deps = d; }
function cfg(k, fb) { try { return (deps && deps.getSetting(k)) || fb || null; } catch { return fb || null; } }

function jsonPost(urlStr, headers, bodyObj) {
  return new Promise((resolve) => {
    const u = new URL(urlStr);
    const body = JSON.stringify(bodyObj);
    const mod = u.protocol === 'http:' ? http : https;
    const req = mod.request({ hostname: u.hostname, port: u.port || (u.protocol === 'http:' ? 80 : 443),
      path: u.pathname + u.search, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body), ...headers },
      timeout: 30000 }, (res) => {
      let data = ''; res.on('data', c => data += c);
      res.on('end', () => { try { resolve(JSON.parse(data)); } catch { resolve(null); } });
    });
    req.on('error', () => resolve(null));
    req.on('timeout', () => { req.destroy(); resolve(null); });
    req.write(body); req.end();
  });
}

async function complete(prompt) {
  const provider = cfg('ai_provider', process.env.ANTHROPIC_API_KEY ? 'anthropic' : 'off');
  if (provider === 'anthropic') {
    const key = (deps && deps.dec && cfg('ai_api_key_enc') ? deps.dec(cfg('ai_api_key_enc')) : null) || process.env.ANTHROPIC_API_KEY;
    if (!key) return null;
    const j = await jsonPost('https://api.anthropic.com/v1/messages',
      { 'x-api-key': key, 'anthropic-version': '2023-06-01' },
      { model: cfg('ai_model', 'claude-sonnet-4-6'), max_tokens: 900, messages: [{ role: 'user', content: prompt }] });
    return j && j.content ? j.content.map(c => c.text || '').join('') : null;
  }
  if (provider === 'custom') {
    const base = cfg('ai_base_url'); if (!base) return null;
    const key = cfg('ai_custom_key_enc') && deps ? deps.dec(cfg('ai_custom_key_enc')) : '';
    const j = await jsonPost(base.replace(/\/$/, '') + '/chat/completions',
      key ? { Authorization: 'Bearer ' + key } : {},
      { model: cfg('ai_model', 'gpt-4o-mini'), messages: [{ role: 'user', content: prompt }], max_tokens: 900 });
    return j && j.choices && j.choices[0] ? j.choices[0].message.content : null;
  }
  return null; // off → احتياطي
}

function fallback(email) {
  const lines = (email.body || '').split('\n').map(s => s.trim()).filter(Boolean);
  return {
    summary: [`رسالة من ${email.from_name || email.from_email} بعنوان: ${email.subject}`,
      ...lines.slice(0, 2).map(l => l.length > 110 ? l.slice(0, 110) + '…' : l)],
    draft: `مرحباً ${email.from_name || ''}،\n\nشكراً لتواصلكم بخصوص «${email.subject}». استلمنا رسالتكم وسنعود إليكم بالرد التفصيلي في أقرب وقت.\n\nمع خالص التحية`,
    task_title: email.subject,
    engine: 'fallback',
  };
}

async function summarizeAndDraft(email) {
  const prompt = `أنت محرك الذكاء داخل نظام إدارة عمل. اقرأ رسالة البريد ثم أعد JSON فقط دون أي نص آخر:
{"summary":["نقطة","نقطة"],"draft":"مسودة رد مهنية","task_title":"عنوان مهمة موجز فعّال (فعل أمر) يصف المطلوب"}
اكتب كل شيء بنفس لغة الرسالة (عربي أو إنجليزي). الملخص 2-4 نقاط تلتقط الطلب والأهمية والمهلة. task_title بصيغة مهمة عمل لا نسخاً للعنوان.

المرسل: ${email.from_name} <${email.from_email}>
العنوان: ${email.subject}
النص:
${(email.body || '').slice(0, 4000)}`;
  const raw = await complete(prompt);
  if (raw) {
    try {
      const j = JSON.parse(raw.replace(/```json|```/g, '').trim());
      if (Array.isArray(j.summary) && j.draft)
        return { summary: j.summary, draft: j.draft, task_title: j.task_title || email.subject,
          engine: cfg('ai_provider', 'anthropic') };
    } catch { /* يسقط للاحتياطي */ }
  }
  return fallback(email);
}

async function testEngine() {
  const raw = await complete('أعد JSON فقط: {"ok":true,"lang":"ar"}');
  if (!raw) return { ok: false, error: 'لم يصل رد من المحرك — تحقق من المفتاح/الرابط' };
  try { const j = JSON.parse(raw.replace(/```json|```/g, '').trim()); return { ok: !!j.ok }; }
  catch { return { ok: true, note: 'المحرك يرد لكن ليس بصيغة JSON منضبطة' }; }
}

module.exports = { summarizeAndDraft, testEngine, init };
