// قراءة وتوليد ملفات التقويم iCalendar (.ics) — دعوات الاجتماعات
function unfold(text) { return String(text).replace(/\r\n[ \t]/g, '').replace(/\n[ \t]/g, ''); }

function parseDate(val, params) {
  // صيغ: 20260705T090000Z | TZID=..:20260705T090000 | VALUE=DATE:20260705
  const m = String(val).match(/(\d{4})(\d{2})(\d{2})(?:T(\d{2})(\d{2})(\d{2})?(Z)?)?/);
  if (!m) return { iso: null, allDay: false };
  const [, Y, Mo, D, H, Mi, , Z] = m;
  if (!H) return { iso: `${Y}-${Mo}-${D}T00:00:00`, allDay: true };
  return { iso: `${Y}-${Mo}-${D}T${H}:${Mi}:00${Z ? 'Z' : ''}`, allDay: false };
}

function parseIcs(text) {
  const t = unfold(text);
  const method = (t.match(/^METHOD:(.+)$/m) || [])[1] || 'REQUEST';
  const events = [];
  const blocks = t.split('BEGIN:VEVENT').slice(1);
  for (const b of blocks) {
    const body = b.split('END:VEVENT')[0];
    const get = (k) => {
      const mm = body.match(new RegExp('^' + k + '(;[^:]*)?:(.*)$', 'm'));
      return mm ? { params: mm[1] || '', val: mm[2].trim() } : null;
    };
    const ds = get('DTSTART'), de = get('DTEND');
    const st = ds ? parseDate(ds.val, ds.params) : { iso: null };
    if (!st.iso) continue;
    const en = de ? parseDate(de.val, de.params) : { iso: null };
    events.push({
      uid: get('UID') ? get('UID').val : null,
      summary: get('SUMMARY') ? get('SUMMARY').val.replace(/\\,/g, ',').replace(/\\n/g, ' ') : '(اجتماع بدون عنوان)',
      location: get('LOCATION') ? get('LOCATION').val.replace(/\\,/g, ',') : '',
      organizer: get('ORGANIZER') ? get('ORGANIZER').val.replace(/^mailto:/i, '') : '',
      starts_at: st.iso, ends_at: en.iso, all_day: st.allDay ? 1 : 0,
      cancelled: /STATUS:CANCELLED/.test(body) || method.trim().toUpperCase() === 'CANCEL',
    });
  }
  return { method: method.trim().toUpperCase(), events };
}

function icsDate(iso) {
  const d = new Date(iso);
  return d.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
}

function buildIcs({ uid, title, starts_at, ends_at, location, organizerEmail, organizerName, attendeeEmail, attendeeName, description }) {
  return ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Mihwar//AR', 'METHOD:REQUEST', 'BEGIN:VEVENT',
    `UID:${uid}`, `DTSTAMP:${icsDate(new Date().toISOString())}`,
    `DTSTART:${icsDate(starts_at)}`, `DTEND:${icsDate(ends_at)}`,
    `SUMMARY:${title}`, location ? `LOCATION:${location}` : '',
    description ? `DESCRIPTION:${String(description).replace(/\n/g, '\\n')}` : '',
    organizerEmail ? `ORGANIZER;CN=${organizerName || organizerEmail}:mailto:${organizerEmail}` : '',
    attendeeEmail ? `ATTENDEE;CN=${attendeeName || attendeeEmail};RSVP=TRUE:mailto:${attendeeEmail}` : '',
    'END:VEVENT', 'END:VCALENDAR'].filter(Boolean).join('\r\n');
}
module.exports = { parseIcs, buildIcs };
