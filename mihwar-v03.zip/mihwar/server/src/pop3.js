// عميل POP3 مصغّر عبر TLS — يكفي احتياجنا: UIDL لاكتشاف الجديد ثم RETR لسحبه.
// POP3 لا يوفر مزامنة حالة، لذا نتتبع UIDL محلياً ونُبقي نسخة الرسالة في الخادم (لا نستخدم DELE).
const tls = require('tls');

function pop3Fetch({ host, port = 995, user, pass }, knownUids) {
  return new Promise((resolve, reject) => {
    const sock = tls.connect({ host, port, rejectUnauthorized: false, timeout: 15000 });
    let buf = '', queue = [], multiline = false, current = null;
    const results = { uids: [], messages: [] };
    const send = (cmd, ml) => new Promise((res, rej2) => { queue.push({ res, rej: rej2, ml: !!ml }); sock.write(cmd + '\r\n'); });
    sock.on('error', reject);
    sock.setTimeout(20000, () => { sock.destroy(); reject(new Error('POP3 timeout')); });

    sock.on('data', (d) => {
      buf += d.toString('binary');
      while (true) {
        if (!current) {
          const i = buf.indexOf('\r\n'); if (i < 0) return;
          const line = buf.slice(0, i); buf = buf.slice(i + 2);
          if (queue.length === 0) { continue; } // ترحيب الخادم
          current = queue.shift();
          if (line.startsWith('-ERR')) { current.rej(new Error(line)); current = null; continue; }
          if (!current.ml) { current.res(line); current = null; continue; }
          multiline = true; current.data = '';
        }
        if (multiline) {
          const end = buf.indexOf('\r\n.\r\n');
          if (end < 0) return;
          current.data += buf.slice(0, end); buf = buf.slice(end + 5);
          current.res(current.data.replace(/^\.\./gm, '.')); current = null; multiline = false;
        }
      }
    });

    sock.on('secureConnect', async () => {
      try {
        // الترحيب يُستهلك أعلاه؛ نمهل لحظة ثم نصادق
        await new Promise(r => setTimeout(r, 300));
        await send('USER ' + user);
        await send('PASS ' + pass);
        const uidl = await send('UIDL', true);
        const entries = uidl.split('\r\n').filter(Boolean).map(l => l.trim().split(' '));
        for (const [num, uid] of entries) {
          results.uids.push(uid);
          if (!knownUids.has(uid)) {
            const raw = await send('RETR ' + num, true);
            results.messages.push({ uid, raw: Buffer.from(raw, 'binary') });
          }
        }
        await send('QUIT'); sock.end(); resolve(results);
      } catch (e) { sock.destroy(); reject(e); }
    });
  });
}
module.exports = { pop3Fetch };
