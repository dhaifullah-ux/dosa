// واجهات REST — كل التعديلات تمر من هنا وتبث حدث تحديث لحظي لكل المتصلين.
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const crypto = require('crypto');
const path = require('path');
const { simpleParser } = require('mailparser');
const { db } = require('./db');
const mailer = require('./mailer');

const SECRET = process.env.SECRET || 'dev';
const upload = multer({ dest: path.join(__dirname, '..', 'uploads'), limits: { fileSize: 200 * 1024 * 1024 } });
const r = express.Router();
let emit = () => {};
r.onChange = fn => { emit = fn; };

/* ---------- المصادقة والصلاحيات ---------- */
r.post('/auth/login', (req, res) => {
  const { email, password } = req.body || {};
  const u = db.prepare('SELECT * FROM users WHERE email=? AND active=1').get(String(email || '').toLowerCase());
  if (!u || !bcrypt.compareSync(password || '', u.pass)) return res.status(401).json({ error: 'بيانات الدخول غير صحيحة' });
  const token = jwt.sign({ id: u.id, role: u.role }, SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: u.id, name: u.name, email: u.email, role: u.role, color: u.color } });
});

function auth(req, res, next) {
  try {
    const t = (req.headers.authorization || '').replace('Bearer ', '');
    req.user = jwt.verify(t, SECRET);
    const u = db.prepare('SELECT active,is_super FROM users WHERE id=?').get(req.user.id);
    if (!u || !u.active) throw new Error();
    req.user.super = !!u.is_super;
    req.user.memberships = db.prepare('SELECT tenant_id,role FROM memberships WHERE user_id=?').all(req.user.id);
    req.tenantIds = req.user.memberships.map(m => m.tenant_id);
    const h = req.headers['x-tenant'];
    req.tenant = (h && h !== 'all' && req.tenantIds.includes(Number(h))) ? Number(h) : null; // null = كل جهاتي
    next();
  } catch { res.status(401).json({ error: 'انتهت الجلسة — سجّل الدخول من جديد' }); }
}
const roleIn = (req, tid) => (req.user.memberships.find(m => m.tenant_id === Number(tid)) || {}).role || null;
const canEditIn = (req, tid) => ['owner', 'admin', 'member'].includes(roleIn(req, tid));
const isAdminIn = (req, tid) => ['owner', 'admin'].includes(roleIn(req, tid));
// توافق خلفي: على مستوى "أي جهة من جهاتي"
const canEdit = req => req.user.memberships.some(m => m.role !== 'viewer');
const isAdmin = req => req.user.super || req.user.memberships.some(m => ['owner', 'admin'].includes(m.role));
const tenantOfProject = pid => (db.prepare('SELECT tenant_id t FROM projects WHERE id=?').get(pid) || {}).t;
const tenantOfTask = tid2 => (db.prepare('SELECT tenant_id t FROM tasks WHERE id=?').get(tid2) || {}).t;
function guardEdit(req, res, next) { if (!canEdit(req)) return res.status(403).json({ error: 'صلاحيتك للمشاهدة فقط' }); next(); }
function guardAdmin(req, res, next) { if (!isAdmin(req)) return res.status(403).json({ error: 'تتطلب صلاحية إدارية' }); next(); }
r.use(auth);

/* ---------- الحالة الكاملة (يقرأها العميل بعد كل تحديث لحظي) ---------- */
r.get('/state', (req, res) => {
  const uid = req.user.id;
  const tids = req.tenant ? [req.tenant] : req.tenantIds;
  const TIN = tids.length ? `(${tids.join(',')})` : '(-1)';
  res.json({
    tenants: db.prepare(`SELECT t.*, m.role my_role FROM tenants t JOIN memberships m ON m.tenant_id=t.id AND m.user_id=? ORDER BY t.id`).all(uid),
    curTenant: req.tenant,
    me: { ...db.prepare('SELECT id,name,email,color,is_super FROM users WHERE id=?').get(uid), role: req.user.super ? 'owner' : (req.user.memberships[0] || {}).role || 'viewer', super: req.user.super },
    members: db.prepare(`SELECT DISTINCT u.id,u.name,u.email,u.color,u.active,u.notify_email, (SELECT role FROM memberships WHERE user_id=u.id AND tenant_id=?) role FROM users u JOIN memberships m ON m.user_id=u.id WHERE m.tenant_id IN ${TIN}`).all(req.tenant || tids[0] || -1),
    products: db.prepare(`SELECT * FROM products WHERE tenant_id IN ${TIN}`).all().map(p => ({ ...p,
      releases: db.prepare('SELECT * FROM releases WHERE product_id=? ORDER BY date DESC').all(p.id) })),
    projects: db.prepare(`SELECT * FROM projects WHERE tenant_id IN ${TIN}`).all(),
    tasks: db.prepare(`SELECT * FROM tasks WHERE deleted_at IS NULL AND tenant_id IN ${TIN} ORDER BY id DESC`).all().map(t => ({ ...t,
      comments: db.prepare('SELECT c.*,u.name uname,u.color ucolor FROM comments c LEFT JOIN users u ON u.id=c.user_id WHERE task_id=? ORDER BY c.id').all(t.id) })),
    emails: db.prepare(`SELECT e.*, mb.scope mb_scope, mb.owner_id mb_owner FROM emails e LEFT JOIN mailboxes mb ON mb.id=e.mailbox_id
      WHERE e.summary IS NOT NULL AND ((mb.scope='team' AND mb.tenant_id IN ${TIN}) OR mb.owner_id=? OR (e.mailbox_id IS NULL)) ORDER BY e.id DESC LIMIT 120`).all(uid)
      .filter(e => e.mb_scope === 'personal' ? e.mb_owner === uid : canEdit(req))
      .map(e => ({ ...e, summary: JSON.parse(e.summary || '[]'),
        attachments: db.prepare('SELECT id,name,size FROM files WHERE email_id=? AND deleted_at IS NULL').all(e.id) })),
    review: db.prepare(`SELECT * FROM review_queue WHERE tenant_id IN ${TIN} OR tenant_id IS NULL ORDER BY id DESC`).all(),
    scheduled: db.prepare("SELECT s.*,e.subject esubject FROM scheduled s LEFT JOIN emails e ON e.id=s.email_id WHERE s.status='pending' ORDER BY send_at").all(),
    channels: db.prepare(`SELECT * FROM channels WHERE (is_dm=1 AND (dm_a=? OR dm_b=?)) OR tenant_id IN ${TIN}`).all(uid, uid),
    messages: db.prepare(`SELECT m.*,u.name uname,u.color ucolor FROM messages m JOIN users u ON u.id=m.user_id JOIN channels c ON c.id=m.channel_id WHERE (c.is_dm=1 AND (c.dm_a=? OR c.dm_b=?)) OR c.tenant_id IN ${TIN} ORDER BY m.id`).all(uid, uid),
    files: db.prepare(`SELECT f.*,u.name uname FROM files f LEFT JOIN users u ON u.id=f.uploader_id
      LEFT JOIN emails e ON e.id=f.email_id LEFT JOIN mailboxes mb ON mb.id=e.mailbox_id
      WHERE f.deleted_at IS NULL AND ((f.tenant_id IN ${TIN}) OR mb.owner_id=? OR (f.uploader_id=? AND f.tenant_id IS NULL))
      ORDER BY f.id DESC`).all(uid, uid),
    trash: isAdmin(req) ? {
      files: db.prepare("SELECT f.id,f.name,f.size,f.deleted_at,u.name dname, CAST(180 - julianday('now') + julianday(f.deleted_at) AS INTEGER) days_left FROM files f LEFT JOIN users u ON u.id=f.deleted_by WHERE f.deleted_at IS NOT NULL ORDER BY f.deleted_at DESC").all(),
      tasks: db.prepare("SELECT t.id,t.title,t.deleted_at,u.name dname, CAST(180 - julianday('now') + julianday(t.deleted_at) AS INTEGER) days_left FROM tasks t LEFT JOIN users u ON u.id=t.deleted_by WHERE t.deleted_at IS NOT NULL ORDER BY t.deleted_at DESC").all(),
    } : { files: [], tasks: [] },
    mailboxes: db.prepare("SELECT m.id,m.email,m.proto,m.host,m.port,m.username,m.smtp_host,m.smtp_port,m.default_project_id,m.status,m.last_sync,m.processed,m.last_error,m.auth_type,m.ms_client_id,m.ms_tenant,m.scope,m.owner_id,(m.ms_refresh_enc IS NOT NULL) ms_linked,u.name owner_name FROM mailboxes m LEFT JOIN users u ON u.id=m.owner_id").all()
      .filter(m => m.scope === 'personal' ? (m.owner_id === uid || req.user.super) : (m.tenant_id && tids.includes(m.tenant_id))),
    notifications: db.prepare('SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 30').all(uid),
    activity: db.prepare(`SELECT * FROM activity WHERE tenant_id IN ${TIN} OR tenant_id IS NULL ORDER BY id DESC LIMIT 20`).all(),
    events: db.prepare(`SELECT * FROM events WHERE status='ok' AND starts_at >= datetime('now','-7 day') AND (user_id=? OR tenant_id IN ${TIN}) ORDER BY starts_at LIMIT 300`).all(uid),
    bookingTypes: db.prepare('SELECT * FROM booking_types WHERE user_id=?').all(uid),
    reads: Object.fromEntries(db.prepare('SELECT channel_id,last_read FROM channel_reads WHERE user_id=?').all(uid).map(r => [r.channel_id, r.last_read])),
    mailTaskMode: mailer.getSetting('mail_task_mode') || 'auto',
    ai: { provider: mailer.getSetting('ai_provider') || (process.env.ANTHROPIC_API_KEY ? 'anthropic' : 'off'),
      model: mailer.getSetting('ai_model') || '', baseUrl: mailer.getSetting('ai_base_url') || '',
      keySet: !!(mailer.getSetting('ai_api_key_enc') || process.env.ANTHROPIC_API_KEY), customKeySet: !!mailer.getSetting('ai_custom_key_enc') },
    systemMail: { configured: mailer.systemSmtpConfigured(), from: mailer.getSetting('smtp_from') || mailer.getSetting('smtp_user') || '', enabled: mailer.getSetting('notify_email_enabled') !== '0',
      ...(isAdmin(req) ? { host: mailer.getSetting('smtp_host') || '', port: mailer.getSetting('smtp_port') || '587', user: mailer.getSetting('smtp_user') || '' } : {}) },
    baseUrl: mailer.getSetting('base_url') || '',
    devMode: String(process.env.MAIL_DEV_MODE || 'true') === 'true',
  });
});

/* ---------- المهام ---------- */
r.post('/tasks', guardEdit, (req, res) => {
  const { title, project_id, assignee_id, due, prio, descr } = req.body;
  if (!title || !project_id) return res.status(400).json({ error: 'العنوان والمشروع مطلوبان' });
  const tt = tenantOfProject(project_id);
  if (!canEditIn(req, tt)) return res.status(403).json({ error: 'ليست لديك صلاحية تحرير في هذه الجهة' });
  const id = db.prepare('INSERT INTO tasks(title,descr,project_id,assignee_id,due,prio,tenant_id) VALUES (?,?,?,?,?,?,'+tt+')')
    .run(title, descr || '', project_id, assignee_id || null, due || null, prio || 'p2').lastInsertRowid;
  mailer.logAct(`${name(req)} أنشأ مهمة «${title}»`);
  if (assignee_id && assignee_id !== req.user.id)
    db.prepare('INSERT INTO notifications(user_id,body) VALUES (?,?)').run(assignee_id, `أُسندت إليك مهمة: ${title}`);
  emit(); res.json({ id });
});
r.patch('/tasks/:id', guardEdit, (req, res) => {
  const t = db.prepare('SELECT * FROM tasks WHERE id=?').get(req.params.id);
  if (!t) return res.status(404).json({ error: 'المهمة غير موجودة' });
  if (!canEditIn(req, t.tenant_id)) return res.status(403).json({ error: 'ليست لديك صلاحية تحرير في جهة هذه المهمة' });
  if (req.body.project_id && req.body.project_id !== t.project_id) {
    const nt = tenantOfProject(req.body.project_id);
    if (!canEditIn(req, nt)) return res.status(403).json({ error: 'لا صلاحية لك في جهة المشروع الهدف' });
    db.prepare('UPDATE tasks SET tenant_id=? WHERE id=?').run(nt, t.id);
  }
  const f = { ...t, ...pick(req.body, ['title', 'descr', 'project_id', 'assignee_id', 'due', 'prio', 'status']) };
  db.prepare('UPDATE tasks SET title=?,descr=?,project_id=?,assignee_id=?,due=?,prio=?,status=? WHERE id=?')
    .run(f.title, f.descr, f.project_id, f.assignee_id, f.due, f.prio, f.status, t.id);
  if (req.body.status && req.body.status !== t.status)
    mailer.logAct(`${name(req)} نقل «${t.title}» إلى ${stName(req.body.status)}`);
  if (req.body.assignee_id && req.body.assignee_id !== t.assignee_id && req.body.assignee_id !== req.user.id)
    db.prepare('INSERT INTO notifications(user_id,body) VALUES (?,?)').run(req.body.assignee_id, `أُسندت إليك مهمة: ${t.title}`);
  emit(); res.json({ ok: 1 });
});
r.delete('/tasks/:id', guardEdit, (req, res) => {
  db.prepare("UPDATE tasks SET deleted_at=datetime('now'), deleted_by=? WHERE id=?").run(req.user.id, req.params.id);
  emit(); res.json({ ok: 1 });
});
r.post('/tasks/:id/comments', guardEdit, (req, res) => {
  if (!req.body.body) return res.status(400).json({ error: 'نص التعليق مطلوب' });
  db.prepare('INSERT INTO comments(task_id,user_id,body) VALUES (?,?,?)').run(req.params.id, req.user.id, req.body.body);
  const t = db.prepare('SELECT * FROM tasks WHERE id=?').get(req.params.id);
  if (t && t.assignee_id && t.assignee_id !== req.user.id)
    db.prepare('INSERT INTO notifications(user_id,body) VALUES (?,?)').run(t.assignee_id, `تعليق جديد على «${t.title}»`);
  emit(); res.json({ ok: 1 });
});

/* ---------- البريد ---------- */
r.post('/emails/:id/send', guardEdit, async (req, res) => {
  try { const info = await mailer.sendReply(Number(req.params.id), req.body.body || '', req.user.id);
    res.json({ ok: 1, dev: !!info.dev }); }
  catch (e) { res.status(400).json({ error: e.message }); }
});
r.post('/emails/:id/schedule', guardEdit, (req, res) => {
  const em = db.prepare('SELECT * FROM emails WHERE id=?').get(req.params.id);
  if (!em) return res.status(404).json({ error: 'الرسالة غير موجودة' });
  if (!req.body.send_at) return res.status(400).json({ error: 'حدد موعد الإرسال' });
  db.prepare('INSERT INTO scheduled(email_id,to_email,subject,body,send_at,created_by) VALUES (?,?,?,?,?,?)')
    .run(em.id, em.from_email, 'رد: ' + em.subject, req.body.body || em.draft, req.body.send_at.replace('T', ' '), req.user.id);
  db.prepare('UPDATE emails SET draft=? WHERE id=?').run(req.body.body || em.draft, em.id);
  mailer.logAct(`${name(req)} جدول رداً على «${em.subject}»`); emit(); res.json({ ok: 1 });
});
r.delete('/scheduled/:id', guardEdit, (req, res) => {
  db.prepare("DELETE FROM scheduled WHERE id=? AND status='pending'").run(req.params.id); emit(); res.json({ ok: 1 });
});
r.patch('/emails/:id/draft', guardEdit, (req, res) => { // حفظ تلقائي للمسودة
  db.prepare('UPDATE emails SET draft=? WHERE id=?').run(req.body.draft || '', req.params.id); res.json({ ok: 1 });
});
r.post('/emails/:id/regenerate', guardEdit, async (req, res) => {
  const em = db.prepare('SELECT * FROM emails WHERE id=?').get(req.params.id);
  const ai = await require('./ai').summarizeAndDraft(em);
  db.prepare('UPDATE emails SET summary=?,draft=? WHERE id=?').run(JSON.stringify(ai.summary), ai.draft, em.id);
  emit(); res.json({ ok: 1, engine: ai.engine });
});
r.post('/review/:id/convert', guardEdit, async (req, res) => {
  const rq = db.prepare('SELECT * FROM review_queue WHERE id=?').get(req.params.id);
  if (!rq) return res.status(404).json({ error: 'غير موجودة' });
  const pid = req.body.project_id || db.prepare('SELECT id FROM projects LIMIT 1').get().id;
  const mb = db.prepare('SELECT * FROM mailboxes LIMIT 1').get();
  const tid = await mailer.processIncoming({ ...mb, default_project_id: pid },
    { messageId: 'review-' + rq.id + '-' + Date.now(), subject: rq.subject,
      from: { value: [{ name: rq.from_email, address: rq.from_email }] }, text: rq.body, attachments: [] });
  db.prepare('DELETE FROM review_queue WHERE id=?').run(rq.id); emit(); res.json({ ok: 1, task_id: tid });
});
r.delete('/review/:id', guardEdit, (req, res) => {
  db.prepare('DELETE FROM review_queue WHERE id=?').run(req.params.id); emit(); res.json({ ok: 1 });
});

/* محاكاة بريد وارد — لتجربة الخط كاملاً بدون خادم بريد فعلي */
r.post('/dev/simulate-email', guardEdit, async (req, res) => {
  const mb = req.body.mailbox_id ? db.prepare('SELECT * FROM mailboxes WHERE id=?').get(req.body.mailbox_id) : db.prepare('SELECT * FROM mailboxes ORDER BY id LIMIT 1').get();
  if (!mb) return res.status(400).json({ error: 'لا يوجد صندوق' });
  const raw = `Message-ID: <sim-${Date.now()}@demo.local>\r\nFrom: ${req.body.from_name || 'عميل تجريبي'} <${req.body.from_email || 'client@example.com'}>\r\nSubject: ${req.body.subject || 'رسالة تجريبية'}\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n${req.body.body || 'نص الرسالة التجريبية.'}`;
  const parsed = await simpleParser(Buffer.from(raw));
  const tid = await mailer.processIncoming(mb, parsed);
  res.json({ ok: 1, task_id: tid });
});

/* ---------- الدردشة ---------- */
r.post('/messages', guardEdit, (req, res) => {
  const { channel_id, body } = req.body;
  if (!channel_id || !body) return res.status(400).json({ error: 'القناة والنص مطلوبان' });
  const ch = db.prepare('SELECT * FROM channels WHERE id=?').get(channel_id);
  if (!ch) return res.status(404).json({ error: 'القناة غير موجودة' });
  if (ch.is_dm ? (ch.dm_a !== req.user.id && ch.dm_b !== req.user.id) : !canEditIn(req, ch.tenant_id))
    return res.status(403).json({ error: 'لا صلاحية لك في هذه القناة' });
  const id = db.prepare('INSERT INTO messages(channel_id,user_id,body) VALUES (?,?,?)').run(channel_id, req.user.id, body).lastInsertRowid;
  // إشارات @
  for (const m of db.prepare('SELECT id,name FROM users').all())
    if (m.id !== req.user.id && body.includes('@' + m.name.split(' ')[0]))
      db.prepare('INSERT INTO notifications(user_id,body) VALUES (?,?)').run(m.id, `${name(req)} أشار إليك في الدردشة`);
  emit(); res.json({ id });
});
r.post('/messages/:id/task', guardEdit, (req, res) => {
  const m = db.prepare('SELECT * FROM messages WHERE id=?').get(req.params.id);
  if (!m) return res.status(404).json({ error: 'الرسالة غير موجودة' });
  const pid = req.body.project_id || db.prepare('SELECT id FROM projects WHERE status=\'نشط\' LIMIT 1').get().id;
  const tid = db.prepare("INSERT INTO tasks(title,descr,project_id,assignee_id,due) VALUES (?,?,?,?,date('now','+3 day'))")
    .run(m.body.slice(0, 80), 'أُنشئت من رسالة دردشة — الرسالة الأصلية مرتبطة بالمهمة.', pid, m.user_id).lastInsertRowid;
  db.prepare('UPDATE messages SET task_id=? WHERE id=?').run(tid, m.id);
  mailer.logAct(`${name(req)} حوّل رسالة دردشة إلى مهمة`); emit(); res.json({ task_id: tid });
});

/* ---------- الملفات ---------- */
r.post('/files', guardEdit, upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'لم يصل أي ملف' });
  const tt = req.body.task_id ? tenantOfTask(req.body.task_id) : (req.tenant || (req.user.memberships.find(m => m.role !== 'viewer') || {}).tenant_id);
  const id = db.prepare("INSERT INTO files(name,stored,size,mime,src,uploader_id,task_id,tenant_id) VALUES (?,?,?,?,'upload',?,?,?)")
    .run(req.file.originalname, req.file.filename, req.file.size, req.file.mimetype, req.user.id, req.body.task_id || null, tt || null).lastInsertRowid;
  mailer.logAct(`${name(req)} رفع ملف «${req.file.originalname}»`); emit(); res.json({ id });
});
r.get('/files/:id/download', (req, res) => {
  const f = db.prepare('SELECT * FROM files WHERE id=?').get(req.params.id);
  if (!f) return res.status(404).end();
  res.download(path.join(__dirname, '..', 'uploads', f.stored), f.name);
});
r.post('/files/:id/share', guardEdit, (req, res) => {
  const token = crypto.randomBytes(8).toString('hex');
  const pub = req.body.type === 'pub';
  db.prepare("INSERT INTO shares(file_id,token,expires_at) VALUES (?,?,?)")
    .run(req.params.id, token, pub ? new Date(Date.now() + 7 * 864e5).toISOString() : null);
  res.json({ url: (pub ? '/s/' : '/api/files/') + (pub ? token : req.params.id + '/download'), pub });
});

/* ---------- الإعدادات ---------- */
r.post('/mailboxes', guardEdit, (req, res) => {
  const b = req.body;
  if (!b.email || !b.proto) return res.status(400).json({ error: 'البريد والبروتوكول مطلوبان' });
  const scope = b.scope === 'personal' ? 'personal' : 'team';
  const tt = scope === 'team' ? (req.body.tenant_id || req.tenant || (req.user.memberships.find(m => ['owner','admin'].includes(m.role)) || {}).tenant_id) : null;
  if (scope === 'team' && !isAdminIn(req, tt)) return res.status(403).json({ error: 'صناديق الفريق يضيفها مدير الجهة — تقدر تضيف صندوقاً شخصياً' });
  const id = db.prepare('INSERT INTO mailboxes(email,proto,host,port,username,pass_enc,smtp_host,smtp_port,default_project_id,auth_type,ms_client_id,ms_client_secret_enc,ms_tenant,scope,owner_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
    .run(b.email, b.proto, b.host || null, b.port || (b.proto === 'IMAP' ? 993 : 995), b.username || b.email,
      mailer.enc(b.password || ''), b.smtp_host || null, b.smtp_port || 587,
      scope === 'personal' ? null : (b.default_project_id || null), // الشخصي لا يرتبط بمشروع أبداً
      b.auth_type || 'password', b.ms_client_id || null, b.ms_client_secret ? mailer.enc(b.ms_client_secret) : null, b.ms_tenant || 'common',
      scope, scope === 'personal' ? req.user.id : null).lastInsertRowid;
  if (tt) db.prepare('UPDATE mailboxes SET tenant_id=? WHERE id=?').run(tt, id);
  const mb = db.prepare('SELECT * FROM mailboxes WHERE id=?').get(id);
  if (mb.auth_type === 'oauth_ms') db.prepare("UPDATE mailboxes SET status='pending', last_error='بانتظار ربط حساب مايكروسوفت' WHERE id=?").run(id);
  else mailer.pollMailbox(mb); // اختبار اتصال فوري
  emit(); res.json({ id });
});

function canManageMailbox(req, mb) { return req.user.super || (mb && (mb.scope === 'personal' ? mb.owner_id === req.user.id : isAdminIn(req, mb.tenant_id))); }
r.patch('/mailboxes/:id', guardEdit, (req, res) => {
  const mb = db.prepare('SELECT * FROM mailboxes WHERE id=?').get(req.params.id);
  if (!mb) return res.status(404).json({ error: 'الصندوق غير موجود' });
  if (!canManageMailbox(req, mb)) return res.status(403).json({ error: 'تعديل هذا الصندوق لمديري النظام أو صاحبه' });
  if (req.body.scope && req.body.scope !== mb.scope && !isAdmin(req)) return res.status(403).json({ error: 'تغيير نطاق الصندوق للمدراء فقط' });
  const b = req.body;
  const f = {
    email: b.email !== undefined ? b.email : mb.email,
    proto: b.proto || mb.proto,
    host: b.host !== undefined ? b.host : mb.host,
    port: b.port || mb.port,
    username: b.username !== undefined ? (b.username || b.email || mb.username) : mb.username,
    smtp_host: b.smtp_host !== undefined ? b.smtp_host : mb.smtp_host,
    smtp_port: b.smtp_port || mb.smtp_port,
    default_project_id: b.default_project_id !== undefined ? (b.default_project_id || null) : mb.default_project_id,
    auth_type: b.auth_type || mb.auth_type,
    ms_client_id: b.ms_client_id !== undefined ? b.ms_client_id : mb.ms_client_id,
    ms_tenant: b.ms_tenant !== undefined ? (b.ms_tenant || 'common') : mb.ms_tenant,
  };
  const passEnc = b.password ? mailer.enc(b.password) : mb.pass_enc;                 // تُستبدل فقط إن أُدخلت
  const msSecEnc = b.ms_client_secret ? mailer.enc(b.ms_client_secret) : mb.ms_client_secret_enc;
  db.prepare(`UPDATE mailboxes SET email=?,proto=?,host=?,port=?,username=?,pass_enc=?,smtp_host=?,smtp_port=?,
    default_project_id=?,auth_type=?,ms_client_id=?,ms_client_secret_enc=?,ms_tenant=?,last_error=NULL WHERE id=?`)
    .run(f.email, f.proto, f.host, f.port, f.username, passEnc, f.smtp_host, f.smtp_port,
      f.default_project_id, f.auth_type, f.ms_client_id, msSecEnc, f.ms_tenant, mb.id);
  mailer.logAct(`${name(req)} عدّل إعدادات الصندوق ${f.email}`);
  const updated = db.prepare('SELECT * FROM mailboxes WHERE id=?').get(mb.id);
  if (updated.auth_type === 'oauth_ms') {
    if (!updated.ms_refresh_enc)
      db.prepare("UPDATE mailboxes SET status='pending', last_error='بانتظار ربط حساب مايكروسوفت' WHERE id=?").run(mb.id);
    // تغيير الحساب/المستأجر يستلزم إعادة ربط
    if (b.ms_client_id !== undefined && b.ms_client_id !== mb.ms_client_id)
      db.prepare("UPDATE mailboxes SET ms_refresh_enc=NULL, status='pending', last_error='تغيّر التطبيق — أعد ربط الحساب' WHERE id=?").run(mb.id);
  } else if (mb.status === 'dev' && f.host === mb.host) {
    // الصندوق التجريبي يبقى تجريبياً ما لم يتغير خادمه
  } else {
    db.prepare("UPDATE mailboxes SET status='ok' WHERE id=?").run(mb.id);
    mailer.pollMailbox(db.prepare('SELECT * FROM mailboxes WHERE id=?').get(mb.id)); // اختبار اتصال فوري بالبيانات الجديدة
  }
  emit(); res.json({ ok: 1 });
});

r.delete('/mailboxes/:id', guardEdit, (req, res) => {
  const mb = db.prepare('SELECT * FROM mailboxes WHERE id=?').get(req.params.id);
  if (!mb) return res.status(404).json({ error: 'غير موجود' });
  if (!canManageMailbox(req, mb)) return res.status(403).json({ error: 'حذف هذا الصندوق لمديري النظام أو صاحبه' });
  db.prepare('DELETE FROM mailboxes WHERE id=?').run(req.params.id); emit(); res.json({ ok: 1 });
});
r.post('/mailboxes/:id/sync', guardEdit, async (req, res) => {
  const mb = db.prepare('SELECT * FROM mailboxes WHERE id=?').get(req.params.id);
  if (mb && mb.status !== 'dev') await mailer.pollMailbox(mb);
  emit(); res.json({ ok: 1 });
});
r.patch('/members/:id', (req, res) => {
  const tt = req.body.tenant_id || req.tenant;
  if (!tt || !isAdminIn(req, tt)) return res.status(403).json({ error: 'إدارة الأعضاء تتم داخل جهة أنت مديرها — بدّل لجهة محددة' });
  const target = db.prepare('SELECT * FROM users WHERE id=?').get(req.params.id);
  if (!target) return res.status(404).json({ error: 'العضو غير موجود' });
  if (target.is_super) return res.status(403).json({ error: 'لا يمكن تعديل مالك المنشأة' });
  if (req.body.role) db.prepare('UPDATE memberships SET role=? WHERE user_id=? AND tenant_id=?').run(req.body.role, target.id, tt);
  if (req.body.remove) db.prepare('DELETE FROM memberships WHERE user_id=? AND tenant_id=?').run(target.id, tt);
  if (req.body.active !== undefined && req.user.super) db.prepare('UPDATE users SET active=? WHERE id=?').run(req.body.active ? 1 : 0, target.id);
  mailer.logAct(`${name(req)} عدّل صلاحية ${target.name} (سجل التدقيق)`); emit(); res.json({ ok: 1 });
});
r.post('/notifications/read', (req, res) => {
  db.prepare('UPDATE notifications SET is_read=1 WHERE user_id=?').run(req.user.id); emit(); res.json({ ok: 1 });
});


/* ---------- الملف الشخصي ---------- */
r.patch('/me', (req, res) => {
  if (req.body.name) db.prepare('UPDATE users SET name=? WHERE id=?').run(String(req.body.name).slice(0, 60), req.user.id);
  if (req.body.notify_email !== undefined) db.prepare('UPDATE users SET notify_email=? WHERE id=?').run(req.body.notify_email ? 1 : 0, req.user.id);
  emit(); res.json({ ok: 1 });
});
r.post('/me/password', (req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
  if (!bcrypt.compareSync(req.body.current || '', u.pass)) return res.status(400).json({ error: 'كلمة المرور الحالية غير صحيحة' });
  if (!req.body.newpass || req.body.newpass.length < 8) return res.status(400).json({ error: 'كلمة المرور الجديدة 8 أحرف على الأقل' });
  db.prepare('UPDATE users SET pass=? WHERE id=?').run(bcrypt.hashSync(req.body.newpass, 10), req.user.id);
  res.json({ ok: 1 });
});

/* ---------- دعوة الأعضاء برابط ---------- */
r.post('/members/invite', (req, res) => {
  const { name: nm, email, role } = req.body;
  const tt = req.body.tenant_id || req.tenant;
  if (!tt || !isAdminIn(req, tt)) return res.status(403).json({ error: 'اختر جهة أنت مديرها لدعوة عضو إليها' });
  if (!nm || !email) return res.status(400).json({ error: 'الاسم والبريد مطلوبان' });
  const existing = db.prepare('SELECT * FROM users WHERE email=?').get(String(email).toLowerCase());
  if (existing) { // مستخدم قائم → عضوية إضافية في الجهة مباشرة
    if (db.prepare('SELECT 1 FROM memberships WHERE user_id=? AND tenant_id=?').get(existing.id, tt))
      return res.status(400).json({ error: 'هذا العضو منضم لهذه الجهة أصلاً' });
    db.prepare('INSERT INTO memberships(user_id,tenant_id,role) VALUES (?,?,?)').run(existing.id, tt, role || 'member');
    mailer.notifyUser(existing.id, `أُضفت لجهة «${db.prepare('SELECT name FROM tenants WHERE id=?').get(tt).name}»`, true);
    emit(); return res.json({ ok: 1, existing: true });
  }
  const token = crypto.randomBytes(16).toString('hex');
  const nuid = db.prepare('INSERT INTO users(name,email,pass,role,color,active,invite_token,must_set_pass) VALUES (?,?,?,?,?,1,?,1)')
    .run(nm, String(email).toLowerCase(), bcrypt.hashSync(crypto.randomUUID(), 10), role || 'member',
      ['#5B4BAE', '#2B5E9E', '#B3372F', '#A16207', '#1E8E5A'][db.prepare('SELECT COUNT(*) c FROM users').get().c % 5], token).lastInsertRowid;
  db.prepare('INSERT INTO memberships(user_id,tenant_id,role) VALUES (?,?,?)').run(nuid, tt, role || 'member');
  mailer.logAct(`${name(req)} دعا عضواً جديداً: ${nm}`);
  const base = mailer.getSetting('base_url') || (req.protocol + '://' + req.get('host'));
  const link = base + '/invite/' + token;
  // إن كان بريد النظام مهيأً نرسل الدعوة تلقائياً أيضاً
  mailer.sendSystemMail(email, 'دعوة للانضمام إلى محور', `مرحباً ${nm}،\n\nدُعيت للانضمام لنظام محور. افتح الرابط لتعيين كلمة مرورك:\n${link}`).catch(() => {});
  emit(); res.json({ ok: 1, link });
});

/* ---------- مشاريع ومنتجات من الواجهة ---------- */
r.post('/projects', guardEdit, (req, res) => {
  if (!req.body.name) return res.status(400).json({ error: 'اسم المشروع مطلوب' });
  const tt = req.body.tenant_id || req.tenant || (req.user.memberships.find(m => m.role !== 'viewer') || {}).tenant_id;
  if (!canEditIn(req, tt)) return res.status(403).json({ error: 'اختر جهة لديك فيها صلاحية تحرير' });
  const id = db.prepare('INSERT INTO projects(name,color,product_id,tenant_id) VALUES (?,?,?,?)')
    .run(req.body.name, req.body.color || '#0E766B', req.body.product_id || null, tt).lastInsertRowid;
  mailer.logAct(`${name(req)} أنشأ مشروع «${req.body.name}»`); emit(); res.json({ id });
});
r.patch('/projects/:id', guardEdit, (req, res) => {
  if (req.body.status) db.prepare('UPDATE projects SET status=? WHERE id=?').run(req.body.status, req.params.id);
  emit(); res.json({ ok: 1 });
});
r.post('/products', guardEdit, (req, res) => {
  if (!req.body.name) return res.status(400).json({ error: 'اسم المنتج مطلوب' });
  const tt = req.body.tenant_id || req.tenant || (req.user.memberships.find(m => m.role !== 'viewer') || {}).tenant_id;
  if (!canEditIn(req, tt)) return res.status(403).json({ error: 'اختر جهة لديك فيها صلاحية تحرير' });
  const id = db.prepare('INSERT INTO products(name,descr,owner_id,tenant_id) VALUES (?,?,?,?)')
    .run(req.body.name, req.body.descr || '', req.user.id, tt).lastInsertRowid;
  mailer.logAct(`${name(req)} أضاف منتج «${req.body.name}»`); emit(); res.json({ id });
});

/* ---------- بريد النظام (إيميلات التنبيه) ---------- */
r.post('/system-smtp', guardAdmin, (req, res) => {
  const b = req.body;
  mailer.setSetting('smtp_host', b.host || ''); mailer.setSetting('smtp_port', String(b.port || 587));
  mailer.setSetting('smtp_user', b.user || ''); mailer.setSetting('smtp_from', b.from || b.user || '');
  if (b.pass) mailer.setSetting('smtp_pass_enc', mailer.enc(b.pass));
  mailer.setSetting('notify_email_enabled', b.enabled === false ? '0' : '1');
  if (b.base_url) mailer.setSetting('base_url', String(b.base_url).replace(/\/$/, ''));
  emit(); res.json({ ok: 1 });
});
r.post('/system-smtp/test', guardAdmin, async (req, res) => {
  try {
    const me = db.prepare('SELECT email FROM users WHERE id=?').get(req.user.id);
    const info = await mailer.sendSystemMail(me.email, 'محور — رسالة اختبار', 'إعداد بريد النظام يعمل بنجاح ✓');
    res.json({ ok: 1, dev: !!info.dev, skipped: !!info.skipped, to: me.email });
  } catch (e) { res.status(400).json({ error: 'فشل الإرسال: ' + e.message }); }
});

/* ---------- التقويم: أحداث يدوية ---------- */
r.post('/events', guardEdit, (req, res) => {
  const b = req.body;
  if (!b.title || !b.starts_at) return res.status(400).json({ error: 'العنوان ووقت البداية مطلوبان' });
  const id = db.prepare("INSERT INTO events(title,starts_at,ends_at,location,notes,source,user_id) VALUES (?,?,?,?,?,'manual',?)")
    .run(b.title, b.starts_at, b.ends_at || null, b.location || '', b.notes || '', req.user.id).lastInsertRowid;
  mailer.logAct(`${name(req)} أضاف للتقويم: «${b.title}»`); emit(); res.json({ id });
});
r.delete('/events/:id', guardEdit, (req, res) => {
  db.prepare('DELETE FROM events WHERE id=?').run(req.params.id); emit(); res.json({ ok: 1 });
});

/* ---------- إعدادات رابط الحجز ---------- */
r.post('/booking-settings', (req, res) => {
  const b = req.body;
  const slug = String(b.slug || '').toLowerCase().replace(/[^a-z0-9-]/g, '');
  if (b.enabled && !slug) return res.status(400).json({ error: 'حدد معرّف الرابط بأحرف إنجليزية' });
  const taken = slug && db.prepare('SELECT user_id FROM booking_settings WHERE slug=? AND user_id!=?').get(slug, req.user.id);
  if (taken) return res.status(400).json({ error: 'هذا المعرّف مستخدم لعضو آخر' });
  db.prepare(`INSERT INTO booking_settings(user_id,slug,enabled,duration,days,start_hour,end_hour,title)
    VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET slug=excluded.slug,enabled=excluded.enabled,
    duration=excluded.duration,days=excluded.days,start_hour=excluded.start_hour,end_hour=excluded.end_hour,title=excluded.title`)
    .run(req.user.id, slug || null, b.enabled ? 1 : 0, Number(b.duration) || 30, b.days || '0,1,2,3,4',
      Number(b.start_hour) ?? 9, Number(b.end_hour) ?? 17, b.title || 'اجتماع');
  emit(); res.json({ ok: 1 });
});

/* ---------- ربط مايكروسوفت: رابط التفويض ---------- */
r.get('/mailboxes/:id/ms-auth-url', guardEdit, (req, res) => {
  const mb = db.prepare('SELECT * FROM mailboxes WHERE id=?').get(req.params.id);
  if (!canManageMailbox(req, mb)) return res.status(403).json({ error: 'ربط هذا الصندوق لمديري النظام أو صاحبه' });
  if (!mb || mb.auth_type !== 'oauth_ms') return res.status(400).json({ error: 'الصندوق ليس بنمط مايكروسوفت OAuth2' });
  if (!mb.ms_client_id) return res.status(400).json({ error: 'أدخل Client ID أولاً' });
  const base = mailer.getSetting('base_url');
  if (!base) return res.status(400).json({ error: 'اضبط رابط النظام الأساسي أولاً في إعدادات بريد النظام (مثال: https://t.do.sa)' });
  const state = jwt.sign({ mb: mb.id }, SECRET, { expiresIn: '15m' });
  res.json({ url: require('./msauth').authUrl(mb, base, state) });
});


/* ---------- v0.3: حذف منتج ---------- */
r.delete('/products/:id', guardEdit, (req, res) => {
  const pr = db.prepare('SELECT * FROM products WHERE id=?').get(req.params.id);
  if (!pr) return res.status(404).json({ error: 'المنتج غير موجود' });
  db.prepare('UPDATE projects SET product_id=NULL WHERE product_id=?').run(pr.id); // المشاريع تبقى، يُفك ربطها فقط
  db.prepare('DELETE FROM releases WHERE product_id=?').run(pr.id);
  db.prepare('DELETE FROM products WHERE id=?').run(pr.id);
  mailer.logAct(`${name(req)} حذف منتج «${pr.name}» (فُك ربط مشاريعه)`);
  emit(); res.json({ ok: 1 });
});

/* ---------- v0.3: رابطا حجز (حضوري بوقت انتقال / أونلاين) ---------- */
r.post('/booking-types', (req, res) => {
  const b = req.body;
  if (!['online', 'inperson'].includes(b.kind)) return res.status(400).json({ error: 'نوع غير معروف' });
  const slug = String(b.slug || '').toLowerCase().replace(/[^a-z0-9-]/g, '');
  if (b.enabled && !slug) return res.status(400).json({ error: 'حدد معرّف الرابط بأحرف إنجليزية' });
  const taken = slug && db.prepare('SELECT id FROM booking_types WHERE slug=? AND NOT (user_id=? AND kind=?)').get(slug, req.user.id, b.kind);
  if (taken) return res.status(400).json({ error: 'هذا المعرّف مستخدم — اختر غيره' });
  db.prepare(`INSERT INTO booking_types(user_id,kind,slug,enabled,duration,days,start_hour,end_hour,buffer_before,buffer_after,title)
    VALUES (?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(user_id,kind) DO UPDATE SET slug=excluded.slug,enabled=excluded.enabled,
    duration=excluded.duration,days=excluded.days,start_hour=excluded.start_hour,end_hour=excluded.end_hour,
    buffer_before=excluded.buffer_before,buffer_after=excluded.buffer_after,title=excluded.title`)
    .run(req.user.id, b.kind, slug || null, b.enabled ? 1 : 0, Number(b.duration) || 30, b.days || '0,1,2,3,4',
      Number(b.start_hour) || 9, Number(b.end_hour) || 17,
      b.kind === 'inperson' ? (Number(b.buffer_before) || 0) : 0, b.kind === 'inperson' ? (Number(b.buffer_after) || 0) : 0,
      b.title || (b.kind === 'inperson' ? 'اجتماع حضوري' : 'اجتماع أونلاين'));
  emit(); res.json({ ok: 1 });
});

/* ---------- v0.3: قراءات الدردشة ---------- */
r.post('/channels/:id/read', (req, res) => {
  const last = db.prepare('SELECT MAX(id) m FROM messages WHERE channel_id=?').get(req.params.id).m || 0;
  db.prepare('INSERT INTO channel_reads(user_id,channel_id,last_read) VALUES (?,?,?) ON CONFLICT(user_id,channel_id) DO UPDATE SET last_read=excluded.last_read')
    .run(req.user.id, req.params.id, last);
  res.json({ ok: 1 });
});

/* ---------- v0.3: مهام البريد — موافقة/رفض/ربط بمهمة قائمة ---------- */
r.post('/emails/:id/approve', guardEdit, (req, res) => {
  const em = db.prepare('SELECT * FROM emails WHERE id=?').get(req.params.id);
  if (!em) return res.status(404).json({ error: 'الرسالة غير موجودة' });
  if (em.task_id) return res.status(400).json({ error: 'الرسالة مرتبطة بمهمة أصلاً' });
  const pid = req.body.project_id || db.prepare("SELECT default_project_id p FROM mailboxes WHERE id=?").get(em.mailbox_id)?.p;
  if (!pid) return res.status(400).json({ error: 'اختر المشروع' });
  const tt = tenantOfProject(pid);
  if (!canEditIn(req, tt)) return res.status(403).json({ error: 'لا صلاحية لك في جهة هذا المشروع' });
  const tid = db.prepare("INSERT INTO tasks(title,descr,project_id,assignee_id,due,prio,status,src,email_id) VALUES (?,?,?,?,date('now','+2 day'),'p2','todo','mail',?)")
    .run(req.body.title || em.proposed_title || em.subject,
      `وصلت عبر البريد من ${em.from_name} <${em.from_email}> — اعتُمدت مسودة المهمة.`, pid, req.body.assignee_id || null, em.id).lastInsertRowid;
  db.prepare('UPDATE tasks SET tenant_id=? WHERE id=?').run(tt, tid);
  db.prepare('UPDATE files SET tenant_id=? WHERE email_id=?').run(tt, em.id);
  db.prepare('UPDATE emails SET task_id=?, approved=1 WHERE id=?').run(tid, em.id);
  db.prepare('UPDATE files SET task_id=? WHERE email_id=? AND task_id IS NULL').run(tid, em.id);
  if (req.body.assignee_id && req.body.assignee_id !== req.user.id)
    mailer.notifyUser(req.body.assignee_id, `أُسندت إليك مهمة من البريد: ${req.body.title || em.proposed_title}`, true);
  mailer.logAct(`${name(req)} اعتمد مسودة مهمة من البريد: «${req.body.title || em.proposed_title}»`);
  emit(); res.json({ ok: 1, task_id: tid });
});
r.post('/emails/:id/reject', guardEdit, (req, res) => {
  db.prepare('UPDATE emails SET approved=-1 WHERE id=? AND task_id IS NULL').run(req.params.id);
  mailer.logAct(`${name(req)} رفض مسودة مهمة من البريد`); emit(); res.json({ ok: 1 });
});
r.post('/emails/:id/link-task', guardEdit, (req, res) => {
  const em = db.prepare('SELECT * FROM emails WHERE id=?').get(req.params.id);
  const target = db.prepare('SELECT * FROM tasks WHERE id=?').get(req.body.task_id);
  if (!em || !target) return res.status(404).json({ error: 'الرسالة أو المهمة غير موجودة' });
  const oldTaskId = em.task_id;
  db.prepare('INSERT INTO comments(task_id,user_id,body,is_mail) VALUES (?,?,?,1)')
    .run(target.id, req.user.id, `رُبط بريد وارد بهذه المهمة — من ${em.from_name}: «${em.subject}»\n${(em.body || '').slice(0, 800)}`);
  db.prepare('UPDATE emails SET task_id=?, approved=1 WHERE id=?').run(target.id, em.id);
  db.prepare('UPDATE files SET task_id=? WHERE email_id=?').run(target.id, em.id);
  // حذف المهمة التلقائية اليتيمة إن كانت بلا تعليقات مستخدمين
  if (oldTaskId && oldTaskId !== target.id) {
    const hasWork = db.prepare('SELECT COUNT(*) c FROM comments WHERE task_id=? AND user_id IS NOT NULL AND is_mail=0').get(oldTaskId).c;
    if (!hasWork) db.prepare("UPDATE tasks SET deleted_at=datetime('now'), deleted_by=? WHERE id=?").run(req.user.id, oldTaskId);
  }
  mailer.logAct(`${name(req)} ربط بريداً بمهمة «${target.title}»`);
  emit(); res.json({ ok: 1, task_id: target.id });
});

/* ---------- v0.3: إعدادات محرك الذكاء ووضع مهام البريد ---------- */
r.post('/ai-settings', guardAdmin, async (req, res) => {
  const b = req.body;
  if (b.provider) mailer.setSetting('ai_provider', b.provider);
  if (b.model !== undefined) mailer.setSetting('ai_model', b.model || '');
  if (b.base_url !== undefined) mailer.setSetting('ai_base_url', (b.base_url || '').replace(/\/$/, ''));
  if (b.api_key) mailer.setSetting('ai_api_key_enc', mailer.enc(b.api_key));
  if (b.custom_key) mailer.setSetting('ai_custom_key_enc', mailer.enc(b.custom_key));
  if (b.mail_task_mode) mailer.setSetting('mail_task_mode', b.mail_task_mode === 'approve' ? 'approve' : 'auto');
  emit(); res.json({ ok: 1 });
});
r.post('/ai-settings/test', guardAdmin, async (req, res) => {
  res.json(await require('./ai').testEngine());
});


/* ---------- v0.4: حذف الملفات (ناعم) وسلة المحذوفات ---------- */
r.delete('/files/:id', guardEdit, (req, res) => {
  const f = db.prepare('SELECT * FROM files WHERE id=? AND deleted_at IS NULL').get(req.params.id);
  if (!f) return res.status(404).json({ error: 'الملف غير موجود' });
  db.prepare("UPDATE files SET deleted_at=datetime('now'), deleted_by=? WHERE id=?").run(req.user.id, f.id);
  mailer.logAct(`${name(req)} حذف ملف «${f.name}» (سلة المحذوفات — 180 يوماً)`);
  emit(); res.json({ ok: 1 });
});
function canRestore(req, row) { return isAdmin(req) || row.deleted_by === req.user.id; }
r.post('/trash/restore', (req, res) => {
  const { type, id } = req.body;
  const table = type === 'file' ? 'files' : type === 'task' ? 'tasks' : null;
  if (!table) return res.status(400).json({ error: 'نوع غير معروف' });
  const row = db.prepare(`SELECT * FROM ${table} WHERE id=? AND deleted_at IS NOT NULL`).get(id);
  if (!row) return res.status(404).json({ error: 'العنصر غير موجود في السلة' });
  if (!canRestore(req, row)) return res.status(403).json({ error: 'الاستعادة لمدير النظام أو من حذف العنصر' });
  db.prepare(`UPDATE ${table} SET deleted_at=NULL, deleted_by=NULL WHERE id=?`).run(id);
  mailer.logAct(`${name(req)} استعاد ${type === 'file' ? 'ملف' : 'مهمة'} من سلة المحذوفات`);
  emit(); res.json({ ok: 1 });
});
r.delete('/trash/:type/:id', guardAdmin, (req, res) => {
  if (req.params.type === 'file') {
    const f = db.prepare('SELECT * FROM files WHERE id=? AND deleted_at IS NOT NULL').get(req.params.id);
    if (f) { try { require('fs').unlinkSync(path.join(__dirname, '..', 'uploads', f.stored)); } catch {}
      db.prepare('DELETE FROM shares WHERE file_id=?').run(f.id);
      db.prepare('DELETE FROM files WHERE id=?').run(f.id); }
  } else {
    db.prepare('DELETE FROM tasks WHERE id=? AND deleted_at IS NOT NULL').run(req.params.id);
  }
  mailer.logAct(`${name(req)} مسح عنصراً نهائياً من سلة المحذوفات`);
  emit(); res.json({ ok: 1 });
});

/* ---------- v0.4: إنشاء قناة وبدء محادثة مباشرة ---------- */
r.post('/channels', guardEdit, (req, res) => {
  let nm = String(req.body.name || '').trim();
  if (!nm) return res.status(400).json({ error: 'اسم القناة مطلوب' });
  if (!nm.startsWith('#')) nm = '# ' + nm;
  const tt = req.body.tenant_id || req.tenant || (req.user.memberships.find(m => m.role !== 'viewer') || {}).tenant_id;
  if (!canEditIn(req, tt)) return res.status(403).json({ error: 'اختر جهة لديك فيها صلاحية' });
  const id = db.prepare('INSERT INTO channels(name,is_dm,tenant_id) VALUES (?,0,?)').run(nm, tt).lastInsertRowid;
  mailer.logAct(`${name(req)} أنشأ قناة ${nm}`); emit(); res.json({ id });
});
r.post('/channels/dm', (req, res) => {
  const other = Number(req.body.user_id);
  if (!other || other === req.user.id) return res.status(400).json({ error: 'اختر عضواً' });
  let ch = db.prepare('SELECT * FROM channels WHERE is_dm=1 AND ((dm_a=? AND dm_b=?) OR (dm_a=? AND dm_b=?))')
    .get(req.user.id, other, other, req.user.id);
  if (!ch) {
    const id = db.prepare("INSERT INTO channels(name,is_dm,dm_a,dm_b) VALUES ('مباشر',1,?,?)").run(req.user.id, other).lastInsertRowid;
    ch = { id };
    mailer.notifyUser(other, `${name(req)} بدأ محادثة مباشرة معك`, false);
  }
  emit(); res.json({ id: ch.id });
});


/* ---------- v0.6: إدارة الجهات ---------- */
r.post('/tenants', (req, res) => {
  if (!req.user.super) return res.status(403).json({ error: 'إنشاء الجهات لمالك المنشأة' });
  if (!req.body.name) return res.status(400).json({ error: 'اسم الجهة مطلوب' });
  const id = db.prepare('INSERT INTO tenants(name,color) VALUES (?,?)').run(req.body.name, req.body.color || '#0E766B').lastInsertRowid;
  db.prepare("INSERT INTO memberships(user_id,tenant_id,role) VALUES (?,?,'owner')").run(req.user.id, id);
  db.prepare('INSERT INTO channels(name,is_dm,tenant_id) VALUES (?,0,?)').run('# عام', id);
  mailer.logAct(`أُنشئت جهة جديدة: ${req.body.name}`);
  emit(); res.json({ id });
});
r.patch('/tenants/:id', (req, res) => {
  if (!isAdminIn(req, req.params.id)) return res.status(403).json({ error: 'لمدير الجهة' });
  if (req.body.name) db.prepare('UPDATE tenants SET name=? WHERE id=?').run(req.body.name, req.params.id);
  emit(); res.json({ ok: 1 });
});

/* ---------- البحث الموحد ---------- */
r.get('/search', (req, res) => {
  const q = '%' + (req.query.q || '') + '%';
  const tids = req.tenant ? [req.tenant] : req.tenantIds;
  const TIN = tids.length ? `(${tids.join(',')})` : '(-1)';
  res.json({
    tasks: db.prepare(`SELECT id,title FROM tasks WHERE title LIKE ? AND deleted_at IS NULL AND tenant_id IN ${TIN} LIMIT 5`).all(q),
    projects: db.prepare(`SELECT id,name FROM projects WHERE name LIKE ? AND tenant_id IN ${TIN} LIMIT 4`).all(q),
    emails: db.prepare('SELECT id,subject,from_name FROM emails WHERE (subject LIKE ? OR from_name LIKE ? OR body LIKE ?) AND summary IS NOT NULL LIMIT 4').all(q, q, q),
    files: db.prepare('SELECT id,name FROM files WHERE name LIKE ? AND deleted_at IS NULL LIMIT 4').all(q),
    events: db.prepare("SELECT id,title,starts_at FROM events WHERE title LIKE ? AND status='ok' LIMIT 4").all(q),
    messages: db.prepare('SELECT id,channel_id,body FROM messages WHERE body LIKE ? LIMIT 4').all(q),
  });
});

function pick(o, ks) { const r2 = {}; ks.forEach(k => { if (o[k] !== undefined) r2[k] = o[k]; }); return r2; }
function name(req) { return db.prepare('SELECT name FROM users WHERE id=?').get(req.user.id).name; }
function stName(s) { return { todo: 'قيد الانتظار', inprog: 'قيد التنفيذ', review: 'قيد المراجعة', done: 'مكتملة' }[s] || s; }
module.exports = r;
