// واجهات REST — كل التعديلات تمر من هنا وتبث حدث تحديث لحظي لكل المتصلين.
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const crypto = require('crypto');
const path = require('path');
const { simpleParser } = require('mailparser');
const { db } = require('./db');
const mailer = require('./mailer');

const SECRET = process.env.SECRET || 'dev';
const upload = multer({ dest: path.join(__dirname, '..', 'uploads'), limits: { fileSize: 200 * 1024 * 1024 } });
const r = express.Router();
let emit = () => {};
r.onChange = fn => { emit = fn; };

/* ---------- المصادقة والصلاحيات ---------- */
r.post('/auth/login', (req, res) => {
  const { email, password } = req.body || {};
  const u = db.prepare('SELECT * FROM users WHERE email=? AND active=1').get(String(email || '').toLowerCase());
  if (!u || !bcrypt.compareSync(password || '', u.pass)) return res.status(401).json({ error: 'بيانات الدخول غير صحيحة' });
  const token = jwt.sign({ id: u.id, role: u.role }, SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: u.id, name: u.name, email: u.email, role: u.role, color: u.color } });
});

function auth(req, res, next) {
  try {
    const t = (req.headers.authorization || '').replace('Bearer ', '');
    req.user = jwt.verify(t, SECRET);
    const u = db.prepare('SELECT active,role FROM users WHERE id=?').get(req.user.id);
    if (!u || !u.active) throw new Error();
    req.user.role = u.role; next();
  } catch { res.status(401).json({ error: 'انتهت الجلسة — سجّل الدخول من جديد' }); }
}
const canEdit = req => req.user.role !== 'viewer';
const isAdmin = req => ['owner', 'admin'].includes(req.user.role);
function guardEdit(req, res, next) { if (!canEdit(req)) return res.status(403).json({ error: 'صلاحيتك للمشاهدة فقط' }); next(); }
function guardAdmin(req, res, next) { if (!isAdmin(req)) return res.status(403).json({ error: 'تتطلب صلاحية إدارية' }); next(); }
r.use(auth);

/* ---------- الحالة الكاملة (يقرأها العميل بعد كل تحديث لحظي) ---------- */
r.get('/state', (req, res) => {
  const uid = req.user.id;
  res.json({
    me: db.prepare('SELECT id,name,email,role,color FROM users WHERE id=?').get(uid),
    members: db.prepare('SELECT id,name,email,role,color,active FROM users').all(),
    products: db.prepare('SELECT * FROM products').all().map(p => ({ ...p,
      releases: db.prepare('SELECT * FROM releases WHERE product_id=? ORDER BY date DESC').all(p.id) })),
    projects: db.prepare('SELECT * FROM projects').all(),
    tasks: db.prepare('SELECT * FROM tasks ORDER BY id DESC').all().map(t => ({ ...t,
      comments: db.prepare('SELECT c.*,u.name uname,u.color ucolor FROM comments c LEFT JOIN users u ON u.id=c.user_id WHERE task_id=? ORDER BY c.id').all(t.id) })),
    emails: db.prepare('SELECT * FROM emails WHERE summary IS NOT NULL ORDER BY id DESC LIMIT 100').all()
      .map(e => ({ ...e, summary: JSON.parse(e.summary || '[]'),
        attachments: db.prepare('SELECT id,name,size FROM files WHERE email_id=?').all(e.id) })),
    review: db.prepare('SELECT * FROM review_queue ORDER BY id DESC').all(),
    scheduled: db.prepare("SELECT s.*,e.subject esubject FROM scheduled s LEFT JOIN emails e ON e.id=s.email_id WHERE s.status='pending' ORDER BY send_at").all(),
    channels: db.prepare('SELECT * FROM channels').all().filter(c => !c.is_dm || c.dm_a === uid || c.dm_b === uid),
    messages: db.prepare('SELECT m.*,u.name uname,u.color ucolor FROM messages m JOIN users u ON u.id=m.user_id ORDER BY m.id').all(),
    files: db.prepare('SELECT f.*,u.name uname FROM files f LEFT JOIN users u ON u.id=f.uploader_id ORDER BY f.id DESC').all(),
    mailboxes: db.prepare('SELECT id,email,proto,host,port,smtp_host,default_project_id,status,last_sync,processed,last_error FROM mailboxes').all(),
    notifications: db.prepare('SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 30').all(uid),
    activity: db.prepare('SELECT * FROM activity ORDER BY id DESC LIMIT 20').all(),
    devMode: String(process.env.MAIL_DEV_MODE || 'true') === 'true',
  });
});

/* ---------- المهام ---------- */
r.post('/tasks', guardEdit, (req, res) => {
  const { title, project_id, assignee_id, due, prio, descr } = req.body;
  if (!title || !project_id) return res.status(400).json({ error: 'العنوان والمشروع مطلوبان' });
  const id = db.prepare('INSERT INTO tasks(title,descr,project_id,assignee_id,due,prio) VALUES (?,?,?,?,?,?)')
    .run(title, descr || '', project_id, assignee_id || null, due || null, prio || 'p2').lastInsertRowid;
  mailer.logAct(`${name(req)} أنشأ مهمة «${title}»`);
  if (assignee_id && assignee_id !== req.user.id)
    db.prepare('INSERT INTO notifications(user_id,body) VALUES (?,?)').run(assignee_id, `أُسندت إليك مهمة: ${title}`);
  emit(); res.json({ id });
});
r.patch('/tasks/:id', guardEdit, (req, res) => {
  const t = db.prepare('SELECT * FROM tasks WHERE id=?').get(req.params.id);
  if (!t) return res.status(404).json({ error: 'المهمة غير موجودة' });
  const f = { ...t, ...pick(req.body, ['title', 'descr', 'project_id', 'assignee_id', 'due', 'prio', 'status']) };
  db.prepare('UPDATE tasks SET title=?,descr=?,project_id=?,assignee_id=?,due=?,prio=?,status=? WHERE id=?')
    .run(f.title, f.descr, f.project_id, f.assignee_id, f.due, f.prio, f.status, t.id);
  if (req.body.status && req.body.status !== t.status)
    mailer.logAct(`${name(req)} نقل «${t.title}» إلى ${stName(req.body.status)}`);
  if (req.body.assignee_id && req.body.assignee_id !== t.assignee_id && req.body.assignee_id !== req.user.id)
    db.prepare('INSERT INTO notifications(user_id,body) VALUES (?,?)').run(req.body.assignee_id, `أُسندت إليك مهمة: ${t.title}`);
  emit(); res.json({ ok: 1 });
});
r.delete('/tasks/:id', guardEdit, (req, res) => {
  db.prepare('UPDATE files SET task_id=NULL WHERE task_id=?').run(req.params.id); // الملفات تبقى في المكتبة
  db.prepare('DELETE FROM tasks WHERE id=?').run(req.params.id);
  emit(); res.json({ ok: 1 });
});
r.post('/tasks/:id/comments', guardEdit, (req, res) => {
  if (!req.body.body) return res.status(400).json({ error: 'نص التعليق مطلوب' });
  db.prepare('INSERT INTO comments(task_id,user_id,body) VALUES (?,?,?)').run(req.params.id, req.user.id, req.body.body);
  const t = db.prepare('SELECT * FROM tasks WHERE id=?').get(req.params.id);
  if (t && t.assignee_id && t.assignee_id !== req.user.id)
    db.prepare('INSERT INTO notifications(user_id,body) VALUES (?,?)').run(t.assignee_id, `تعليق جديد على «${t.title}»`);
  emit(); res.json({ ok: 1 });
});

/* ---------- البريد ---------- */
r.post('/emails/:id/send', guardEdit, async (req, res) => {
  try { const info = await mailer.sendReply(Number(req.params.id), req.body.body || '', req.user.id);
    res.json({ ok: 1, dev: !!info.dev }); }
  catch (e) { res.status(400).json({ error: e.message }); }
});
r.post('/emails/:id/schedule', guardEdit, (req, res) => {
  const em = db.prepare('SELECT * FROM emails WHERE id=?').get(req.params.id);
  if (!em) return res.status(404).json({ error: 'الرسالة غير موجودة' });
  if (!req.body.send_at) return res.status(400).json({ error: 'حدد موعد الإرسال' });
  db.prepare('INSERT INTO scheduled(email_id,to_email,subject,body,send_at,created_by) VALUES (?,?,?,?,?,?)')
    .run(em.id, em.from_email, 'رد: ' + em.subject, req.body.body || em.draft, req.body.send_at.replace('T', ' '), req.user.id);
  db.prepare('UPDATE emails SET draft=? WHERE id=?').run(req.body.body || em.draft, em.id);
  mailer.logAct(`${name(req)} جدول رداً على «${em.subject}»`); emit(); res.json({ ok: 1 });
});
r.delete('/scheduled/:id', guardEdit, (req, res) => {
  db.prepare("DELETE FROM scheduled WHERE id=? AND status='pending'").run(req.params.id); emit(); res.json({ ok: 1 });
});
r.patch('/emails/:id/draft', guardEdit, (req, res) => { // حفظ تلقائي للمسودة
  db.prepare('UPDATE emails SET draft=? WHERE id=?').run(req.body.draft || '', req.params.id); res.json({ ok: 1 });
});
r.post('/emails/:id/regenerate', guardEdit, async (req, res) => {
  const em = db.prepare('SELECT * FROM emails WHERE id=?').get(req.params.id);
  const ai = await require('./ai').summarizeAndDraft(em);
  db.prepare('UPDATE emails SET summary=?,draft=? WHERE id=?').run(JSON.stringify(ai.summary), ai.draft, em.id);
  emit(); res.json({ ok: 1, engine: ai.engine });
});
r.post('/review/:id/convert', guardEdit, async (req, res) => {
  const rq = db.prepare('SELECT * FROM review_queue WHERE id=?').get(req.params.id);
  if (!rq) return res.status(404).json({ error: 'غير موجودة' });
  const pid = req.body.project_id || db.prepare('SELECT id FROM projects LIMIT 1').get().id;
  const mb = db.prepare('SELECT * FROM mailboxes LIMIT 1').get();
  const tid = await mailer.processIncoming({ ...mb, default_project_id: pid },
    { messageId: 'review-' + rq.id + '-' + Date.now(), subject: rq.subject,
      from: { value: [{ name: rq.from_email, address: rq.from_email }] }, text: rq.body, attachments: [] });
  db.prepare('DELETE FROM review_queue WHERE id=?').run(rq.id); emit(); res.json({ ok: 1, task_id: tid });
});
r.delete('/review/:id', guardEdit, (req, res) => {
  db.prepare('DELETE FROM review_queue WHERE id=?').run(req.params.id); emit(); res.json({ ok: 1 });
});

/* محاكاة بريد وارد — لتجربة الخط كاملاً بدون خادم بريد فعلي */
r.post('/dev/simulate-email', guardEdit, async (req, res) => {
  const mb = db.prepare('SELECT * FROM mailboxes ORDER BY id LIMIT 1').get();
  const raw = `Message-ID: <sim-${Date.now()}@demo.local>\r\nFrom: ${req.body.from_name || 'عميل تجريبي'} <${req.body.from_email || 'client@example.com'}>\r\nSubject: ${req.body.subject || 'رسالة تجريبية'}\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n${req.body.body || 'نص الرسالة التجريبية.'}`;
  const parsed = await simpleParser(Buffer.from(raw));
  const tid = await mailer.processIncoming(mb, parsed);
  res.json({ ok: 1, task_id: tid });
});

/* ---------- الدردشة ---------- */
r.post('/messages', guardEdit, (req, res) => {
  const { channel_id, body } = req.body;
  if (!channel_id || !body) return res.status(400).json({ error: 'القناة والنص مطلوبان' });
  const id = db.prepare('INSERT INTO messages(channel_id,user_id,body) VALUES (?,?,?)').run(channel_id, req.user.id, body).lastInsertRowid;
  // إشارات @
  for (const m of db.prepare('SELECT id,name FROM users').all())
    if (m.id !== req.user.id && body.includes('@' + m.name.split(' ')[0]))
      db.prepare('INSERT INTO notifications(user_id,body) VALUES (?,?)').run(m.id, `${name(req)} أشار إليك في الدردشة`);
  emit(); res.json({ id });
});
r.post('/messages/:id/task', guardEdit, (req, res) => {
  const m = db.prepare('SELECT * FROM messages WHERE id=?').get(req.params.id);
  if (!m) return res.status(404).json({ error: 'الرسالة غير موجودة' });
  const pid = req.body.project_id || db.prepare('SELECT id FROM projects WHERE status=\'نشط\' LIMIT 1').get().id;
  const tid = db.prepare("INSERT INTO tasks(title,descr,project_id,assignee_id,due) VALUES (?,?,?,?,date('now','+3 day'))")
    .run(m.body.slice(0, 80), 'أُنشئت من رسالة دردشة — الرسالة الأصلية مرتبطة بالمهمة.', pid, m.user_id).lastInsertRowid;
  db.prepare('UPDATE messages SET task_id=? WHERE id=?').run(tid, m.id);
  mailer.logAct(`${name(req)} حوّل رسالة دردشة إلى مهمة`); emit(); res.json({ task_id: tid });
});

/* ---------- الملفات ---------- */
r.post('/files', guardEdit, upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'لم يصل أي ملف' });
  const id = db.prepare("INSERT INTO files(name,stored,size,mime,src,uploader_id,task_id) VALUES (?,?,?,?,'upload',?,?)")
    .run(req.file.originalname, req.file.filename, req.file.size, req.file.mimetype, req.user.id, req.body.task_id || null).lastInsertRowid;
  mailer.logAct(`${name(req)} رفع ملف «${req.file.originalname}»`); emit(); res.json({ id });
});
r.get('/files/:id/download', (req, res) => {
  const f = db.prepare('SELECT * FROM files WHERE id=?').get(req.params.id);
  if (!f) return res.status(404).end();
  res.download(path.join(__dirname, '..', 'uploads', f.stored), f.name);
});
r.post('/files/:id/share', guardEdit, (req, res) => {
  const token = crypto.randomBytes(8).toString('hex');
  const pub = req.body.type === 'pub';
  db.prepare("INSERT INTO shares(file_id,token,expires_at) VALUES (?,?,?)")
    .run(req.params.id, token, pub ? new Date(Date.now() + 7 * 864e5).toISOString() : null);
  res.json({ url: (pub ? '/s/' : '/api/files/') + (pub ? token : req.params.id + '/download'), pub });
});

/* ---------- الإعدادات ---------- */
r.post('/mailboxes', guardAdmin, (req, res) => {
  const b = req.body;
  if (!b.email || !b.proto) return res.status(400).json({ error: 'البريد والبروتوكول مطلوبان' });
  const id = db.prepare('INSERT INTO mailboxes(email,proto,host,port,username,pass_enc,smtp_host,smtp_port,default_project_id) VALUES (?,?,?,?,?,?,?,?,?)')
    .run(b.email, b.proto, b.host || null, b.port || (b.proto === 'IMAP' ? 993 : 995), b.username || b.email,
      mailer.enc(b.password || ''), b.smtp_host || null, b.smtp_port || 587, b.default_project_id || null).lastInsertRowid;
  const mb = db.prepare('SELECT * FROM mailboxes WHERE id=?').get(id);
  mailer.pollMailbox(mb); // اختبار اتصال فوري
  emit(); res.json({ id });
});
r.delete('/mailboxes/:id', guardAdmin, (req, res) => {
  db.prepare('DELETE FROM mailboxes WHERE id=?').run(req.params.id); emit(); res.json({ ok: 1 });
});
r.post('/mailboxes/:id/sync', guardEdit, async (req, res) => {
  const mb = db.prepare('SELECT * FROM mailboxes WHERE id=?').get(req.params.id);
  if (mb && mb.status !== 'dev') await mailer.pollMailbox(mb);
  emit(); res.json({ ok: 1 });
});
r.patch('/members/:id', guardAdmin, (req, res) => {
  const target = db.prepare('SELECT * FROM users WHERE id=?').get(req.params.id);
  if (!target) return res.status(404).json({ error: 'العضو غير موجود' });
  if (target.role === 'owner') return res.status(403).json({ error: 'لا يمكن تعديل صلاحية المالك' });
  if (req.body.role) db.prepare('UPDATE users SET role=? WHERE id=?').run(req.body.role, target.id);
  if (req.body.active !== undefined) db.prepare('UPDATE users SET active=? WHERE id=?').run(req.body.active ? 1 : 0, target.id);
  mailer.logAct(`${name(req)} عدّل صلاحية ${target.name} (سجل التدقيق)`); emit(); res.json({ ok: 1 });
});
r.post('/notifications/read', (req, res) => {
  db.prepare('UPDATE notifications SET is_read=1 WHERE user_id=?').run(req.user.id); emit(); res.json({ ok: 1 });
});

/* ---------- البحث الموحد ---------- */
r.get('/search', (req, res) => {
  const q = '%' + (req.query.q || '') + '%';
  res.json({
    tasks: db.prepare('SELECT id,title FROM tasks WHERE title LIKE ? LIMIT 5').all(q),
    projects: db.prepare('SELECT id,name FROM projects WHERE name LIKE ? LIMIT 4').all(q),
    emails: db.prepare('SELECT id,subject,from_name FROM emails WHERE (subject LIKE ? OR from_name LIKE ? OR body LIKE ?) AND summary IS NOT NULL LIMIT 4').all(q, q, q),
    files: db.prepare('SELECT id,name FROM files WHERE name LIKE ? LIMIT 4').all(q),
    messages: db.prepare('SELECT id,channel_id,body FROM messages WHERE body LIKE ? LIMIT 4').all(q),
  });
});

function pick(o, ks) { const r2 = {}; ks.forEach(k => { if (o[k] !== undefined) r2[k] = o[k]; }); return r2; }
function name(req) { return db.prepare('SELECT name FROM users WHERE id=?').get(req.user.id).name; }
function stName(s) { return { todo: 'قيد الانتظار', inprog: 'قيد التنفيذ', review: 'قيد المراجعة', done: 'مكتملة' }[s] || s; }
module.exports = r;
