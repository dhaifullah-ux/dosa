// محور — نقطة تشغيل الخادم: REST + ملفات ثابتة + WebSocket لحظي + عمال البريد والجدولة.
require('dotenv').config();
const express = require('express');
const http = require('http');
const path = require('path');
const jwt = require('jsonwebtoken');
const { db, seed } = require('./db');
const routes = require('./routes');
const mailer = require('./mailer');

seed();
const app = express();
const server = http.createServer(app);
const io = require('socket.io')(server, { cors: { origin: '*' } });

app.use(express.json({ limit: '2mb' }));
app.use('/api', routes);
app.use(express.static(path.join(__dirname, '..', '..', 'web')));

// رابط المشاركة العام المؤقت
app.get('/s/:token', (req, res) => {
  const sh = db.prepare('SELECT s.*,f.name,f.stored FROM shares s JOIN files f ON f.id=s.file_id WHERE token=?').get(req.params.token);
  if (!sh) return res.status(404).send('<meta charset=utf-8><h3 style="font-family:sans-serif">الرابط غير صحيح</h3>');
  if (sh.expires_at && new Date(sh.expires_at) < new Date())
    return res.status(410).send('<meta charset=utf-8><h3 style="font-family:sans-serif">انتهت صلاحية هذا الرابط</h3>');
  res.download(path.join(__dirname, '..', 'uploads', sh.stored), sh.name);
});

// WebSocket: مصادقة بالتوكن، وأي تغيير في النظام يبث «changed» فيعيد كل عميل تحميل حالته
io.use((socket, next) => {
  try { socket.user = jwt.verify(socket.handshake.auth.token, process.env.SECRET || 'dev'); next(); }
  catch { next(new Error('unauthorized')); }
});
const broadcast = () => io.emit('changed');
routes.onChange(broadcast);
mailer.onChange(broadcast);

mailer.startPolling();
mailer.startScheduler();

const PORT = process.env.PORT || 4000;
server.listen(PORT, () => console.log(`محور يعمل الآن → http://localhost:${PORT}  (الدخول: sultan@mihwar.local / 123456)`));
